import React from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { StyleSheet, View } from 'react-native';

const Tab = createMaterialTopTabNavigator()


export function TopTabNavigator() {
  return (
    <View style={styles.container}>
      <Tab.Navigator screenOptions={{
      tabBarStyle: styles.tabBar,
      tabBarLabelStyle: styles.tabBarLabel,}}>
        <Tab.Screen name="Leitor" component={HomeScreen} />
        <Tab.Screen name="Gerador" component={ProfileScreen} />
       
      </Tab.Navigator>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
  },
  tabBar: {
    backgroundColor: '#000',
    height: 50,
    borderColor: 'transparent' // Mantém o tabBar transparente
  },
  tabBarLabel: {
    color: 'white',
    fontFamily: 'Poppins', // Define a fonte Poppins
  },
});
export default TopTabNavigator;
