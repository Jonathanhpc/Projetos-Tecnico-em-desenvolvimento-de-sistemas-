import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Button } from 'react-native';

// Função para verificar se há um vencedor
const checkWinner = (board) => {
  const winningCombinations = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Linhas
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Colunas
    [0, 4, 8], [2, 4, 6], // Diagonais
  ];

  for (let [a, b, c] of winningCombinations) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return board[a];
    }
  }
  return null;
};

// Função simples para a jogada da máquina
const getMachineMove = (board) => {
  const availableMoves = board.map((value, index) => (value === null ? index : null)).filter(index => index !== null);
  return availableMoves[Math.floor(Math.random() * availableMoves.length)];
};

const TicTacToe = () => {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [player, setPlayer] = useState(null); // 'X' ou 'O'
  const [isGameOver, setIsGameOver] = useState(false);
  const [winner, setWinner] = useState(null);

  const handlePress = (index) => {
    if (board[index] || isGameOver) return;

    // Definir a jogada do jogador
    const newBoard = [...board];
    newBoard[index] = player;
    setBoard(newBoard);

    // Verificar se há vencedor
    const gameWinner = checkWinner(newBoard);
    if (gameWinner) {
      setIsGameOver(true);
      setWinner(gameWinner);
      Alert.alert('Fim de Jogo', `O jogador ${gameWinner} venceu!`, [
        { text: 'Reiniciar', onPress: resetGame },
      ]);
      return;
    }

    // Verificar empate
    if (!newBoard.includes(null)) {
      setIsGameOver(true);
      setWinner('Empate');
      Alert.alert('Fim de Jogo', 'O jogo terminou em empate!', [
        { text: 'Reiniciar', onPress: resetGame },
      ]);
      return;
    }

    // Jogada da máquina
    const machineMove = getMachineMove(newBoard);
    newBoard[machineMove] = 'O';
    setBoard(newBoard);

    // Verificar se há vencedor
    const machineWinner = checkWinner(newBoard);
    if (machineWinner) {
      setIsGameOver(true);
      setWinner(machineWinner);
      Alert.alert('Fim de Jogo', `A máquina (${machineWinner}) venceu!`, [
        { text: 'Reiniciar', onPress: resetGame },
      ]);
      return;
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsGameOver(false);
    setWinner(null);
  };

  const handlePlayerChoice = (choice) => {
    setPlayer(choice);
    resetGame();
  };

  const renderSquare = (index) => (
    <TouchableOpacity
      key={index}
      style={[styles.square, { backgroundColor: board[index] === 'X' ? '#4CAF50' : board[index] === 'O' ? '#FFC107' : '#FFFFFF' }]}
      onPress={() => handlePress(index)}
    >
      <Text style={styles.squareText}>{board[index]}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {!player && (
        <View style={styles.choiceContainer}>
          <Text style={styles.choiceText}>Escolha seu símbolo:</Text>
          <View style={styles.buttonContainer}>
            <Button title="X" onPress={() => handlePlayerChoice('X')} />
            <Button title="O" onPress={() => handlePlayerChoice('O')} />
          </View>
        </View>
      )}
      {player && (
        <>
          <View style={styles.titleContainer}>
            <Text style={styles.title}>Jogo da Velha</Text>
          </View>
          <View style={styles.boardContainer}>
            <View style={styles.board}>
              {board.map((_, index) => renderSquare(index))}
            </View>
            {isGameOver && (
              <TouchableOpacity style={styles.resetButton} onPress={resetGame}>
                <Text style={styles.resetButtonText}>Reiniciar</Text>
              </TouchableOpacity>
            )}
          </View>
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  choiceContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  choiceText: {
    fontSize: 20,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    marginTop: 10,
  },
  titleContainer: {
    backgroundColor: '#d3d3d3', // Cinza claro
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    color: '#333',
  },
  boardContainer: {
    backgroundColor: '#f0f8ff', // Fundo claro atrás do tabuleiro
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
  },
  board: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: 300,
    height: 300,
    marginBottom: 20,
  },
  square: {
    width: 100,
    height: 100,
    borderWidth: 1,
    borderColor: '#ccc',
    justifyContent: 'center',
    alignItems: 'center',
  },
  squareText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#333',
  },
  resetButton: {
    backgroundColor: '#FF6347', // Tomato
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  resetButtonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default TicTacToe;
