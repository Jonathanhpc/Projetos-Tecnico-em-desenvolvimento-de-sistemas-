import React from 'react';
import { View, Image, TouchableOpacity, StyleSheet } from 'react-native';

// Defina suas imagens diretamente aqui
const images = {
  0: require('../../Images/tigre.png'),
  1: require('../../Images/coala.png'),
  2: require('../../Images/serpente.png'),
  3: require('../../Images/cao.png'),
  4: require('../../Images/abelha.png'),
  5: require('../../Images/tartaruga-marinha.png'),
  6: require('../../Images/golfinho.png'),
};

const Card = ({ card, cardWidth, isFlipped, onPress }) => {
  return (
    <TouchableOpacity 
      onPress={onPress} 
      style={[styles.card, { width: cardWidth, height: cardWidth }]}
      activeOpacity={0.8}
    >
      {isFlipped ? (
        <Image 
          source={images[card.id]} 
          style={styles.cardImage} 
          resizeMode="cover" 
        />
      ) : (
        <View style={styles.cardBack} />
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    margin: 5,
    borderRadius: 10,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cardBack: {
    backgroundColor: '#ccc',
    width: '100%',
    height: '100%',
  },
});

export default Card;
