import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { View, Text, StyleSheet, Dimensions, Alert, Image, TouchableOpacity, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 

const { width, height } = Dimensions.get('window');
const cardWidth = width / 4 - 10;

const images = {
  0: require('../../Images/tigre.png'),
  1: require('../../Images/coala.png'),
  2: require('../../Images/serpente.png'),
  3: require('../../Images/cao.png'),
  4: require('../../Images/abelha.png'),
  5: require('../../Images/tartaruga-marinha.png'),
  6: require('../../Images/golfinho.png'),
};

const App = () => {
  const [screen, setScreen] = useState('difficulty');
  const [difficulty, setDifficulty] = useState('easy');
  const [cards, setCards] = useState([]);
  const [flippedIndices, setFlippedIndices] = useState([]);
  const [matchedPairs, setMatchedPairs] = useState([]);
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [showingCards, setShowingCards] = useState(true);

  const difficultyTimes = useMemo(() => ({
    easy: 10000,
    medium: 7000,
    hard: 5000,
  }), []);

  const numberOfPairs = useMemo(() => ({
    easy: 4,
    medium: 6,
    hard: 8,
  }), []);

  const initializeCards = useCallback(() => {
    const pairs = numberOfPairs[difficulty];
    const cardImages = Array.from({ length: pairs }, (_, index) => ({ id: index }));

    const shuffledCards = cardImages
      .flatMap(card => [card, { ...card }])
      .sort(() => Math.random() - 0.5);

    setCards(shuffledCards);
    setFlippedIndices([]);
    setMatchedPairs([]);
    setScore(0);
    setIsGameOver(false);
    setShowingCards(true);
  }, [difficulty, numberOfPairs]);

  const resetGame = useCallback(() => {
    initializeCards();
    setIsGameOver(false);
  }, [initializeCards]);

  const handleCardPress = (index) => {
    if (flippedIndices.length === 2 || flippedIndices.includes(index) || matchedPairs.includes(cards[index].id)) {
      return;
    }
    setFlippedIndices((prev) => [...prev, index]);
  };

  useEffect(() => {
    if (flippedIndices.length === 2) {
      const [firstIndex, secondIndex] = flippedIndices;
      const firstCard = cards[firstIndex];
      const secondCard = cards[secondIndex];

      if (firstCard.id === secondCard.id) {
        setMatchedPairs((prev) => [...prev, firstCard.id]);
        setScore((prev) => prev + 1);
      }
      setTimeout(() => setFlippedIndices([]), 1000);
    }
  }, [flippedIndices, cards]);

  useEffect(() => {
    if (matchedPairs.length === cards.length / 2) {
      setIsGameOver(true);
      Alert.alert('Parabéns!', `Você completou o jogo com ${score} pontos!`, [
        { text: 'Reiniciar', onPress: resetGame },
      ]);
    }
  }, [matchedPairs, cards.length, resetGame, score]);

  useEffect(() => {
    if (showingCards) {
      const timer = setTimeout(() => {
        setShowingCards(false);
      }, difficultyTimes[difficulty]);
      return () => clearTimeout(timer);
    }
  }, [showingCards, difficulty, difficultyTimes]);

  const Card = ({ card, cardWidth, isFlipped, onPress }) => {
    return (
      <TouchableOpacity 
        onPress={onPress} 
        style={[styles.card, { width: cardWidth, height: cardWidth }]}
        activeOpacity={0.8}
      >
        {isFlipped ? (
          <Image 
            source={images[card.id]} 
            style={styles.cardImage} 
            resizeMode="cover" 
          />
        ) : (
          <View style={styles.cardBack} />
        )}
      </TouchableOpacity>
    );
  };

  if (screen === 'difficulty') {
    return (
      <View style={styles.container}>
        <View style={styles.difficultyContainer}>
          <Text style={styles.title}>Escolha a Dificuldade</Text>
          <TouchableOpacity style={styles.button} onPress={() => { setDifficulty('easy'); setScreen('game'); }}>
            <Text style={styles.buttonText}>Fácil</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => { setDifficulty('medium'); setScreen('game'); }}>
            <Text style={styles.buttonText}>Médio</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => { setDifficulty('hard'); setScreen('game'); }}>
            <Text style={styles.buttonText}>Avançado</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <ImageBackground 
      source={require('../../Images/fundo.png')}
      style={styles.background}
    >
      <View style={styles.navBar}>
        <TouchableOpacity 
          onPress={() => setScreen('difficulty')} 
          style={styles.navButton}
          accessibilityLabel="Voltar"
          accessibilityHint="Volta para a tela anterior"
        >
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.navTitle}>Jogo da Memória</Text>
        <View style={styles.navButton} />
      </View>

      <View style={styles.gameContainer}>
        {!isGameOver && (
          <View style={styles.scoreContainer}>
            <Text style={styles.score}>Pontuação: {score}</Text>
          </View>
        )}
        <View style={styles.cardBackground}>
          <View style={styles.cardContainer}>
            {cards.map((card, index) => (
              <Card
                key={index}
                card={card}
                cardWidth={cardWidth}
                isFlipped={showingCards || flippedIndices.includes(index) || matchedPairs.includes(card.id)}
                onPress={() => handleCardPress(index)}
              />
            ))}
          </View>
        </View>
        {isGameOver && (
          <TouchableOpacity style={styles.resetButton} onPress={resetGame}>
            <Text style={styles.resetButtonText}>Reiniciar</Text>
          </TouchableOpacity>
        )}
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
  },
  navTitle: {
    fontSize: width * 0.05,
    color: '#FFF',
    fontWeight: 'bold',
  },
  gameContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: height * 0.1,
  },
  scoreContainer: {
    marginBottom: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: 10,
    borderRadius: 10,
  },
  score: {
    fontSize: width * 0.05,
    color: '#000',
    fontWeight: 'bold',
  },
  cardBackground: {
    backgroundColor: '#FFCCBC',
    padding: 10,
    borderRadius: 10,
  },
  cardContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: width - 20,
    justifyContent: 'center',
  },
  card: {
    margin: 5,
    borderRadius: 10,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 2,
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cardBack: {
    backgroundColor: '#ccc',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  resetButton: {
    backgroundColor: '#FF6F00',
    padding: width * 0.03,
    borderRadius: 12,
    marginTop: 20,
  },
  resetButtonText: {
    color: '#FFF',
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  title: {
    fontSize: width * 0.06,
    marginBottom: 20,
    fontWeight: 'bold',
    backgroundColor: '#F0F0F0',
    padding: 10,
    borderRadius: 10,
  },
  difficultyContainer: {
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    padding: 20,
    borderRadius: 10,
  },
  button: {
    backgroundColor: '#FF6F00',
    padding: width * 0.04,
    borderRadius: 12,
    marginBottom: 15,
    width: width * 0.8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
});

export default App;
