import React from 'react';
import { Container, UserPhoto, UserName, Button } from './styles';

const SidebarItem = ({ Icon, Text, photoUrl, userName, onButtonClick }) => {
  return (
    <Container>
      <UserPhoto src={photoUrl} alt={`${userName}'s photo`} />
      <div>
        <Icon />
        <UserName>{userName}</UserName>
        <div>{Text}</div>
      </div>
      <Button onClick={onButtonClick}>Go to Page</Button>
    </Container>
  );
};

export default SidebarItem;
