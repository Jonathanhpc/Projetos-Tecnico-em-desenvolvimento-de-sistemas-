import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  align-items: center;
  background-color: #1A202C; 
  font-size: 20px;
  color: white;
  padding: 10px;
  cursor: pointer;
  border-radius: 10px;
  margin: 0 15px 20px;
  position: relative; /* Para posicionar o botão no canto direito */

  > svg {
    margin: 0 20px;
  }

  &:hover {
    background-color: black;
  }
`;

export const UserPhoto = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 15px;
`;

export const UserName = styled.div`
  font-weight: bold;
  margin-bottom: 5px;
`;

export const Button = styled.button`
  position: absolute; /* Posiciona o botão no canto direito */
  right: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 5px 10px;
  cursor: pointer;
  font-size: 16px;

  &:hover {
    background-color: #0056b3;
  }
`;
