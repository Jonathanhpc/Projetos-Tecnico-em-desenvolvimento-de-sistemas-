import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, Dimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { PieChart } from 'react-native-chart-kit';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native'; 

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; 
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const AlunoScreen = () => {
  const [showPieChart, setShowPieChart] = useState(false); 
  const [alunoData, setAlunoData] = useState(null); 
  const navigation = useNavigation(); 

  // Definir as cores das matérias
  const materiaColors = {
        'Biologia': '#FFFF00',
    'portugues': '#FF9E3D',
    'matematica': '#FF7F50',
    'fisica': '#F4C430',
    'geografia': '#CC5500',
    'ingles': '#FFFF00',
    // Adicione outras matérias com suas cores aqui
  };

  useEffect(() => {
    const fetchAlunoProgresso = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (!userData) throw new Error('Usuário não autenticado.');

        const { email } = JSON.parse(userData);
        if (!email) throw new Error('Email não encontrado nos dados do usuário.');

        // Consulta o ID do aluno com base no e-mail
        const { data: alunoData, error: alunoError } = await supabase
          .from('alunos_instituicao')
          .select('id, nome, email')
          .eq('email', email)
          .single();

        if (alunoError || !alunoData) throw new Error('Erro ao buscar aluno.');

        const alunoId = alunoData.id;

        // Consulta o progresso do aluno com base no ID
        const { data: progressoData, error: progressoError } = await supabase
          .from('progresso_aluno')
          .select('pontos, progresso, materia_ou_jogo')
          .eq('aluno_id', alunoId);

        if (progressoError) throw new Error('Erro ao buscar dados de progresso.');

        if (progressoData && progressoData.length > 0) {
          // Prepara os dados do gráfico de pizza com a cor associada a cada matéria
          const progressoFormatted = progressoData.map((item) => ({
            name: item.materia_ou_jogo,
            population: item.progresso,
            color: materiaColors[item.materia_ou_jogo] || '#9E9E9E', // Cor padrão caso a matéria não esteja no objeto
            legendFontColor: '#7F7F7F',
            legendFontSize: 15,
          }));

          setAlunoData({ data: progressoFormatted });
          setShowPieChart(true);
        } else {
          Alert.alert('Aviso', 'Não há dados de progresso para este aluno.');
        }
      } catch (err) {
        Alert.alert('Erro', err.message);
      }
    };

    fetchAlunoProgresso();
  }, []);

  return (
    <View style={styles.container}>
      {/* Navbar */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.navbarTitle}>Progresso do Aluno</Text>
      </View>

      {/* Exibe o gráfico de pizza */}
      {showPieChart && alunoData && (
        <View style={styles.pieChartContainer}>
          <PieChart
            data={alunoData.data}
            width={Dimensions.get('window').width - 40} 
            height={250}
            chartConfig={{
              backgroundColor: '#FFF',
              backgroundGradientFrom: '#FFF',
              backgroundGradientTo: '#FFF',
              decimalPlaces: 2,
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  navbar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  navbarTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 15,
  },
  pieChartContainer: {
    position: 'absolute',
    top: '30%', 
    left: '5%',
    right: '5%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5DC',  
    paddingBottom: 60,  
    paddingTop: 20, 
    borderRadius: 10,      
  },
});

export default AlunoScreen;
