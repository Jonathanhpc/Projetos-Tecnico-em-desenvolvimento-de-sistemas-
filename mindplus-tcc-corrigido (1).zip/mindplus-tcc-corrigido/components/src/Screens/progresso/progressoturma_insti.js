import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput, Alert, Modal, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { useNavigation } from '@react-navigation/native';
import { PieChart } from 'react-native-chart-kit';  
import { Dimensions } from 'react-native';

// Configurações do Supabase
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; 
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);


const AlunoScreen = () => {
  const navigation = useNavigation();
  const [alunos, setAlunos] = useState([]);
  const [institutionCode, setInstitutionCode] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [newAluno, setNewAluno] = useState({ id: null, nome: '', cpf: '', email: '', rg: '', nome_mae: '', telefone: '', cep: '', endereco: '', sexo: '', data_nascimento: '', senha: '' });
  const [showModal, setShowModal] = useState(false);
  const [showPieChart, setShowPieChart] = useState(false); 
  const [alunoData, setAlunoData] = useState(null); 

  useEffect(() => {
    const fetchInstitutionAndProfissionalCode = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (!userData) throw new Error('Usuário não autenticado.');

        const { email } = JSON.parse(userData);
        if (!email) throw new Error('Email não encontrado nos dados do usuário.');

        // Buscar o código do profissional usando o e-mail
        const { data: profissionalData, error: profissionalError } = await supabase
          .from('profissional')
          .select('codigo_instituicao, codigo_profissional')
          .eq('email', email)
          .single();

        if (profissionalError || !profissionalData) throw new Error('Erro ao buscar dados do profissional.');

        const codigoProfissional = profissionalData.codigo_profissional;
        const codigoInstituicao = profissionalData.codigo_instituicao;

        setInstitutionCode(codigoInstituicao);

        fetchAlunos(codigoProfissional); 
      } catch (err) {
        Alert.alert('Erro', err.message);
      }
    };

    fetchInstitutionAndProfissionalCode();
  }, []);

  const fetchAlunos = async (codigoProfissional) => {
    try {
      
      const { data, error } = await supabase
        .from('alunos_instituicao')
        .select('*')
        .eq('codigo_profissional', codigoProfissional);

      if (error) throw new Error('Erro ao buscar alunos.');
      setAlunos(data || []);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const fetchProgressoAluno = async (alunoId) => {
    try {
      
      const { data, error } = await supabase
        .from('progresso_aluno')
        .select('pontos, progresso, materia_ou_jogo')
        .eq('aluno_id', alunoId)
        .eq('codigo_profissional', institutionCode); 

      if (error) throw new Error('Erro ao buscar dados de progresso.');

      
      if (data && data.length > 0) {
        
        const progressoData = data.map((item, index) => ({
          name: item.materia_ou_jogo,  
          population: item.progresso,  
          color: index % 2 === 0 ? '#FF6347' : '#4CAF50', 
          legendFontColor: '#7F7F7F',
          legendFontSize: 15,
        }));

        setAlunoData({ data: progressoData });
        setShowPieChart(true); 
      } else {
        Alert.alert('Aviso', 'Não há dados de progresso para este aluno.');
      }
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const showPieChartData = (aluno) => {
    
    fetchProgressoAluno(aluno.id);
  };

  const handleAddOrEditAluno = async () => {
    try {
      if (isEditing) {
        const { error } = await supabase
          .from('alunos_instituicao')
          .update({
            nome: newAluno.nome,
            cpf: newAluno.cpf,
            email: newAluno.email,
            rg: newAluno.rg,
            nome_mae: newAluno.nome_mae,
            telefone: newAluno.telefone,
            cep: newAluno.cep,
            endereco: newAluno.endereco,
            sexo: newAluno.sexo,
            data_nascimento: newAluno.data_nascimento,
            senha: newAluno.senha,
          })
          .eq('id', newAluno.id);

        if (error) throw new Error('Erro ao editar aluno.');
        Alert.alert('Sucesso', 'Aluno atualizado com sucesso!');
      } else {
        const { error } = await supabase
          .from('alunos_instituicao')
          .insert({ ...newAluno, codigo_instituicao: institutionCode });

        if (error) throw new Error('Erro ao adicionar aluno.');
        Alert.alert('Sucesso', 'Aluno cadastrado com sucesso!');
      }

      fetchAlunos(institutionCode);
      setShowForm(false);
      setNewAluno({ id: null, nome: '', cpf: '', email: '', rg: '', nome_mae: '', telefone: '', cep: '', endereco: '', sexo: '', data_nascimento: '', senha: '' });
      setIsEditing(false);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const handleDeleteAluno = async (id) => {
    try {
      const { error } = await supabase
        .from('alunos_instituicao')
        .delete()
        .eq('id', id);

      if (error) throw new Error('Erro ao deletar aluno.');
      Alert.alert('Sucesso', 'Aluno excluído com sucesso!');
      fetchAlunos(institutionCode);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const startEdit = (aluno) => {
    setNewAluno(aluno);
    setShowModal(true);
    setIsEditing(true);
    setShowPieChart(false); 
  };

  const closeModal = () => {
    setShowModal(false);
    setIsEditing(false);
    setNewAluno({ id: null, nome: '', cpf: '', email: '', rg: '', nome_mae: '', telefone: '', cep: '', endereco: '', sexo: '', data_nascimento: '', senha: '' });
    setShowPieChart(false); 
  };

  const closePieChart = () => {
    setShowPieChart(false); 
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Alunos</Text>
      </View>

      <FlatList
        data={alunos}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.alunoItem} onPress={() => showPieChartData(item)}>
            <View>
              <Text style={styles.alunoName}>{item.nome}</Text>
              <Text style={styles.alunoDetails}>CPF: {item.cpf}</Text>
            </View>
            <View style={styles.actions}>
              <TouchableOpacity onPress={() => startEdit(item)}>
                <Ionicons name="create" size={24} color="#FF6F00" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDeleteAluno(item.id)}>
                <Ionicons name="trash" size={24} color="#FF3D00" />
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        )}
      />

      <Modal visible={showForm} animationType="slide">
        <ScrollView contentContainerStyle={styles.modalContent}>
          <TextInput
            style={styles.input}
            placeholder="Nome"
            value={newAluno.nome}
            onChangeText={(text) => setNewAluno({ ...newAluno, nome: text })}
          />
          <TextInput
            style={styles.input}
            placeholder="CPF"
            value={newAluno.cpf}
            onChangeText={(text) => setNewAluno({ ...newAluno, cpf: text })}
          />

          <TouchableOpacity style={styles.button} onPress={handleAddOrEditAluno}>
            <Text style={styles.buttonText}>{isEditing ? 'Editar' : 'Adicionar'} Aluno</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.button} onPress={closeModal}>
            <Text style={styles.buttonText}>Cancelar</Text>
          </TouchableOpacity>
        </ScrollView>
      </Modal>

      {/* Exibindo o gráfico de pizza quando showPieChart for true */}
      {showPieChart && alunoData && (
        <View style={styles.pieChartContainer}>
          <TouchableOpacity style={styles.closeButton} onPress={closePieChart}>
            <Text style={styles.closeButtonText}>Fechar</Text>
          </TouchableOpacity>
          <PieChart
            data={alunoData.data}
            width={Dimensions.get('window').width - 40} 
            height={250}
            chartConfig={{
              backgroundColor: '#FFF',
              backgroundGradientFrom: '#FFF',
              backgroundGradientTo: '#FFF',
              decimalPlaces: 2,
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    paddingVertical: 15,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 20,
    color: '#FFF',
    fontWeight: 'bold',
    marginLeft: 10,
  },
  alunoItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  alunoName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  alunoDetails: {
    fontSize: 14,
    color: '#777',
  },
  actions: {
    flexDirection: 'row',
  },
  input: {
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    marginVertical: 5,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: '#FF6F00',
    paddingVertical: 10,
    borderRadius: 5,
    marginVertical: 10,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    textAlign: 'center',
  },
  modalContent: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  pieChartContainer: {
    position: 'absolute',
    top: '30%', 
    left: '5%',
    right: '5%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#DCDCDC',  
    paddingBottom: 60,  
    paddingTop: 20, 
    borderRadius: 10,
  },
  closeButton: {
    position: 'absolute',
    bottom: 10,
    left: '50%',
    transform: [{ translateX: -50}],
    backgroundColor: '#FF3D00',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  closeButtonText: {
    color: '#FFF',
    fontSize: 16,
  },
});

export default AlunoScreen;
