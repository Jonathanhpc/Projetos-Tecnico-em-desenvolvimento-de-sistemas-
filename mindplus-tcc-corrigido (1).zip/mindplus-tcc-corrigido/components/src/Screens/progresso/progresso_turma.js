import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createClient } from '@supabase/supabase-js';
import { PieChart } from 'react-native-chart-kit'; 
import { Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native'; 

// Configurações do Supabase
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const AlunoScreen = () => {
  const [materiasProgresso, setMateriasProgresso] = useState([]);
  const [showPieChart, setShowPieChart] = useState(false); 
  const navigation = useNavigation(); 

  useEffect(() => {
    fetchProgressoMaterias();
  }, []);

  const fetchProgressoMaterias = async () => {
    try {
      // Buscar os dados de progresso de todas as matérias
      const { data, error } = await supabase
        .from('progresso_aluno')
        .select('progresso, materia_ou_jogo');

      if (error) throw new Error('Erro ao buscar dados de progresso.');

      // Calcular a média de progresso por matéria
      const materiaProgress = data.reduce((acc, item) => {
        if (!acc[item.materia_ou_jogo]) {
          acc[item.materia_ou_jogo] = { totalProgresso: 0, count: 0 };
        }
        acc[item.materia_ou_jogo].totalProgresso += item.progresso;
        acc[item.materia_ou_jogo].count += 1;
        return acc;
      }, {});

      // Criar a estrutura de dados para o gráfico
      const progressoData = Object.keys(materiaProgress).map((materia) => {
        const mediaProgresso = materiaProgress[materia].totalProgresso / materiaProgress[materia].count;
        return {
          name: materia,
          population: mediaProgresso,
          color: getColorForMateria(materia), 
          legendFontColor: '#7F7F7F',
          legendFontSize: 15,
        };
      });

      setMateriasProgresso(progressoData);
      setShowPieChart(true); 
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  // Função para atribuir cor para cada matéria
  const getColorForMateria = (materia) => {
  const materiaColors = {
    'Biologia': '#FFFF00',
    'portugues': '#FF9E3D',
    'matematica': '#FF7F50',
    'fisica': '#F4C430',
    'geografia': '#CC5500',
    'ingles': '#FFFF00',
  };
  return materiaColors[materia] || '#9E9E9E'; // Corrigido de colors para materiaColors
};


  return (
    <View style={styles.container}>
      {/* Navbar com seta para voltar */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={30} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.navbarTitle}>Progresso por Matéria</Text>
      </View>

      {showPieChart && materiasProgresso.length > 0 ? (
        <View style={styles.pieChartContainer}>
          <Text style={styles.chartTitle}>Média de Progresso por Matéria</Text>
          <PieChart
            data={materiasProgresso}
            width={Dimensions.get('window').width - 40}
            height={220}
            chartConfig={{
              backgroundColor: 'transparent', 
              backgroundGradientFrom: 'transparent', 
              backgroundGradientTo: 'transparent', 
              decimalPlaces: 2,
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="transparent" 
            paddingLeft="15"
          />
        </View>
      ) : (
        <Text style={styles.noDataText}>Não há dados de progresso disponíveis.</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  navbar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  navbarTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 15,
  },
  pieChartContainer: {
    backgroundColor: '#F5F5DC', 
    borderRadius: 20,            
    padding: 20,
    shadowColor: '#FF6F00',      
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,                
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,        
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  noDataText: {
    fontSize: 16,
    color: '#FF3D00',
    textAlign: 'center',
    marginTop: 50,
  },
});

export default AlunoScreen;
