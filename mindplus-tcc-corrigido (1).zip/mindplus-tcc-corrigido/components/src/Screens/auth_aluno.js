import { supabase } from './supabaseClient'; // ajuste o caminho conforme necessário
import AsyncStorage from '@react-native-async-storage/async-storage';

export const loginUser = async (email, password, role) => {
  // Tente realizar o login usando Supabase
  const { user, error } = await supabase.auth.signIn({
    email,
    password,
  });

  // Se houver erro no login, lance um erro
  if (error) throw new Error(error.message);

  // Buscar o nome do usuário na tabela 'alunos'
  const { data, error: fetchError } = await supabase
    .from('alunos')
    .select('nome')
    .eq('email', email)
    .single();

  // Se houver erro ao buscar o nome, lance um erro
  if (fetchError) throw new Error(fetchError.message);

  // Salvar o nome do usuário no AsyncStorage
  await AsyncStorage.setItem('userName', data.nome);

  return user;
};

export const logoutUser = async () => {
  // Realizar logout e remover o nome do usuário do AsyncStorage
  await supabase.auth.signOut();
  await AsyncStorage.removeItem('userName');
};
