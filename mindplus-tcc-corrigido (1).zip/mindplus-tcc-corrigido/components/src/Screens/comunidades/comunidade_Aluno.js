import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, Image, StyleSheet, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createClient } from '@supabase/supabase-js';
import { useRoute } from '@react-navigation/native';
import MessageModal from '../Aluno/comunidade/MessageModal'; // Ajuste o caminho conforme necessário
import CommentModal from '../Aluno/comunidade/CommentModal'; // Ajuste o caminho conforme necessário

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; // Substitua pela sua URL do Supabase
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; // Substitua pela sua chave anônima do Supabase
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const CommunityScreen = () => {
  const route = useRoute(); // Usamos useRoute para pegar parâmetros da navegação
  const email = route.params?.email; // Pegando o email passado pela navegação
  const nome = route.params?.nome;
  
  const [messages, setMessages] = useState([]);
  const [comments, setComments] = useState([]);
  const [isCommentModalVisible, setIsCommentModalVisible] = useState(false);
  const [comment, setComment] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [userProfile, setUserProfile] = useState({});
  const [currentMessageId, setCurrentMessageId] = useState(null);
  const [likedMessages, setLikedMessages] = useState({});
  const [isMessageModalVisible, setIsMessageModalVisible] = useState(false);
  const [studentName, setStudentName] = useState(''); // Armazena o nome do aluno
  const [emailInput, setEmailInput] = useState(''); // Para armazenar o email inserido
  const [isEmailModalVisible, setIsEmailModalVisible] = useState(true); // Exibir modal de email inicialmente

  // Buscar o nome do aluno com base no email
  const fetchStudentDetails = async (email) => {
    try {
      const { data, error } = await supabase
        .from('alunos')
        .select('nome') // Buscando nome
        .eq('email', email)
        .single(); // Busca um único registro

      if (error) throw error;

      if (data) {
        setStudentName(data.nome); // Define o nome do aluno se encontrado
      } else {
        console.log('No data found for email:', email);
      }
    } catch (error) {
      console.error('Erro ao buscar dados do aluno:', error.message);
    }
  };

  useEffect(() => {
    if (email) {
      fetchStudentDetails(email); // Chama a função para buscar o nome do aluno
    }
  }, [email]);

  const handleAddComment = useCallback(async () => {
    if (comment.trim()) {
      await supabase.from('comments').insert([{ content: comment, user_name: studentName, message_id: currentMessageId }]);
      setComment('');
      fetchComments(currentMessageId);
    }
  }, [comment, studentName, currentMessageId, fetchComments]);

  const handleAddMessage = useCallback(async () => {
    if (newMessage.trim()) {
      const { error } = await supabase.from('messages').insert([
        {
          content: newMessage,
          user_name: studentName || 'Nome não disponível', // Usa o nome ou "Nome não disponível"
        },
      ]);
      if (!error) {
        setNewMessage('');
        setIsMessageModalVisible(false);
        fetchMessages();
      } else {
        console.error('Erro ao adicionar mensagem:', error);
      }
    }
  }, [newMessage, studentName, fetchMessages]);

  const handleLikeMessage = useCallback(async (messageId) => {
    const currentLiked = likedMessages[messageId];
    setLikedMessages((prev) => ({ ...prev, [messageId]: !currentLiked }));

    const message = messages.find((msg) => msg.id === messageId);
    const newLikes = currentLiked ? (message.likes || 0) - 1 : (message.likes || 0) + 1;

    await supabase
      .from('messages')
      .update({ likes: newLikes })
      .eq('id', messageId); // Corrigido de 'data.nome' para 'messageId'
    fetchMessages();
  }, [likedMessages, messages, fetchMessages]);

  const fetchMessages = useCallback(async () => {
    const { data, error } = await supabase.from('messages').select('*');
    if (error) {
      console.error('Erro ao buscar mensagens:', error);
    } else {
      setMessages(data);
    }
  }, []);

  const fetchComments = useCallback(async (messageId) => {
    const { data, error } = await supabase.from('comments').select('*').eq('message_id', messageId);
    if (error) {
      console.error('Erro ao buscar comentários:', error);
    } else {
      setComments(data);
    }
  }, []);

  const handleEmailSubmit = () => {
    fetchStudentDetails(emailInput);
    setIsEmailModalVisible(false);
  };

  const filteredMessages = messages.filter((message) =>
    message.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderMessage = ({ item }) => (
    <View style={styles.messageItem}>
      <View style={styles.userContainer}>
        <Image
          source={{ uri: item.user_photo || userProfile.photo }}
          style={styles.userPhoto}
        />
        <Text style={styles.studentName}>
          {studentName || 'Nome não disponível.'}
        </Text>
      </View>
      <Text style={styles.messageContent}>{item.content}</Text>
      <View style={styles.actions}>
        <TouchableOpacity onPress={() => handleLikeMessage(item.id)}>
          <Ionicons
            name={likedMessages[item.id] ? 'heart' : 'heart-outline'}
            size={20}
            color={likedMessages[item.id] ? '#FF6F00' : 'black'}
          />
        </TouchableOpacity>
        <Text style={styles.likeCount}>{item.likes || 0} curtidas</Text>
        <TouchableOpacity
          style={styles.commentButton}
          onPress={() => {
            setIsCommentModalVisible(true);
            setCurrentMessageId(item.id);
            fetchComments(item.id);
          }}
        >
          <Ionicons name="chatbubble-outline" size={20} color="black" />
        </TouchableOpacity>
        <Text style={styles.commentCount}>{comments.length} comentários</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {isEmailModalVisible && (
        <Modal
          transparent={true}
          animationType="fade"
          visible={isEmailModalVisible}
          onRequestClose={() => setIsEmailModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Digite seu Email</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Email"
                value={emailInput}
                onChangeText={setEmailInput}
              />
              <TouchableOpacity
                style={styles.modalButton}
                onPress={handleEmailSubmit}
              >
                <Text style={styles.modalButtonText}>Entrar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}

      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => {/* Lógica para voltar */}} >
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.navTitle}>Comunidade</Text>
        <TouchableOpacity>
          <Ionicons name="ellipsis-vertical" size={24} color="white" />
        </TouchableOpacity>
      </View>

      <TextInput
        style={styles.searchInput}
        placeholder="Pesquisar mensagem..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />

      <FlatList
        data={filteredMessages}
        keyExtractor={(item) => item.id.toString()}
        style={styles.messageList}
        renderItem={renderMessage}
      />

      <TouchableOpacity style={styles.fab} onPress={() => setIsMessageModalVisible(true)}>
        <Ionicons name="add" size={24} color="#fff" />
      </TouchableOpacity>

      <MessageModal
        isVisible={isMessageModalVisible}
        onClose={() => setIsMessageModalVisible(false)}
        onSend={handleAddMessage}
        message={newMessage}
        onMessageChange={setNewMessage}
      />

      <CommentModal
        isVisible={isCommentModalVisible}
        onClose={() => setIsCommentModalVisible(false)}
        onSend={handleAddComment}
        comment={comment}
        onCommentChange={setComment}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  navBar: {
    height: 60,
    backgroundColor: '#FF6F00',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  navTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  searchInput: {
    height: 40,
    backgroundColor: '#fff',
    margin: 16,
    borderRadius: 8,
    paddingHorizontal: 10,
  },
  messageList: {
    flex: 1,
    paddingHorizontal: 16,
  },
  messageItem: {
    marginVertical: 12,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  userContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userPhoto: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  studentName: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  messageContent: {
    fontSize: 16,
    marginVertical: 8,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  likeCount: {
    fontSize: 14,
    color: 'gray',
  },
  commentButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  commentCount: {
    fontSize: 14,
    color: 'gray',
  },
  fab: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    backgroundColor: '#6200EE',
    borderRadius: 30,
    padding: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 20,
    marginBottom: 10,
  },
  modalInput: {
    width: '100%',
    height: 40,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  modalButton: {
    backgroundColor: '#FF6F00',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default CommunityScreen;
