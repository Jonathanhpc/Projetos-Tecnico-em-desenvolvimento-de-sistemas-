import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; // Substitua pela sua URL do Supabase
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; // Substitua pela sua chave anônima do Supabase
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const SignupScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [studentName, setStudentName] = useState(''); // Armazena o nome do aluno
  const [studentPhoto, setStudentPhoto] = useState(''); // Armazena a foto do aluno
  const [email, setEmail] = useState(null); // Estado para armazenar o e-mail

  const fetchStudentDetails = async (email) => {
    try {
      const { data, error } = await supabase
        .from('profissional')
        .select('nome_completo') // Buscando nome e foto_perfil
        .eq('email', email)
        .single(); // Busca um único registro

      if (error) throw error; // Lança um erro se houver um problema na consulta

      if (data) {
        setStudentName(data.nome_completo); // Define o nome do aluno se encontrado
        setStudentPhoto(data.foto_perfil); // Define a foto do aluno se encontrado
      } else {
        console.log('No data found for email:', email);
      }
    } catch (error) {
      console.error('Erro ao buscar dados do aluno:', error.message);
    }
  };

  useEffect(() => {
    const getEmailFromStorage = async () => {
      try {
        const storedEmail = await AsyncStorage.getItem('userData');
        if (storedEmail) {
          const userData = JSON.parse(storedEmail);
          setEmail(userData.email);
          fetchStudentDetails(userData.email); // Chama a função para buscar o nome e foto do aluno
        }
      } catch (error) {
        console.error('Erro ao recuperar e-mail do AsyncStorage:', error);
        Alert.alert('Erro', 'Não foi possível recuperar o e-mail.');
      }
    };

    getEmailFromStorage();
  }, []);

  const openDrawer = () => {
    setSidebar(prev => !prev); // Alterna o estado da sidebar
  };

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <Image 
            source={require('../../Icons/LogoMax/logo.png')}
            style={styles.navLogo}
          />
          <TouchableOpacity 
            onPress={openDrawer} 
            style={styles.navButton}
            accessibilityLabel="Menu"
            accessibilityHint="Abre o menu lateral"
          >
            <Ionicons name="ellipsis-vertical" size={24} color="#FFF" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              {studentPhoto ? (
                <Image
                  source={{ uri: studentPhoto || '../../../src/Icons/icones/icones_perfil/professor.png' }} // Foto do usuário
                  style={styles.userPhoto}
                />
              ) : (
                <Image
                  source={require('../../../src/Icons/icones/icones_perfil/professor.png')} // Foto padrão caso não tenha foto
                  style={styles.userPhoto}
                />
              )}
              <Text style={styles.tituloText}>
                {studentName ? `Bem-vindo, ${studentName}` : 'Nome não disponível.'}
              </Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.content}>


         <View style={styles.buttonContainer}>
            <View style={styles.row}>
              <TouchableOpacity onPress={() => navigation.navigate('index_educacao')} style={styles.button}>
                <Image
                  source={require('../../Images/educacao.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Educação</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('calendario')} style={styles.button}>
                <Image
                  source={require('../../Images/cronograma.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Agenda</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.row}>
              <TouchableOpacity onPress={() => navigation.navigate('meditacao')} style={styles.button}>
                <Image
                  source={require('../../Images/harmonia.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Meditação</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('comunidade')} style={styles.button}>
                <Image
                  source={require('../../Images/bater-papo.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Comunidade pública</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.row}>
              <TouchableOpacity onPress={() => navigation.navigate('progresso2')} style={styles.button}>
                <Image
                  source={require('../../Images/aumentar.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Progresso</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('bot')} style={styles.button}>
                <Image
                  source={require('../../Images/robo.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Chat Bot</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.row}>
              <TouchableOpacity onPress={() => navigation.navigate('gerenciar_aluno')} style={styles.button}>
                <Image
                  source={require('../../Images/gerenciamento-de-equipe.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Gerenciamento de Alunos</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ImageBackground>
    </View>
  );
};

// Estilos ajustados
const styles = StyleSheet.create({
   container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
  width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * -0.12, // Reduzido para mover a logo mais para a esquerda
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: height * 0.1,
  },
  textContainer: {
    backgroundColor: '#FFB74D',
    padding: width * 0.05,
    borderRadius: 20,
    marginBottom: height * 0.03,
    alignItems: 'center',
    width: width * 0.8,
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.05,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonContainer: {
    width: '90%',
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 3,
    marginBottom: height * 0.02,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: height * 0.02,
  },
  button: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    height: 100,
    width: '45%',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  buttonImage: {
    width: width * 0.1,
    height: width * 0.1,
    marginBottom: 5,
  },
  buttonText: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  navLogo: {
   width: width * 0.3, // Ajustado para um tamanho menor
    height: height * 0.04, // Ajustado para um tamanho menor
    resizeMode: 'contain',
    marginLeft: -10, 
  },
});

export default SignupScreen;
