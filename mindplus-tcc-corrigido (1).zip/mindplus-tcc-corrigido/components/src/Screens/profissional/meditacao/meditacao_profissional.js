import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const SignupScreen = () => {
  const navigation = useNavigation();
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });
  const [sidebar, setSidebar] = useState(false);

  const goBack = () => {
    navigation.goBack();
  };

  const showSidebar = () => setSidebar(prev => !prev);

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('gerenciamento')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>
          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          {/* Contêiner de Texto */}
          <View style={styles.textContainer}>
            <Text style={styles.tituloText}>O que você está precisando?</Text>
          </View>

          {/* Contêiner de Botões em um Contêiner Cinza */}
          <View style={styles.grayContainer}>
            <View style={styles.buttonWrapper}>
              <View style={styles.buttonRow}>
                <TouchableOpacity 
                  onPress={() => navigation.navigate('controle_profissional')} 
                  style={styles.button}
                  accessibilityLabel="Gerenciamento de Profissionais"
                >
                  <Image
                    source={require('../../../Images/emocional.png')}
                    style={styles.buttonImage}
                  />
                  <Text style={styles.buttonText}>Controle de emoções</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  onPress={() => navigation.navigate('energia_profissional')} 
                  style={styles.button}
                  accessibilityLabel="Cadastro de Aluno"
                >
                  <Image
                    source={require('../../../Images/limpar.png')}
                    style={styles.buttonImage}
                  />
                  <Text style={styles.buttonText}>Energia</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  onPress={() => navigation.navigate('foco_profissional')} 
                  style={styles.button}
                  accessibilityLabel="Progresso"
                >
                  <Image
                    source={require('../../../Images/alvo.png')}
                    style={styles.buttonImage}
                  />
                  <Text style={styles.buttonText}>Foco</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>

          {/* Contêiner de Informação em Cinza */}
          <View style={styles.grayContainer}>
            <Text style={styles.infoText}>
              <Text style={styles.boldText}>O que é meditação?</Text>{'\n'}
              A meditação é uma sabedoria espiritual universal e uma prática encontrada no centro de todas as grandes tradições religiosas. Conduz o praticante da mente ao coração e à integração destes dois centros do ser humano. Não é uma prática exotérica complicada ou essencialmente difícil. É um processo de aprendizagem, a maior parte do qual é, de fato, desaprender as respostas condicionadas imaginárias à realidade.
            </Text>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingBottom: height * 0.05,
  },
  textContainer: {
    backgroundColor: '#FFB74D',
    padding: width * 0.05,
    borderRadius: 20,
    marginBottom: height * 0.03,
    alignItems: 'center',
    width: '90%',
    marginTop: height * 0.02,
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.05,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  grayContainer: {
    width: '90%',
    backgroundColor: '#E0E0E0', 
    borderRadius: 12,
    padding: width * 0.05,
    marginBottom: height * 0.03,
    alignItems: 'center', 
  },
  buttonWrapper: {
    width: '100%',
    alignItems: 'center',
    marginBottom: height * 0.02,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  button: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: width * 0.04,
    width: '30%',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  buttonImage: {
    width: width * 0.1,
    height: width * 0.1,
    marginBottom: 10,
  },
  buttonText: {
    fontSize: width * 0.03,
    color: '#333',
    fontWeight: 'bold',
  },
  infoText: {
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  },
  boldText: {
    fontWeight: 'bold',
  },
});

export default SignupScreen;
