import React, { useState, useEffect } from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { useFonts } from 'expo-font';

const TutorialScreen = () => {
  const [fontsLoaded] = useFonts({
    'Poppins': require('../../../../assets/fontes/Poppins/Poppins-Regular.ttf'),
  });

  const navigation = useNavigation();
  const [currentScreen, setCurrentScreen] = useState(1);

  useEffect(() => {
    if (fontsLoaded) {
      const timer = setTimeout(() => {
        if (currentScreen < 3) {
          setCurrentScreen(currentScreen + 1);
        } else {
          navigation.navigate('Login');
        }
      }, 4000); // Troca de tela a cada 4 segundos

      return () => clearTimeout(timer);
    }
  }, [fontsLoaded, currentScreen, navigation]);

  if (!fontsLoaded) {
    return null;
  }

  const renderTutorialScreen = () => {
    switch (currentScreen) {
      case 1:
        return (
          <View style={styles.container}>
            <Image source={require('../../Icons/LogoMax/logo.png')} style={styles.image} />
            <Text style={styles.title}>Bem-vindo ao Mind Plus</Text>
            <Text style={styles.subtitle}>Nós ajudamos você a organizar sua mente e melhorar seu foco.</Text>
          </View>
        );
      case 2:
        return (
          <View style={styles.container}>
            <Image source={require('../../Images/alvo.png')} style={styles.image} />
            <Text style={styles.title}>Técnicas para melhorar o foco</Text>
            <Text style={styles.subtitle}>Aprenda a usar técnicas simples e eficazes para aumentar sua concentração.</Text>
          </View>
        );
      case 3:
        return (
          <View style={styles.container}>
            <Image source={require('../../Images/ampulheta.png')} style={styles.image} />
            <Text style={styles.title}>Organize seu tempo</Text>
            <Text style={styles.subtitle}>Use o nosso aplicativo para planejar e gerenciar suas tarefas de forma eficiente.</Text>
          </View>
        );
      default:
        return (
          <View style={styles.container}>
            <Text style={styles.title}>Carregando...</Text>
          </View>
        );
    }
  };

  return (
    <LinearGradient
      colors={['#f46a14', '#FF9E2C']} // Degradê de laranja para branco
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={styles.background}
    >
      {renderTutorialScreen()}
      <View style={styles.footer}>
        {currentScreen > 1 && (
          <TouchableOpacity
            style={styles.navButton}
            onPress={() => setCurrentScreen(currentScreen - 1)}
          >
            <Text style={styles.buttonText}>Voltar</Text>
          </TouchableOpacity>
        )}
        {currentScreen < 3 ? (
          <TouchableOpacity
            style={styles.navButton}
            onPress={() => setCurrentScreen(currentScreen + 1)}
          >
            <Text style={styles.buttonText}>Próximo</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={styles.navButton}
            onPress={() => navigation.navigate('Login')}
          >
            <Text style={styles.buttonText}>Ir para o Login</Text>
          </TouchableOpacity>
        )}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    flex: 1,
  },
  image: {
    width: 300,
    height: 200,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    color: '#FFF',
    fontFamily: 'Poppins', // Fonte personalizada
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 20,
    color: '#FFF',
    fontFamily: 'Poppins', // Fonte personalizada
    textAlign: 'center',
    marginHorizontal: 20,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    position: 'absolute',
    bottom: 40,
  },
  navButton: {
    backgroundColor: '#FFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    marginTop: 20,
  },
  buttonText: {
    color: '#f46a14',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default TutorialScreen;
