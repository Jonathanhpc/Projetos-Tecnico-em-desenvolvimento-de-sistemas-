import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image, StatusBar } from 'react-native';
import { useFonts } from 'expo-font';
import { LinearGradient } from 'expo-linear-gradient';
import Checkbox from 'expo-checkbox';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; // Substitua pela sua URL do Supabase
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; // Substitua pela sua chave anônima do Supabase
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState(null);
  const roles = ['Profissional', 'Aluno', 'Instituição', 'Usuário Comum'];

  const handleLogin = async () => {
    if (!selectedRole) {
      Alert.alert('Erro', 'Por favor, selecione um papel.');
      return;
    }

    const tableMap = {
      'Profissional': 'profissional',
      'Aluno': 'alunos_instituicao',
      'Instituição': 'instituicoes',
      'Usuário Comum': 'alunos',
    };

    const tableName = tableMap[selectedRole];

    const { data, error } = await supabase
      .from(tableName)
      .select('*')
      .eq('email', email)
      .eq('senha', password)
      .single();

    if (error || !data) {
      Alert.alert('Erro', 'Email ou senha incorretos.');
      return;
    }

    // Armazenar os dados do usuário logado localmente
    try {
      await AsyncStorage.setItem('userData', JSON.stringify({ email: data.email, role: selectedRole }));
      Alert.alert('Sucesso', 'Login bem-sucedido!');
    } catch (error) {
      console.error('Erro ao salvar dados localmente:', error);
    }

    // Navegar para a tela apropriada com base no papel
    switch (selectedRole) {
      case 'Profissional':
        navigation.navigate('index_Profissional');
        break;
      case 'Instituição':
        navigation.navigate('IndexInstituicao');
        break;
      case 'Aluno':
        navigation.navigate('IndexAluno', { nome: data.nome });
        break;
      case 'Usuário Comum':
        navigation.navigate('IndexAluno');
        break;
      default:
        Alert.alert('Erro', 'Papel selecionado inválido.');
    }
  };

  const handleCheckboxChange = (role) => {
    setSelectedRole(role);
  };

  let [fontsLoaded] = useFonts({
    'Poppins': require('../../../assets/fontes/Poppins/Poppins-Regular.ttf'),
  });

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <LinearGradient colors={['#f46a14', '#f46a14']} style={styles.background}>
      <StatusBar barStyle="light-content" backgroundColor="#f46a14" />
      <View style={styles.container}>
        <View style={styles.logoContainer}>
          <Image 
            source={require('../Icons/LogoMax/logo.png')}
            style={styles.logoImage}
          />
        </View>
        
        <View style={styles.loginContainer}>
          <TextInput
            style={styles.input}
            placeholder="EMAIL"
            placeholderTextColor="#888888"
            value={email}
            onChangeText={setEmail}
          />
          <TextInput
            style={styles.input}
            placeholder="SENHA"
            placeholderTextColor="#888888"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />

          <View style={styles.checkboxContainer}>
            {roles.map(role => (
              <View key={role} style={styles.checkboxItem}>
                <Checkbox
                  style={styles.checkbox}
                  value={selectedRole === role}
                  onValueChange={() => handleCheckboxChange(role)}
                  color={selectedRole === role ? '#f46a14' : '#000'}
                />
                
                <Text style={[styles.checkboxText, selectedRole === role && styles.checkboxTextSelected]}>
                  {role}
                </Text>
                
              </View>
            ))}
          </View>
        </View>
          <TouchableOpacity onPress={() => navigation.navigate('RecuperarScreen')}>
          <Text style={styles.signupText}>Esqueceu a senha?</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('OpcaodeCadastro')}>
          <Text style={styles.signupText}>Não possui cadastro ainda? Clique aqui e cadastre-se</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <Text style={styles.buttonText}>ENTRAR</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  ); 
};
const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  logoContainer: {
    marginBottom: 20,
    alignItems: 'center',
    paddingRight: 80,
    paddingTop: 30,
  },
  logoImage: {
    width: 300,
    height: 100,
    resizeMode: 'contain',
  },
  loginContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    width: '80%',
    alignItems: 'center',
  },
  input: {
    width: '100%',
    height: 40,
    backgroundColor: '#d6cfcb',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginBottom: 15,
    color: '#000',
  },
  checkboxContainer: {
    width: '100%',
    marginBottom: 20,
  },
  checkboxItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: '#000',
  },
  checkboxText: {
    color: '#000',
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  checkboxTextSelected: {
    color: '#000',
  },
  signupText: {
    color: 'white',
    fontSize: 14,
    textDecorationLine: 'underline',
    marginTop: 20,
  },
  button: {
    width: '80%',
    height: 50,
    backgroundColor: '#FFFAFA',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: 'Black',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default LoginScreen;
