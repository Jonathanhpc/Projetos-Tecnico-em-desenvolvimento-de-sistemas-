import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const SignupScreen = ({ navigation }) => {
  return (
    <LinearGradient
      colors={['#f46a14', '#f46a14']}
      style={styles.background}
    >
      <View style={styles.container}>
        <View style={styles.logoContainer}>
          <Image 
            source={require('../Icons/LogoMax/logo.png')}
            style={styles.logoImage}
          />
        </View>

        <Text style={styles.tituloText}>Clique na Opção desejada:</Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('CadastroAluno')} style={styles.button}>
            <Image
              source={require('../Icons/icones/aluna.png')}
              style={styles.buttonImage}
            />
            <Text style={styles.buttonText}>Usuário Comum</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('CadastroInstituicao')} style={styles.button}>
            <Image
              source={require('../Icons/icones/coloridoescola.png')}
              style={styles.buttonImage}
            />
            <Text style={styles.buttonText}>Instituição</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('CadastroProfissional')} style={styles.button}>
            <Image
              source={require('../Icons/icones/professor.png')}
              style={styles.buttonImage}
            />
            <Text style={styles.buttonText}>Profissional</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.signupText}>Já possui cadastro? Clique aqui!</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  signupText: {
    color: 'white',
    fontSize: 14,  
    textDecorationLine: 'underline',
    marginTop: 20,
    textAlign: 'center',  
    paddingHorizontal: 10,  
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  logoContainer: {
    paddingRight: 70,
    marginBottom: 30,
    alignItems: 'center',
  },
  logoImage: {
    width: 300,
    height: 200,
    resizeMode: 'contain',
  },
  tituloText: {
    color: '#FFF',
    fontSize: 20,  
    fontWeight: 'bold',
    marginBottom: 20, 
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 20,  
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  button: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    padding: 10,
    width: '30%',
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  buttonImage: {
    width: 40,
    height: 40,
    marginBottom: 10,
  },
  buttonText: {
    fontSize: 11,
    color: '#333',
    fontWeight: 'bold',
  },
});

export default SignupScreen;
