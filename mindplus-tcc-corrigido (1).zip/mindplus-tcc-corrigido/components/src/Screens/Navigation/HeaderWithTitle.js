import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const HeaderWithTitle = () => (
  <View style={styles.headerContainer}>
    <Text style={styles.title}>Seu Título</Text>
  </View>
);

const styles = StyleSheet.create({
  headerContainer: {
    flex: 1,
    alignItems: 'center',
    paddingLeft:100,
    justifyContent: 'center',
 // Ajusta o espaçamento do topo, se necessário
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins', // Defina a fonte desejada
    color: 'white',
    textAlign: 'center',
  },
});

export default HeaderWithTitle;
