import React from 'react';
import { StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { LinearGradient } from 'expo-linear-gradient';
import OtherScreen from '../../Screens/OtherScreen';  // Uma tela adicional para teste

const Tab = createBottomTabNavigator();

function BottonTabNavigator() {
  return (
    
    <Tab.Navigator screenOptions={{
          tabBarStyle: styles.tabBar, // Estilo do tabBar
          
          tabBarLabelStyle: styles.tabBarLabel, // Adiciona estilo à label da tabBar
        }}>
      <Tab.Screen name="HomeTabs" component={Index} options={{ title: 'Tela inicial', headerShown: false  }} />
      <Tab.Screen name="Other" component={OtherScreen} options={{ title: 'Ajuda', headerShown: false  }} />
    </Tab.Navigator>
  );
}
const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: '#000',
    height: 50,
    borderColor: 'transparent' // Mantém o tabBar transparente
  },
  tabBarLabel: {
    color: 'white',
    fontFamily: 'Poppins', // Define a fonte Poppins
  },
});

export default BottonTabNavigator;
