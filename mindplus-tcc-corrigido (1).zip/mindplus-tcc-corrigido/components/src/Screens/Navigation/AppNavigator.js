import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';



import RecuperarScreen from '../../Screens/RecuperarScreen';
import LoginScreen from '../../Screens/LoginScreen';
import OpcaodeCadastro from '../../Screens/opcaoCadastro';
import ProfileScreen from '../../Screens/ProfileScreen';
import SettingsScreen from '../../Screens/SettingsScreen';
import SplashScreen from '../../Screens/HomeScreen';
import memoria from '../../Games/memoria/GameScreen';
import jogo_velha from '../../Games/velha/jogo_velha';
import index_jogos from '../../Games/index_jogos';


//
// Importações de telas de cadastro
import CadastroAluno from '../../Screens/CadastroAluno';
import CadastroInstituicao from '../../Screens/CadastroInstituicao';
import CadastroProfissional from '../../Screens/CadastroProfissional';

// Importações de telas por tipo de usuário
import tutorial from '../../Screens/tutorial/tutorial';
import IndexInstituicao from '../../Screens/instituicao/index_Instituicao';
import cadastro_turma from '../../Screens/instituicao/cadastro_turmas';
import IndexAluno from '../../Screens/Aluno/index_Usuariocomum';
import index_educacao from '../../Screens/materias/educacao/index_educacao';
import index_Profissional from '../../Screens/profissional/index_Profissional';
import gerenciar_aluno from '../../Screens/profissional/gerenciarAluno';

// Importações de telas de meditação
import meditacao from '../../Screens/Aluno/Meditacao/meditacao';
import bot from '../../Screens/Aluno/bot';
import meditacao_comum from '../../Screens/Usuario/Meditacao/meditacao_comum';
import controle from '../../Screens/Aluno/Meditacao/controle';
import controle_comum from '../../Screens/Usuario/Meditacao/controle_comum';
import energia from '../../Screens/Aluno/Meditacao/energia';
import energia_comum from '../../Screens/Usuario/Meditacao/energia_comum';
import foco from '../../Screens/Aluno/Meditacao/foco';
import foco_comum from '../../Screens/Usuario/Meditacao/foco_comum';

// Importações das telas de matérias
import comunidade from '../../Screens/materias/educacao/comunidade';
import matematica from '../../Screens/materias/educacao/matematica';
import quimica_basica from '../../Screens/materias/educacao/quimica_basica';
import matematica_basica from '../../Screens/materias/educacao/matematica_basica';
import matematica_intermediaria from '../../Screens/materias/educacao/matematica_intermediaria';
import matematica_avancada from '../../Screens/materias/educacao/matematica_avancada';
import biologia from '../../Screens/materias/educacao/biologia';
import biologia_basica from '../../Screens/materias/educacao/biologia_basica';
import biologia_intermediaria from '../../Screens/materias/educacao/biologia_intermediaria';
import biologia_avancada from '../../Screens/materias/educacao/biologia_avancada';
import quimica_intermediaria from '../../Screens/materias/educacao/quimica_intermediaria';
import quimica_avancada from '../../Screens/materias/educacao/quimica_avancada';
import quimica from '../../Screens/materias/educacao/quimica';
import portugues from '../../Screens/materias/educacao/portugues';
import portugues_basico from '../../Screens/materias/educacao/portugues_basico';
import portugues_intermediario from '../../Screens/materias/educacao/portugues_intermediario';
import portugues_avancado from '../../Screens/materias/educacao/portugues_avancado';
import redacao from '../../Screens/materias/educacao/redacao';
import redacao_avancada from '../../Screens/materias/educacao/redacao_avancada';
import redacao_intermediaria from '../../Screens/materias/educacao/redacao_intermediaria';
import redacao_basica from '../../Screens/materias/educacao/redacao_basica';
import geografia from '../../Screens/materias/educacao/geografia';
import geografia_basica from '../../Screens/materias/educacao/geografia_basica';
import geografia_intermediaria from '../../Screens/materias/educacao/geografia_intermediaria';
import geografia_avancada from '../../Screens/materias/educacao/geografia_avancada';
import fisica from '../../Screens/materias/educacao/fisica';
import fisica_basica from '../../Screens/materias/educacao/fisica_basica';
import fisica_intermediaria from '../../Screens/materias/educacao/fisica_intermediaria';
import fisica_avancada from '../../Screens/materias/educacao/fisica_avancada';
import ingles from '../../Screens/materias/educacao/ingles';
import ingles_basico from '../../Screens/materias/educacao/ingles_basico';
import ingles_intermediario from '../../Screens/materias/educacao/ingles_intermediario';
import ingles_avancado from '../../Screens/materias/educacao/ingles_avancado';

// Importações de gerenciamento e configuração
import gerenciamento from '../../Screens/instituicao/Gerenciamento';
import gerenciamentoaluno from '../../Screens/instituicao/GerenciamentoAluno';
import avaliacao from '../../Screens/instituicao/Avaliacao';
import configuracao from '../../Screens/instituicao/configuracao';

// Outros
import dicas from '../../Screens/materias/educacao/dicas';
import calendario from '../../Screens/materias/educacao/calendario';
import adicionar_aluno from '../../Screens/materias/educacao/adicionar_aluno';
import adicionar_professor from '../../Screens/materias/educacao/adicionar_professor';
import tarefas from '../../Screens/materias/educacao/tarefas';

// Quiz
import quiz_ingles from '../../Screens/materias/educacao/quiz_ingles';
import duvidas from '../../Screens/materias/educacao/duvidas';
import quiz_biologia from '../../Screens/materias/educacao/quiz_biologia';
import quiz_redacao from '../../Screens/materias/educacao/quiz_redacao';
import quiz_quimica from '../../Screens/materias/educacao/quiz_quimica';
import quiz_fisica from '../../Screens/materias/educacao/quiz_fisica';
import quiz_matematica from '../../Screens/materias/educacao/quiz_matematica';
import quiz_portugues from '../../Screens/materias/educacao/quiz_portugues';
import quiz_geografia from '../../Screens/materias/educacao/quiz_geografia';
import NewScreen1 from '../../cadastroprofissional2'; 
import cadastro_alunoinstituicao from '../../Screens/cadastro_alunoInstituicao'; 

// Importações das telas de progresso 
import progresso from '../../Screens/progresso/progresso';
import progresso_aluno from '../../Screens/progresso/progresso_aluno';
import progresso_turma from '../../Screens/progresso/progresso_turma';
import progresso2 from '../../Screens/progresso/progresso2';
import progresso_individual from '../../Screens/progresso/progresso_individual';
import progresso_alunoinst from '../../Screens/progresso/progresso_turmainst';
import index_progressoinst from '../../Screens/progresso/index_progressoinst';

  const Stack = createStackNavigator();

  const AppNavigator = () => {
    return (
      <NavigationContainer>
          


        <Stack.Navigator initialRouteName="Splash" screenOptions={{ headerShown: false }}>
         <Stack.Screen name="CadastroProfessor" component={NewScreen1} />
         <Stack.Screen 
  name="gerenciar_aluno" 
  component={gerenciar_aluno} 
  options={{ headerShown: false }} 
/>
<Stack.Screen 
  name="tutorial" 
  component={tutorial} 
  options={{ headerShown: false }} 
/>
<Stack.Screen 
  name="RecuperarScreen" 
  component={RecuperarScreen} 
  options={{ headerShown: false }} 
/>
<Stack.Screen 
  name="index_progressoinst" 
  component={index_progressoinst} 
  options={{ headerShown: false }} 
/>
<Stack.Screen 
  name="progresso_individual" 
  component={progresso_individual} 
  options={{ headerShown: false }} 
/>
<Stack.Screen 
  name="progresso.alunoinst" 
  component={progresso_alunoinst} 
  options={{ headerShown: false }} 
/>
<Stack.Screen 
  name="cadastro_alunoinstituicao" 
  component={cadastro_alunoinstituicao} 
  options={{ headerShown: false }} 
/>
<Stack.Screen 
  name="cadastro_turma" 
  component={cadastro_turma} 
  options={{ headerShown: false }} 
/>
        <Stack.Screen 
            name="duvidas" 
            component={duvidas} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="bot" 
            component={bot} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="comunidade" 
            component={comunidade} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="jogo_velha" 
            component={jogo_velha} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="progresso" 
            component={progresso} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="progresso2" 
            component={progresso2} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="progresso_aluno" 
            component={progresso_aluno} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="progresso_turma" 
            component={progresso_turma} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="tarefas" 
            component={tarefas} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="adicionar_professor" 
            component={adicionar_professor} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="adicionar_aluno" 
            component={adicionar_aluno} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="calendario" 
            component={calendario} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="quiz_quimica" 
            component={quiz_quimica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="quiz_ingles" 
            component={quiz_ingles} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="quiz_fisica" 
            component={quiz_fisica} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="quiz_matematica"  quiz_geografia
            component={quiz_matematica} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="quiz_portugues" 
            component={quiz_portugues} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="quiz_geografia" 
            component={quiz_geografia} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="OpcaodeCadastro" 
            component={OpcaodeCadastro} 
            options={{ headerShown: false }} 
          />
           <Stack.Screen 
            name="index_jogos" 
            component={index_jogos} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="quiz_redacao" 
            component={quiz_redacao} 
            options={{ headerShown: false }} 
          />
         <Stack.Screen 
            name="memoria" 
            component={memoria} 
            options={{ headerShown: false }} 
          />
      <Stack.Screen 
            name="Splash" 
            component={SplashScreen} 
            
          />
          <Stack.Screen 
            name="quimica_basica" 
            component={quimica_basica} 
            options={{ headerShown: false }} 
          />
         
          <Stack.Screen 
            name="quimica_intermediaria" 
            component={quimica_intermediaria} 
            options={{ headerShown: false }} 
          />
         
          <Stack.Screen 
            name="quimica_avancada" 
            component={quimica_avancada} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="quimica" 
            component={quimica} 
            options={{ headerShown: false }} 
          />
          
          <Stack.Screen 
            name="quiz_biologia" 
            component={quiz_biologia} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="configuracao" 
            component={configuracao} 
            options={{ headerShown: false }} 
          />
        
          <Stack.Screen 
            name="dicas" 
            component={dicas} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="portugues" 
            component={portugues} 
            options={{ headerShown: false }} 
          />
            <Stack.Screen 
            name="portugues_basico" 
            component={portugues_basico} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="portugues_intermediario" 
            component={portugues_intermediario} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="portugues_avancado" 
            component={portugues_avancado} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="redacao" 
            component={redacao} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="redacao_avancada" 
            component={redacao_avancada} 
            options={{ headerShown: false }} 
          />
            <Stack.Screen 
            name="redacao_intermediaria" 
            component={redacao_intermediaria} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="redacao_basica" 
            component={redacao_basica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="geografia" 
            component={geografia} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="geografia_basica" 
            component={geografia_basica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="geografia_intermediaria" 
            component={geografia_intermediaria} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="geografia_avancada" 
            component={geografia_avancada} 
            options={{ headerShown: false }} 
          />
          
          <Stack.Screen 
            name="fisica" 
            component={fisica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="fisica_basica" 
            component={fisica_basica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="fisica_intermediaria" 
            component={fisica_intermediaria} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="fisica_avancada" 
            component={fisica_avancada} 
            options={{ headerShown: false }} 
          />
          
            <Stack.Screen 
            name="ingles" 
            component={ingles} 
            options={{ headerShown: false }} 
          />
            <Stack.Screen 
            name="ingles_basico" 
            component={ingles_basico} 
            options={{ headerShown: false }} 
          />
            <Stack.Screen 
            name="ingles_intermediario" 
            component={ingles_intermediario} 
            options={{ headerShown: false }} 
          />
            <Stack.Screen 
            name="ingles_avancado" 
            component={ingles_avancado} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="biologia" 
            component={biologia} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="biologia_basica" 
            component={biologia_basica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="biologia_intermediaria" 
            component={biologia_intermediaria} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="biologia_avancada" 
            component={biologia_avancada} 
            options={{ headerShown: false }} 
          />
          
          {/* Tela de Login */}
          <Stack.Screen 
            name="Login" 
            component={LoginScreen} 
            options={{ headerShown: false }} 
          />
          
          {/* Outras telas de cadastro */}
          <Stack.Screen 
            name="CadastroAluno" 
            component={CadastroAluno} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="CadastroInstituicao" 
            component={CadastroInstituicao} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="CadastroProfissional" 
            component={CadastroProfissional} 
            options={{ headerShown: false }} 
          />
          
          {/* Telas de index */}
          <Stack.Screen 
            name="IndexAluno" 
            component={IndexAluno} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="index_Profissional" 
            component={index_Profissional} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="IndexInstituicao" 
            component={IndexInstituicao} 
            options={{ headerShown: false }} 
          />
          
          {/* Telas de gerenciamento */}
          <Stack.Screen 
            name="gerenciamento" 
            component={gerenciamento} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="gerenciamentoaluno" 
            component={gerenciamentoaluno} 
            options={{ headerShown: false }} 
          />
          
          {/* Telas de avaliação */}
          <Stack.Screen 
            name="avaliacao" 
            component={avaliacao} 
            options={{ headerShown: false }} 
          />
          
          {/* Telas de educação */}
         
          <Stack.Screen 
            name="index_educacao" 
            component={index_educacao} 
            options={{ headerShown: false }} 
          />
          
          {/* Telas de matérias */}
          <Stack.Screen 
            name="matematica" 
            component={matematica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="matematica_basica" 
            component={matematica_basica} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="matematica_intermediaria" 
            component={matematica_intermediaria} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="matematica_avancada" 
            component={matematica_avancada} 
            options={{ headerShown: false }} 
          />
          
          {/* Telas de foco e energia */}
          <Stack.Screen 
            name="foco" 
            component={foco} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="foco_comum" 
            component={foco_comum} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="energia" 
            component={energia} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="energia_comum" 
            component={energia_comum} 
            options={{ headerShown: false }} 
          />
          
          {/* Telas de controle e meditação */}
          <Stack.Screen 
            name="controle" 
            component={controle} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="controle_comum" 
            component={controle_comum} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="meditacao" 
            component={meditacao} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="meditacao_comum" 
            component={meditacao_comum} 
            options={{ headerShown: false }} 
          />
          
          {/* Outras telas */}
          <Stack.Screen 
            name="ProfileScreen" 
            component={ProfileScreen} 
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="SettingsScreen" 
            component={SettingsScreen} 
            options={{ headerShown: false }} 
          />
          </Stack.Navigator>
      </NavigationContainer>
    );
  };
  export default AppNavigator;
