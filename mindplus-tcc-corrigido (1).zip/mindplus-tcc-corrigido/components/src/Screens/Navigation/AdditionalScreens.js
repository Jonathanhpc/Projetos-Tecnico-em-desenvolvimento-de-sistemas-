import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import NewScreen1 from '../../cadastroprofissional2'; 


const Stack = createStackNavigator();

function AdditionalScreens() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="NewScreen1" component={NewScreen1} />
      
    </Stack.Navigator>
  );
}

export default AdditionalScreens;
