import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const IntermediateEnglishScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const goBack = () => {
    navigation.goBack();
  };

  const showSidebar = () => setSidebar(prev => !prev);

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Inglês Intermediário
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Present Perfect</Text>{"\n"}
                - Explicação: O Present Perfect é usado para falar de ações que começaram no passado e têm relação com o presente. Usa-se o verbo auxiliar "have" ou "has" seguido do particípio passado do verbo principal.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                I have visited many countries. (Eu visitei muitos países.){"\n"}
                She has lived here since 2010. (Ela mora aqui desde 2010.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Past Continuous</Text>{"\n"}
                - Explicação: O Past Continuous descreve ações que estavam ocorrendo em um momento específico do passado. Ele é formado pelo verbo "was" ou "were" seguido do verbo principal com "ing".
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                They were watching TV when I arrived. (Eles estavam assistindo TV quando eu cheguei.){"\n"}
                I was studying when the phone rang. (Eu estava estudando quando o telefone tocou.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Comparativos e Superlativos</Text>{"\n"}
                - Explicação: Usamos os comparativos para comparar duas coisas e os **superlativos** para destacar algo como o "mais" entre todos. Em geral, adicionamos "-er" para comparativos e "-est" para superlativos, ou usamos "more" e "most" com palavras mais longas.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                This book is better than that one. (Este livro é melhor que aquele.){"\n"}
                He is the tallest in the class. (Ele é o mais alto da turma.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Modal Verbs</Text>{"\n"}
                - Explicação: Os Modal Verbs como "can", "could", "may", "might", "must", "shall", "should", "will" e "would" expressam possibilidades, habilidades, permissões e obrigações.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                You should study more. (Você deveria estudar mais.){"\n"}
                He can speak three languages. (Ele pode falar três idiomas.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>5. Phrasal Verbs</Text>{"\n"}
                - Explicação: Os Phrasal Verbs são combinações de verbo + preposição ou advérbio que mudam o significado original do verbo. Eles são muito comuns no inglês falado e escrito.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                She gave up smoking. (Ela desistiu de fumar.){"\n"}
                Let's hang out tonight. (Vamos sair hoje à noite.)
                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                Estes tópicos são fundamentais para entender e se comunicar em um nível intermediário de inglês. Com prática constante, você irá dominar essas estruturas e aumentar sua confiança ao falar e escrever.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default IntermediateEnglishScreen;
