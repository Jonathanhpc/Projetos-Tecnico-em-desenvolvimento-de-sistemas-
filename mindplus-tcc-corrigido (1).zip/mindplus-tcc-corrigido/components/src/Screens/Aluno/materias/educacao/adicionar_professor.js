import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert, Modal, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const ProfessorScreen = () => {
  const navigation = useNavigation();
  const [professors, setProfessors] = useState([]);
  const [professorName, setProfessorName] = useState('');
  const [editProfessorIndex, setEditProfessorIndex] = useState(null);
  const [details, setDetails] = useState({ subject: '', schedule: '', room: '' });
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [sidebar, setSidebar] = useState(false);
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const handleAddProfessor = () => {
    if (professorName.trim() === '') {
      Alert.alert('Erro', 'Digite o nome do professor.');
      return;
    }

    const newProfessor = { name: professorName, details: { ...details } };
    setProfessors([...professors, newProfessor]);
    setProfessorName('');
    setDetails({ subject: '', schedule: '', room: '' });
    setIsModalVisible(false);
  };

  const handleEditProfessor = () => {
    if (professorName.trim() === '') {
      Alert.alert('Erro', 'Digite o nome do professor.');
      return;
    }

    const updatedProfessors = [...professors];
    updatedProfessors[editProfessorIndex] = { name: professorName, details: { ...details } };
    setProfessors(updatedProfessors);
    setProfessorName('');
    setDetails({ subject: '', schedule: '', room: '' });
    setEditProfessorIndex(null);
    setIsModalVisible(false);
  };

  const handleDeleteProfessor = (index) => {
    const updatedProfessors = professors.filter((_, i) => i !== index);
    setProfessors(updatedProfessors);
  };

  const handleOpenEditModal = (index) => {
    const professor = professors[index];
    setProfessorName(professor.name);
    setDetails({ ...professor.details });
    setEditProfessorIndex(index);
    setIsModalVisible(true);
  };

  const openDrawer = () => {
    setSidebar(prev => !prev);
  };

  return (
    <View style={styles.container}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.navButton}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>

        <TouchableOpacity onPress={openDrawer} style={styles.navButton}>
          <Ionicons name="menu" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      {sidebar && (
        <View style={styles.sidebar}>
          <View style={styles.userContainer}>
            <Image
              source={{ uri: user.photo }}
              style={styles.userPhoto}
            />
            <Text style={styles.userName}>{user.name}</Text>
          </View>

          <TouchableOpacity onPress={() => navigation.navigate('Configuracao')} style={styles.sidebarButton}>
            <Text style={styles.sidebarButtonText}>Configuração</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Avaliacao')} style={styles.sidebarButton}>
            <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Login')} style={styles.sidebarButton}>
            <Text style={styles.sidebarButtonText}>Logout</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.content}>
        <Text style={styles.title}>Gerenciar Professores</Text>

        <TouchableOpacity style={styles.addButton} onPress={() => setIsModalVisible(true)}>
          <Text style={styles.addButtonText}>Adicionar Professor</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={professors}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.professorItem}>
            <View style={styles.professorDetails}>
              <Text style={styles.professorName}>{item.name}</Text>
              <Text style={styles.professorInfo}>
                Matéria: {item.details.subject} | Horário: {item.details.schedule} | Sala: {item.details.room}
              </Text>
            </View>

            <View style={styles.actions}>
              <TouchableOpacity onPress={() => handleOpenEditModal(index)}>
                <Ionicons name="pencil" size={24} color="#FF6F00" />
              </TouchableOpacity>

              <TouchableOpacity onPress={() => handleDeleteProfessor(index)}>
                <Ionicons name="trash" size={24} color="#FF6F00" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      <Modal
        visible={isModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setIsModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {editProfessorIndex !== null ? 'Editar Professor' : 'Adicionar Professor'}
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Nome do Professor"
              value={professorName}
              onChangeText={setProfessorName}
            />

            <TextInput
              style={styles.input}
              placeholder="Matéria"
              value={details.subject}
              onChangeText={(text) => setDetails({ ...details, subject: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Horário"
              value={details.schedule}
              onChangeText={(text) => setDetails({ ...details, schedule: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Sala"
              value={details.room}
              onChangeText={(text) => setDetails({ ...details, room: text })}
            />

            <TouchableOpacity
              style={styles.button}
              onPress={editProfessorIndex !== null ? handleEditProfessor : handleAddProfessor}
            >
              <Text style={styles.buttonText}>
                {editProfessorIndex !== null ? 'Salvar' : 'Adicionar'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.button, { backgroundColor: '#999' }]}
              onPress={() => setIsModalVisible(false)}
            >
              <Text style={styles.buttonText}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF6F00',
    marginBottom: 20,
    textAlign: 'center',
  },
  navBar: {
    width: '100%',
    height: 50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    paddingHorizontal: 10,
    elevation: 4,
  },
  navButton: {
    padding: 10,
  },
  addButton: {
    backgroundColor: '#FF6F00',
    padding: 12,
    borderRadius: 5,
    marginBottom: 20,
    width: '90%',
    alignSelf: 'center',
    alignItems: 'center',
    elevation: 2,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  professorItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#FFF',
    borderRadius: 10,
    marginBottom: 10,
    elevation: 2,
    width: '90%',
    alignSelf: 'center',
  },
  professorDetails: {
    flex: 1,
  },
  professorName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  professorInfo: {
    fontSize: 14,
    color: '#555',
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#FF6F00',
    borderRadius: 5,
    padding: 10,
    width: '100%',
    marginBottom: 10,
    backgroundColor: '#FFF',
  },
  button: {
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  sidebar: {
    position: 'absolute',
    top: 50,
    left: 0,
    width: '80%',
    height: '100%',
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
    elevation: 4,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  userPhoto: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: 10,
    marginVertical: 5,
    backgroundColor: '#FF6F00',
    borderRadius: 5,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: 16,
    color: '#FFF',
  },
});

export default ProfessorScreen;
