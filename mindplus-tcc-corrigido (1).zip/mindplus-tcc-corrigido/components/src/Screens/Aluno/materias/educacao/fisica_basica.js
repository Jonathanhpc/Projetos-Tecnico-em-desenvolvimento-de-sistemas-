import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const BasicPhysicsScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Física Básica
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Leis de Newton</Text>{"\n"}
                - Explicação: As Leis de Newton descrevem o movimento dos corpos e as forças que atuam sobre eles. A primeira lei é a Lei da Inércia, a segunda lei relaciona força, massa e aceleração, e a terceira lei afirma que para toda ação há uma reação igual e oposta.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                Um livro em repouso sobre uma mesa permanecerá em repouso até que uma força externa o mova, de acordo com a primeira lei de Newton.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Gravitação</Text>{"\n"}
                - Explicação: A Lei da Gravitação Universal de Newton afirma que cada partícula do universo atrai todas as outras com uma força que é diretamente proporcional ao produto de suas massas e inversamente proporcional ao quadrado da distância entre seus centros.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                A força que faz com que um objeto caia em direção ao chão é a força gravitacional.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Trabalho e Energia</Text>{"\n"}
                - Explicação: Trabalho é a força aplicada sobre um objeto multiplicada pela distância que ele se move. **Energia** é a capacidade de realizar trabalho. A energia pode ser cinética, potencial, entre outras.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                Levantar um objeto contra a gravidade é um exemplo de trabalho realizado.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Lei da Conservação da Energia</Text>{"\n"}
                - Explicação: A Lei da Conservação da Energia afirma que a energia não pode ser criada nem destruída, apenas transformada de uma forma para outra.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                Quando um objeto em queda ganha energia cinética, ele perde energia potencial.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>5. Ondas</Text>{"\n"}
                - Explicação: Ondas são perturbações que se propagam através de um meio ou do espaço. Podem ser ondas mecânicas, como as ondas sonoras, ou ondas eletromagnéticas, como a luz.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                O som que ouvimos é uma onda mecânica que se propaga pelo ar.
                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                Esses conceitos básicos são fundamentais para entender o comportamento dos corpos e as forças que atuam sobre eles. Eles formam a base para estudos mais avançados na física.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default BasicPhysicsScreen;
