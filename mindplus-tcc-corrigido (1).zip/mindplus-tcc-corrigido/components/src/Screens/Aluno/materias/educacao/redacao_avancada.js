import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const AdvancedWritingScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Redação Avançada
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Argumentação Complexa</Text>{"\n"}
                - Estrutura Argumentativa: Construir argumentos complexos requer uma estrutura sólida com evidências robustas e raciocínio lógico. Exemplo: integrar dados empíricos e teorias existentes.
                {"\n"}{"\n"}
                - Perspectivas Contrastantes: Abordar múltiplas perspectivas e fornecer uma análise crítica das contradições. Exemplo: comparar diferentes pontos de vista sobre um tema controverso.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Técnicas de Persuasão</Text>{"\n"}
                - Retórica Avançada: Utilizar técnicas retóricas como ethos, pathos e logos para persuadir o leitor de forma eficaz. Exemplo: apelar à ética, emoções e lógica em um argumento.
                {"\n"}{"\n"}
                - Narrativas e Exemplos: Integrar histórias e exemplos complexos que reforçam o argumento principal. Exemplo: usar estudos de caso detalhados para ilustrar um ponto.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Análise Crítica</Text>{"\n"}
                - Avaliação de Fontes: Criticar e avaliar a credibilidade e relevância das fontes utilizadas. Exemplo: analisar a autoridade e o viés das fontes citadas.
                {"\n"}{"\n"}
                - Interpretação de Dados: Interpretar e contextualizar dados e pesquisas para fortalecer o argumento. Exemplo: explorar gráficos e estatísticas e relacioná-los com a tese.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Coerência e Coesão Avançadas</Text>{"\n"}
                - Estrutura de Parágrafos: Desenvolver parágrafos de forma que cada um contribua para a construção do argumento geral. Exemplo: criar transições sofisticadas entre parágrafos e seções.
                {"\n"}{"\n"}
                - Coesão Textual: Utilizar técnicas avançadas de coesão, como a repetição controlada e a referência cruzada. Exemplo: garantir que o texto tenha uma fluidez contínua e lógica.

                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                A redação avançada envolve a aplicação de técnicas sofisticadas para criar textos bem fundamentados e persuasivos. A prática contínua e a análise crítica são essenciais para alcançar a excelência na escrita.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default AdvancedWritingScreen;
