import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, Modal, TextInput, Image, ImageBackground, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; 
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; 
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);


const { width } = Dimensions.get('window');
const daysOfWeek = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const generateDays = (month, year) => {
  // Função para gerar os dias do mês atual e bordas
  const days = [];
  const firstDay = new Date(year, month, 1).getDay();
  const date = new Date(year, month, 1);
  if (firstDay > 0) {
    const prevMonthDays = new Date(year, month, 0).getDate();
    for (let i = prevMonthDays - firstDay + 1; i <= prevMonthDays; i++) {
      days.push(new Date(year, month - 1, i));
    }
  }
  while (date.getMonth() === month) {
    days.push(new Date(date));
    date.setDate(date.getDate() + 1);
  }
  const lastDay = new Date(year, month + 1, 0).getDay();
  if (lastDay < 6) {
    for (let i = 1; i <= 6 - lastDay; i++) {
      days.push(new Date(year, month + 1, i));
    }
  }
  return days;
};

const CalendarScreen = () => {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  const [note, setNote] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [user, setUser] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    fetchUser();
    fetchTasksForMonth();
  }, [currentMonth, currentYear]);

  const fetchUser = async () => {
    // Verifique o usuário logado
    const { data: { user } } = await supabase.auth.getUser();
    setUser(user);
  };

  const fetchTasksForMonth = async () => {
    // Carregar tarefas do Supabase
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('user_id', user.id)
      .ilike('date', `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-%`);
    if (error) console.error(error);
    else setTasks(data);
  };

  const handleSaveTask = async () => {
    if (selectedDate && selectedColor && note) {
      const { data, error } = await supabase.from('tasks').insert([
        { user_id: user.id, date: selectedDate, note, color: selectedColor }
      ]);
      if (error) console.error(error);
      else setTasks([...tasks, data[0]]);
      setIsModalVisible(false);
      setSelectedColor(null);
      setNote('');
    }
  };

  const handleDeleteTask = async (id) => {
    const { error } = await supabase.from('tasks').delete().eq('id', id);
    if (error) console.error(error);
    else setTasks(tasks.filter(task => task.id !== id));
  };

  const handleEditTask = (task) => {
    setSelectedDate(new Date(task.date));
    setSelectedColor(task.color);
    setNote(task.note);
    setIsModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <ImageBackground source={require('../../../../Images/fundo.png')} style={styles.background}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.headerButton}>
            <Ionicons name="chevron-back" size={24} color="#FFF" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Calendário</Text>
          <TouchableOpacity onPress={() => {/* Sidebar */}} style={styles.headerButton}>
            <Ionicons name="ellipsis-vertical" size={24} color="#FFF" />
          </TouchableOpacity>
        </View>

        <View style={styles.calendarContainer}>
          {/* Mês e ano com botões */}
          <FlatList
            data={tasks}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View style={styles.taskContainer}>
                <Text style={styles.taskText}>{item.date}: {item.note}</Text>
                <View style={styles.taskActions}>
                  <TouchableOpacity onPress={() => handleEditTask(item)}>
                    <Ionicons name="pencil" size={20} color="#FFA500" />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleDeleteTask(item.id)}>
                    <Ionicons name="trash" size={20} color="#FF0000" />
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  background: { flex: 1, resizeMode: 'cover' },
  header: { flexDirection: 'row', justifyContent: 'space-between', padding: 16, backgroundColor: '#FF6F00' },
  headerButton: { padding: 8 },
  headerTitle: { color: '#FFF', fontSize: 20, fontWeight: 'bold' },
  calendarContainer: { flex: 1, margin: 10, padding: 10, backgroundColor: '#FFF', borderRadius: 10, shadowColor: '#000', shadowOpacity: 0.2 },
  taskContainer: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 10,
    backgroundColor: '#f0f0f0', borderRadius: 5, marginVertical: 5, shadowColor: '#FFA500', shadowOpacity: 0.8, shadowRadius: 3
  },
  taskText: { fontSize: 16 },
  taskActions: { flexDirection: 'row', gap: 10 }
});

export default CalendarScreen;
