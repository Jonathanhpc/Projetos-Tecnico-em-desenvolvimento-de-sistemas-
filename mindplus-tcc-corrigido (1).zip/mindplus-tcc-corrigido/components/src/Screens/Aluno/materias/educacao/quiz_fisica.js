import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const QuizScreen = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isCorrect, setIsCorrect] = useState(null);
  const [score, setScore] = useState(0);
  const [errors, setErrors] = useState(0);
  const [isQuizFinished, setIsQuizFinished] = useState(false);

 const questions = [
  {    
    question: 'Qual é a unidade de medida da força no Sistema Internacional de Unidades (SI)?',
    options: ['A) Joule', 'B) Newton', 'C) Watt', 'D) Pascal'],
    answer: 'B) Newton',
  },
  {
    question: 'Qual é a fórmula da segunda lei de Newton?',
    options: ['A) F = m * a', 'B) E = m * c²', 'C) P = F / A', 'D) V = d / t'],
    answer: 'A) F = m * a',
  },
  {
    question: 'O que é a energia cinética?',
    options: ['A) Energia armazenada em um corpo parado', 'B) Energia associada ao movimento de um corpo', 'C) Energia gerada pela compressão de um gás', 'D) Energia térmica de um sistema'],
    answer: 'B) Energia associada ao movimento de um corpo',
  },
  {
    question: 'Qual das grandezas abaixo é uma unidade de potência?',
    options: ['A) Joule', 'B) Pascal', 'C) Watt', 'D) Volt'],
    answer: 'C) Watt',
  },
  {
    question: 'Qual é a velocidade da luz no vácuo?',
    options: ['A) 3 x 10^8 m/s', 'B) 3 x 10^6 m/s', 'C) 3 x 10^5 m/s', 'D) 3 x 10^9 m/s'],
    answer: 'A) 3 x 10^8 m/s',
  },
  {
    question: 'Qual é a definição de inércia?',
    options: ['A) Capacidade de um corpo realizar trabalho', 'B) Tendência de um corpo de permanecer em seu estado de repouso ou movimento uniforme', 'C) Capacidade de um corpo de resistir à deformação', 'D) Tendência de um corpo de variar sua aceleração'],
    answer: 'B) Tendência de um corpo de permanecer em seu estado de repouso ou movimento uniforme',
  },
  {
    question: 'Qual das opções abaixo representa a Lei da Conservação da Energia?',
    options: ['A) A energia total de um sistema isolado permanece constante', 'B) A força resultante sobre um corpo é sempre nula', 'C) O trabalho realizado por uma força é sempre positivo', 'D) A quantidade de movimento de um corpo permanece constante'],
    answer: 'A) A energia total de um sistema isolado permanece constante',
  },
  {
    question: 'Qual é a diferença entre calor e temperatura?',
    options: ['A) Calor é uma forma de energia, enquanto temperatura é uma medida dessa energia', 'B) Temperatura é o mesmo que calor', 'C) Calor é a capacidade térmica de um objeto, enquanto temperatura é a quantidade de calor armazenado', 'D) Não há diferença entre calor e temperatura'],
    answer: 'A) Calor é uma forma de energia, enquanto temperatura é uma medida dessa energia',
  },
  {
    question: 'Qual é a fórmula para calcular o trabalho mecânico?',
    options: ['A) T = F / d', 'B) T = F * d * cos(θ)', 'C) T = m * a * t', 'D) T = P / A'],
    answer: 'B) T = F * d * cos(θ)',
  },
  {
    question: 'Qual é a aceleração gravitacional média na Terra?',
    options: ['A) 9,8 m/s²', 'B) 10 m/s²', 'C) 8,9 m/s²', 'D) 9,2 m/s²'],
    answer: 'A) 9,8 m/s²',
  },
];



  const handleAnswer = (option) => {
    if (isCorrect === null) { 
      const correct = option === questions[currentQuestion].answer;
      setIsCorrect(correct);

      if (correct) {
        setScore(score + 1); 
      } else {
        setErrors(errors + 1); 
      }
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion + 1 < questions.length) {
      setIsCorrect(null);
      setCurrentQuestion((prev) => prev + 1);
    } else {
      setIsQuizFinished(true);
    }
  };

  const getFinalMessage = () => {
    const percentage = (score / questions.length) * 100;

    if (percentage >= 80) {
      return 'Parabéns, você foi incrível!';
    } else if (percentage >= 50) {
      return 'Muito bem, mas podemos melhorar!';
    } else {
      return 'Estude mais um pouquinho!';
    }
  };

  return (
    <LinearGradient colors={['#ffe0b2', '#ff9800']} style={styles.background}>
      <View style={styles.container}>
        {isQuizFinished ? (
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>Quiz finalizado!</Text>
            <Text style={styles.resultText}>Acertos: {score}</Text>
            <Text style={styles.resultText}>Erros: {errors}</Text>
            <Text style={styles.resultMessage}>{getFinalMessage()}</Text>
          </View>
        ) : (
          <>
            <Text style={styles.question}>{questions[currentQuestion].question}</Text>
            
            <View style={styles.optionsContainer}>
              {questions[currentQuestion].options.map((option, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.optionButton, isCorrect !== null && styles.disabledOption]}
                  onPress={() => handleAnswer(option)}
                  disabled={isCorrect !== null}
                >
                  <Text style={styles.optionText}>{option}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {isCorrect !== null && (
              <Text style={isCorrect ? styles.correct : styles.incorrect}>
                {isCorrect ? 'Acertou!' : 'Errou!'}
              </Text>
            )}

            {isCorrect !== null && (
              <TouchableOpacity style={styles.nextButton} onPress={handleNextQuestion}>
                <Text style={styles.nextButtonText}>Próxima pergunta</Text>
              </TouchableOpacity>
            )}
          </>
        )}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginHorizontal: 20,
    elevation: 10, 
    shadowColor: '#FF6F00',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  question: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  optionsContainer: {
    marginBottom: 20,
  },
  optionButton: {
    backgroundColor: '#FF6F00',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  disabledOption: {
    backgroundColor: '#d3d3d3',
  },
  optionText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  correct: {
    fontSize: 22,
    color: '#4caf50',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  incorrect: {
    fontSize: 22,
    color: '#f44336',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  nextButton: {
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  nextButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  resultContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  resultMessage: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ff9800',
    marginTop: 20,
    textAlign: 'center',
  },
});

export default QuizScreen;
