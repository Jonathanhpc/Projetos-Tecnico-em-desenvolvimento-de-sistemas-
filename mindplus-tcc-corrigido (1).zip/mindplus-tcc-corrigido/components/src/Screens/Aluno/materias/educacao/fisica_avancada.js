import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const AdvancedPhysicsScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Física Avançada
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Mecânica Quântica</Text>{"\n"}
                - Explicação: A Mecânica Quântica descreve o comportamento de partículas subatômicas. Ela aborda fenômenos como a dualidade onda-partícula e o princípio da incerteza de Heisenberg.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                O experimento da dupla fenda mostra que os elétrons exibem comportamentos de onda e de partícula, dependendo da forma como são observados.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Relatividade Geral</Text>{"\n"}
                - Explicação: A Relatividade Geral de Einstein trata da gravidade como uma curvatura do espaço-tempo causada pela massa e energia, substituindo a visão clássica de Newton.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                A órbita de Mercúrio é explicada de forma mais precisa pela relatividade geral, devido à sua proximidade com o sol e os efeitos intensos da gravidade.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Termodinâmica Avançada</Text>{"\n"}
                - Explicação: A Termodinâmica Avançada explora os princípios de energia e calor em sistemas fechados e abertos, com aplicações em motores, bombas de calor e reações químicas.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                A segunda lei da termodinâmica afirma que a entropia de um sistema isolado sempre aumenta, o que explica porque a energia útil tende a se dissipar com o tempo.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Eletromagnetismo</Text>{"\n"}
                - Explicação: O Eletromagnetismo envolve o estudo de campos elétricos e magnéticos e suas interações. Ele é governado pelas equações de Maxwell, que unificam as teorias de eletricidade e magnetismo.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                A indução eletromagnética, que permite a conversão de energia mecânica em elétrica, é a base de geradores e transformadores.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>5. Física de Partículas</Text>{"\n"}
                - Explicação: A Física de Partículas estuda as menores partículas do universo, como quarks e léptons, além das forças fundamentais que as governam, como a força nuclear forte e fraca.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                O Bóson de Higgs, descoberto em 2012, é uma partícula fundamental que dá massa a outras partículas por meio do campo de Higgs.
                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                Esses conceitos representam áreas avançadas da física e são essenciais para entender os fundamentos do universo, da escala subatômica até a cosmologia.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default AdvancedPhysicsScreen;
