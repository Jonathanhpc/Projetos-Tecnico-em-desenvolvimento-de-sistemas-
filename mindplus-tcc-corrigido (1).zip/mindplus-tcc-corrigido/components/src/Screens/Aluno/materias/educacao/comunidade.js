import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, Image, StyleSheet, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; 
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; 
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const CommunityScreen = ({ route }) => {
  const [messages, setMessages] = useState([]);
  const [comments, setComments] = useState([]);
  const [isCommentModalVisible, setIsCommentModalVisible] = useState(false);
  const [comment, setComment] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [userProfile, setUserProfile] = useState({});  // User profile state
  const [currentMessageId, setCurrentMessageId] = useState(null);
  const [likedMessages, setLikedMessages] = useState({});
  const [isMessageModalVisible, setIsMessageModalVisible] = useState(false);

  const fetchUserProfile = useCallback(async () => {
    const { email } = route.params;

    const { data, error } = await supabase.from('alunos').select('nome, foto_perfil').eq('email', email).single();
    if (error) {
      console.error('Erro ao buscar perfil do usuário:', error);
      setUserProfile({ nome: 'Usuário Anônimo', foto_perfil: null });
    } else {
      setUserProfile(data || { nome: 'Usuário Anônimo', foto_perfil: null });
    }
  }, [route.params]); // Adicione route.params como dependência se precisar

  useEffect(() => {
    fetchMessages();
    fetchUserProfile();
  }, [fetchUserProfile]); // Aqui você inclui a função fetchUserProfile como dependência

  // Função para buscar as mensagens
  const fetchMessages = async () => {
    const { data, error } = await supabase.from('messages').select('*');
    if (error) {
      console.error('Erro ao buscar mensagens:', error);
    } else {
      setMessages(data);
    }
  };
  const handleAddComment = async () => {
    if (comment.trim()) {
      await supabase.from('comments').insert([{ content: comment, user_name: userProfile.nome, message_id: currentMessageId }]);
      setComment('');
      fetchComments(currentMessageId);
    }
  };

  const fetchComments = async (messageId) => {
    const { data, error } = await supabase.from('comments').select('*').eq('message_id', messageId);
    if (error) {
      console.error('Erro ao buscar comentários:', error);
    } else {
      setComments(data);
    }
  };

  const handleAddMessage = async () => {
    if (newMessage.trim()) {
      const { data, error } = await supabase.from('messages').insert([{ content: newMessage, user_name: userProfile.nome, user_photo: userProfile.foto_perfil }]);
      if (error) {
        console.error('Erro ao adicionar mensagem:', error);
      } else {
        setNewMessage('');
        setIsMessageModalVisible(false);
        fetchMessages();
      }
    }
  };

  const handleLikeMessage = async (messageId) => {
    const currentLiked = likedMessages[messageId];
    setLikedMessages((prev) => ({ ...prev, [messageId]: !currentLiked }));

    const message = messages.find(msg => msg.id === messageId);
    const newLikes = currentLiked ? (message.likes || 0) - 1 : (message.likes || 0) + 1;

    await supabase
      .from('messages')
      .update({ likes: newLikes })
      .eq('id', messageId);
    fetchMessages();
  };

  const filteredMessages = messages.filter(message => 
    message.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => {/* Lógica para voltar */}}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.navTitle}>Comunidade</Text>
        <TouchableOpacity>
          <Ionicons name="ellipsis-vertical" size={24} color="white" />
        </TouchableOpacity>
      </View>

      <TextInput
        style={styles.searchInput}
        placeholder="Pesquisar mensagem..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />

      <FlatList
        data={filteredMessages}
        keyExtractor={(item) => item.id.toString()}
        style={styles.messageList}
        renderItem={({ item }) => (
          <View style={styles.messageItem}>
            <View style={styles.userContainer}>
              <Image source={{ uri: item.user_photo || userProfile.foto_perfil }} style={styles.userPhoto} />
              <Text style={styles.messageUser}>{item.user_name || userProfile.nome}</Text>
            </View>
            <Text style={styles.messageContent}>{item.content}</Text>
            <View style={styles.actions}>
              <TouchableOpacity onPress={() => handleLikeMessage(item.id)}>
                <Ionicons 
                  name={likedMessages[item.id] ? "heart" : "heart-outline"} 
                  size={20} 
                  color={likedMessages[item.id] ? "#FF6F00" : "black"} 
                />
              </TouchableOpacity>
              <Text style={styles.likeCount}>{item.likes || 0} curtidas</Text>
              <TouchableOpacity style={styles.commentButton} onPress={() => { 
                setIsCommentModalVisible(true); 
                setCurrentMessageId(item.id); 
                fetchComments(item.id); 
              }}>
                <Ionicons name="chatbubble-outline" size={20} color="black" />
              </TouchableOpacity>
              <Text style={styles.commentCount}>{item.comments || 0} comentários</Text>
            </View>
          </View>
        )}
      />

      <TouchableOpacity style={styles.fab} onPress={() => setIsMessageModalVisible(true)}>
        <Ionicons name="add" size={24} color="#fff" />
      </TouchableOpacity>

      {/* Modal de Nova Mensagem */}
      <Modal
        visible={isMessageModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setIsMessageModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.commentTitle}>Nova Mensagem</Text>
            <TextInput
              style={styles.input}
              placeholder="Digite sua mensagem..."
              value={newMessage}
              onChangeText={setNewMessage}
            />
            <TouchableOpacity onPress={handleAddMessage} style={styles.sendButton}>
              <Text style={styles.buttonText}>Enviar</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setIsMessageModalVisible(false)} style={styles.closeButton}>
              <Text style={styles.buttonText}>Fechar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal de Comentários */}
      <Modal
        visible={isCommentModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setIsCommentModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.commentTitle}>Comentários</Text>
            <FlatList
              data={comments}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <View style={styles.userContainer}>
                  <Image source={{ uri: item.user_photo || userProfile.foto_perfil }} style={styles.userPhoto} />
                  <Text style={styles.messageUser}>
                    {item.user_name || userProfile.nome || 'Usuário Anônimo'}
                  </Text>
                </View>
              )}
            />
            <TextInput
              style={styles.input}
              placeholder="Adicione um comentário..."
              value={comment}
              onChangeText={setComment}
            />
            <TouchableOpacity onPress={handleAddComment} style={styles.sendButton}>
              <Text style={styles.buttonText}>Comentar</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setIsCommentModalVisible(false)} style={styles.closeButton}>
              <Text style={styles.buttonText}>Fechar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    backgroundColor: '#fff',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  navTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  searchInput: {
    marginTop: 10,
    marginHorizontal: 20,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
  },
  messageList: {
    marginTop: 20,
  },
  messageItem: {
    backgroundColor: '#f9f9f9',
    marginBottom: 10,
    padding: 15,
    borderRadius: 8,
  },
  userContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userPhoto: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  messageUser: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  messageContent: {
    marginTop: 10,
    fontSize: 14,
    color: '#555',
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  likeCount: {
    marginLeft: 5,
  },
  commentButton: {
    marginLeft: 10,
  },
  commentCount: {
    marginLeft: 5,
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 30,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  commentTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  sendButton: {
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  closeButton: {
    marginTop: 10,
    backgroundColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
});

export default CommunityScreen;
