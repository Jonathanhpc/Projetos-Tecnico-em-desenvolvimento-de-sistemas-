import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const ProfessorScreen = ({ navigation }) => {
  const [students, setStudents] = useState([]);
  const [studentName, setStudentName] = useState('');
  const [editStudentIndex, setEditStudentIndex] = useState(null);
  const [grades, setGrades] = useState({ b1: '', b2: '', b3: '', b4: '' });
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [sidebarVisible, setSidebarVisible] = useState(false);

  // Adicionar um aluno
  const handleAddStudent = () => {
    if (studentName.trim() === '') {
      Alert.alert('Erro', 'Digite o nome do aluno.');
      return;
    }

    const newStudent = { name: studentName, grades: { ...grades } };
    setStudents([...students, newStudent]);
    setStudentName('');
    setGrades({ b1: '', b2: '', b3: '', b4: '' });
    setIsModalVisible(false);
  };

  // Editar um aluno
  const handleEditStudent = () => {
    if (studentName.trim() === '') {
      Alert.alert('Erro', 'Digite o nome do aluno.');
      return;
    }

    const updatedStudents = [...students];
    updatedStudents[editStudentIndex] = { name: studentName, grades: { ...grades } };
    setStudents(updatedStudents);
    setStudentName('');
    setGrades({ b1: '', b2: '', b3: '', b4: '' });
    setEditStudentIndex(null);
    setIsModalVisible(false);
  };

  // Excluir um aluno
  const handleDeleteStudent = (index) => {
    const updatedStudents = students.filter((_, i) => i !== index);
    setStudents(updatedStudents);
  };

  // Abrir o modal para editar um aluno existente
  const handleOpenEditModal = (index) => {
    const student = students[index];
    setStudentName(student.name);
    setGrades({ ...student.grades });
    setEditStudentIndex(index);
    setIsModalVisible(true);
  };

  const openDrawer = () => {
    setSidebarVisible(prev => !prev);
  };

  return (
    <View style={styles.container}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.navButton}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>

        <TouchableOpacity onPress={openDrawer} style={styles.navButton}>
          <Ionicons name="menu" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      {sidebarVisible && (
        <View style={styles.sidebar}>
          <Text style={styles.sidebarText}>Menu</Text>
        </View>
      )}

      <Text style={styles.title}>Gerenciar Alunos</Text>

      <TouchableOpacity
        style={styles.addButton}
        onPress={() => setIsModalVisible(true)}
      >
        <Text style={styles.addButtonText}>Adicionar Aluno</Text>
      </TouchableOpacity>

      <FlatList
        data={students}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.studentItem}>
            <View style={styles.studentDetails}>
              <Text style={styles.studentName}>{item.name}</Text>
              <Text style={styles.studentGrades}>
                1º Bim: {item.grades.b1}  2º Bim: {item.grades.b2}  3º Bim: {item.grades.b3}  4º Bim: {item.grades.b4}
              </Text>
            </View>

            <View style={styles.actions}>
              <TouchableOpacity onPress={() => handleOpenEditModal(index)}>
                <Ionicons name="pencil" size={24} color="#FF6F00" />
              </TouchableOpacity>

              <TouchableOpacity onPress={() => handleDeleteStudent(index)}>
                <Ionicons name="trash" size={24} color="#FF6F00" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      {/* Modal para Adicionar/Editar Aluno */}
      <Modal
        visible={isModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setIsModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {editStudentIndex !== null ? 'Editar Aluno' : 'Adicionar Aluno'}
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Nome do Aluno"
              value={studentName}
              onChangeText={setStudentName}
            />

            <TextInput
              style={styles.input}
              placeholder="Nota 1º Bim"
              keyboardType="numeric"
              value={grades.b1}
              onChangeText={(text) => setGrades({ ...grades, b1: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Nota 2º Bim"
              keyboardType="numeric"
              value={grades.b2}
              onChangeText={(text) => setGrades({ ...grades, b2: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Nota 3º Bim"
              keyboardType="numeric"
              value={grades.b3}
              onChangeText={(text) => setGrades({ ...grades, b3: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Nota 4º Bim"
              keyboardType="numeric"
              value={grades.b4}
              onChangeText={(text) => setGrades({ ...grades, b4: text })}
            />

            <TouchableOpacity
              style={styles.button}
              onPress={editStudentIndex !== null ? handleEditStudent : handleAddStudent}
            >
              <Text style={styles.buttonText}>
                {editStudentIndex !== null ? 'Salvar' : 'Adicionar'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.button, { backgroundColor: '#999' }]}
              onPress={() => setIsModalVisible(false)}
            >
              <Text style={styles.buttonText}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 0, // Remove o espaçamento nas laterais
    backgroundColor: '#F0F4F8',
  },
  navBar: {
    width: '100%',
    height: 50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    paddingHorizontal: 10,
    elevation: 4,
  },
  navButton: {
    padding: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF6F00',
    marginVertical: 20,
    textAlign: 'center',
  },
  addButton: {
    backgroundColor: '#FF6F00',
    padding: 12,
    borderRadius: 5,
    marginVertical: 10,
    width: '80%',
    alignSelf: 'center',
    alignItems: 'center',
    elevation: 2,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  studentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#CCC',
    width: '100%',
  },
  studentDetails: {
    flex: 1,
  },
  studentName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  studentGrades: {
    fontSize: 14,
    color: '#555',
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: 70,
  },
  input: {
    borderWidth: 1,
    borderColor: '#FF6F00',
    borderRadius: 5,
    padding: 10,
    width: '100%',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  buttonText: {
    color: '#FFF',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  sidebar: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '60%',
    height: '100%',
    backgroundColor: '#FFF',
    elevation: 5,
    padding: 20,
  },
  sidebarText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ProfessorScreen;
