import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const BasicEnglishScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const goBack = () => {
    navigation.goBack();
  };

  const showSidebar = () => setSidebar(prev => !prev);

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Inglês Básico
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Verbos no presente</Text>{"\n"}
                - Explicação: Os verbos no presente simples são usados para falar sobre ações habituais ou verdades gerais. No inglês, o presente simples usa a forma básica do verbo.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                I eat an apple every day. (Eu como uma maçã todos os dias.)
                {"\n"}
                She works in a hospital. (Ela trabalha em um hospital.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Pronomes Pessoais</Text>{"\n"}
                - Explicação: Os pronomes pessoais substituem substantivos e indicam quem está realizando a ação.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                I am a student. (Eu sou um estudante.){"\n"}
                He is my friend. (Ele é meu amigo.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Artigos "A" e "An"</Text>{"\n"}
                - Explicação: "A" e "An" são usados antes de substantivos no singular para indicar algo de forma geral. Use "A" antes de palavras que começam com som de consoante e "An" antes de palavras que começam com som de vogal.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                I have a book. (Eu tenho um livro.){"\n"}
                She has an orange. (Ela tem uma laranja.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Perguntas e respostas simples</Text>{"\n"}
                - Explicação: Para formar perguntas em inglês, muitas vezes usamos "Do" ou "Does" para o presente. Responda com "Yes" ou "No" seguido do pronome e verbo.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                Do you like coffee? (Você gosta de café?){"\n"}
                Yes, I do. / No, I don't. (Sim, eu gosto. / Não, eu não gosto.)
                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                Estes conceitos são a base para o aprendizado da língua inglesa. Com prática diária, você vai se familiarizar com essas estruturas e expandir seu vocabulário!
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default BasicEnglishScreen;
