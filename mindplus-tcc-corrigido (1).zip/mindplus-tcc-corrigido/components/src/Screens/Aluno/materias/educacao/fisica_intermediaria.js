import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const IntermediatePhysicsScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Física Intermediária
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Cinemática</Text>{"\n"}
                - Explicação: Cinemática estuda o movimento dos corpos sem se preocupar com as causas desse movimento. Inclui conceitos como velocidade, aceleração e trajetórias.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                O movimento de um carro em uma estrada pode ser descrito através de gráficos de posição versus tempo e velocidade versus tempo.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Dinâmica</Text>{"\n"}
                - Explicação: Dinâmica analisa as forças e torques que causam o movimento dos corpos. Inclui as Leis de Newton e a Lei da Gravitação Universal.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                A força que um carro exerce sobre o chão para mover-se é a mesma que o chão exerce sobre o carro, de acordo com a terceira lei de Newton.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Trabalho e Energia</Text>{"\n"}
                - Explicação: **Trabalho** é a transferência de energia por meio de forças aplicadas. **Energia** pode ser cinética, potencial, térmica, entre outras.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                A energia potencial de um objeto em uma altura é convertida em energia cinética quando ele cai, conforme a conservação da energia.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Termodinâmica</Text>{"\n"}
                - Explicação: Termodinâmica estuda as relações entre calor, trabalho e energia em sistemas. Inclui as leis da termodinâmica e conceitos como entropia e entalpia.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                A eficiência de um motor térmico é limitada pela segunda lei da termodinâmica, que afirma que nem toda a energia térmica pode ser convertida em trabalho.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>5. Óptica</Text>{"\n"}
                - Explicação: Óptica estuda a luz e suas interações com diferentes meios. Inclui reflexão, refração e dispersão da luz.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                O arco-íris é um fenômeno óptico causado pela refração e dispersão da luz solar através das gotas de chuva.
                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                Esses conceitos são fundamentais para o entendimento das leis que governam o mundo físico e são a base para muitos estudos mais avançados na física.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default IntermediatePhysicsScreen;
