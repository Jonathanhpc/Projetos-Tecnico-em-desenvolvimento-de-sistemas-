// AuthProvider.js
import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export const useUser = () => {
  return useContext(AuthContext);
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);  // Armazenar o usuário autenticado

  const login = (userData) => {
    setUser(userData);  // Armazenar o email e outras informações do usuário
  };

  const logout = () => {
    setUser(null);  // Limpar os dados do usuário quando ele fizer logout
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
