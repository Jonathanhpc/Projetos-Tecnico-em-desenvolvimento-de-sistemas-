import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, ScrollView, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const EnergyTipsScreen = () => {
  const navigation = useNavigation();

  const goBack = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <ImageBackground
        source={require('../../../Images/fundo.png')}  
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <Text style={styles.navTitle}>Dicas de Energia</Text>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.tipContainer}>
            <Image
              source={require('../../../Images/respiracao.png')} 
              style={styles.tipImage}
            />
            <Text style={styles.tipTitle}>1. Pratique a Respiração Profunda</Text>
            <Text style={styles.tipText}>
              Reserve alguns minutos por dia para praticar a respiração profunda. Inspire lentamente pelo nariz, enchendo o abdômen, e expire pela boca. Isso ajuda a reduzir o estresse e aumenta a energia.
            </Text>
          </View>

          <View style={styles.tipContainer}>
            <Image
              source={require('../../../Images/agua.png')} 
              style={styles.tipImage}
            />
            <Text style={styles.tipTitle}>2. Hidrate-se Regularmente</Text>
            <Text style={styles.tipText}>
              Manter-se hidratado é crucial para o bem-estar físico e mental. Beba água ao longo do dia para manter seus níveis de energia elevados.
            </Text>
          </View>

          <View style={styles.tipContainer}>
            <Image
              source={require('../../../Images/exercicio.png')} 
              style={styles.tipImage}
            />
            <Text style={styles.tipTitle}>3. Faça Alongamentos</Text>
            <Text style={styles.tipText}>
              Fazer alongamentos regulares ajuda a relaxar os músculos tensos e aumenta o fluxo de energia. Reserve alguns minutos para alongar-se durante o dia.
            </Text>
          </View>

          <View style={styles.tipContainer}>
            <Image
              source={require('../../../Images/alimentacao-saudavel.png')} 
              style={styles.tipImage}
            />
            <Text style={styles.tipTitle}>4. Alimente-se Bem</Text>
            <Text style={styles.tipText}>
              Uma dieta equilibrada rica em frutas, vegetais e proteínas saudáveis pode ajudar a manter níveis de energia estáveis ao longo do dia.
            </Text>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
  },
  navTitle: {
    fontSize: width * 0.05,
    color: 'white',
    fontWeight: 'bold',
    marginLeft: width * 0.05,
  },
  scrollContainer: {
    flexGrow: 1,
    paddingTop: height * 0.12,
    paddingBottom: height * 0.05,
    paddingHorizontal: width * 0.05,
  },
  tipContainer: {
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: width * 0.05,
    marginBottom: height * 0.03,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  tipImage: {
    width: width * 0.2,
    height: width * 0.2,
    marginBottom: height * 0.02,
  },
  tipTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
    marginBottom: height * 0.01,
    textAlign: 'center',
  },
  tipText: {
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  },
});

export default EnergyTipsScreen;
