<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // Permite acesso de qualquer origem

// Conecte ao banco de dados
$servername = "db4free.net";
$username = "mindplus2024";
$password = "Mindplus0404";
$dbname = "mindplus";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Recebe os dados do frontend
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['nome']) && isset($data['cpf']) && isset($data['email']) && isset($data['rg']) && isset($data['nomeMae']) && isset($data['telefone']) && isset($data['cep']) && isset($data['endereco']) && isset($data['sexo']) && isset($data['dataNascimento']) && isset($data['codigoVerificacao'])) {
    $nome = $conn->real_escape_string($data['nome']);
    $cpf = $conn->real_escape_string($data['cpf']);
    $email = $conn->real_escape_string($data['email']);
    $rg = $conn->real_escape_string($data['rg']);
    $nomeMae = $conn->real_escape_string($data['nomeMae']);
    $telefone = $conn->real_escape_string($data['telefone']);
    $cep = $conn->real_escape_string($data['cep']);
    $endereco = $conn->real_escape_string($data['endereco']);
    $sexo = $conn->real_escape_string($data['sexo']);
    $dataNascimento = $conn->real_escape_string($data['dataNascimento']);
    $codigoVerificacao = $conn->real_escape_string($data['codigoVerificacao']);

    $sql = "INSERT INTO alunos (nome, cpf, email, rg, nomeMae, telefone, cep, endereco, sexo, dataNascimento, codigoVerificacao) VALUES ('$nome', '$cpf', '$email', '$rg', '$nomeMae', '$telefone', '$cep', '$endereco', '$sexo', '$dataNascimento', '$codigoVerificacao')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("status" => "success", "message" => "Cadastro realizado com sucesso."));
    } else {
        echo json_encode(array("status" => "error", "message" => "Erro: " . $conn->error));
    }

    $conn->close();
} else {
    echo json_encode(array("status" => "error", "message" => "Dados incompletos."));
}
?>
