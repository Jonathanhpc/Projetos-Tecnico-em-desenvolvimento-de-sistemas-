import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { useAuth } from './AuthProvider';

const HomeScreen = () => {
  const { user, logout } = useAuth();

  return (
    <View>
      <Text>Bem-vindo, {user?.nome}!</Text>
      <Text>Papel: {user?.role}</Text>
      <TouchableOpacity onPress={logout}>
        <Text>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

export default HomeScreen;
