import React, { useState, useEffect } from 'react'; 
import { View, Text, Image, TouchableOpacity, ScrollView, TextInput, Button, StyleSheet, Modal, KeyboardAvoidingView, Platform, Keyboard, TouchableWithoutFeedback } from 'react-native'; 
import * as Speech from 'expo-speech'; 
import Ionicons from 'react-native-vector-icons/Ionicons'; 

const API_KEY = 'AIzaSyAIRqj9gfIWMgDUPCerVlEGv9z1iWhi_Pg'; // Substitua pela sua chave da Google API 
const CX = '556bb5cbb643d4c65'; // Substitua pelo seu ID do motor de busca  

const fetchResponseFromGoogle = async (query) => {   
  const url = `https://www.googleapis.com/customsearch/v1?key=${API_KEY}&cx=${CX}&q=${encodeURIComponent(query)}`;    
  try {     
    const response = await fetch(url);     
    const data = await response.json();      
    if (data.items && data.items.length > 0) {       
      const firstResult = data.items[0].snippet;       
      return firstResult;     
    } else {       
      return 'Desculpe, não encontrei resultados relevantes para sua pergunta.';     
    }   
  } catch (error) {     
    console.error(error);     
    return 'Houve um erro ao fazer a pesquisa. Tente novamente mais tarde.';   
  } 
};

export default function App({ navigation }) {   
  const [inputText, setInputText] = useState('');   
  const [messages, setMessages] = useState([     
    { role: 'bot', text: 'Olá! Sou o Jargas. Como posso te ajudar com suas dúvidas escolares?' },   
  ]);   
  const [sidebarVisible, setSidebarVisible] = useState(false); // Controla a exibição do Drawer   
  const [user, setUser] = useState({ name: '', photo: '' });    

  useEffect(() => {     
    const fetchUserData = async () => {       
      const { data, error } = await supabase         
        .from('alunos') // substitua 'alunos' pelo nome da sua tabela         
        .select('nome, photo') // ajuste os campos conforme necessário         
        .eq('email', 'aluno@example.com') // substitua pelo email do aluno logado         
        .single();        
      if (error) {         
        console.error('Erro ao buscar usuário:', error);         
        setUser({ name: 'Erro ao carregar nome', photo: null });       
      } else {         
        setUser({ name: data.nome, photo: data.photo });       
      }     
    };      
    fetchUserData();   
  }, []);    

  const handleSendMessage = async () => {     
    if (inputText.trim() === '') return;      
    const newMessages = [...messages, { role: 'user', text: inputText }];     
    setMessages(newMessages);     
    setInputText('');      
    const response = await fetchResponseFromGoogle(inputText);     
    setMessages([...newMessages, { role: 'bot', text: response }]);     
    Speech.speak(response);   
  };    

  const toggleDrawer = () => setSidebarVisible(!sidebarVisible);    

  // Dismiss keyboard when tapping outside the input field
  const dismissKeyboard = () => {
    Keyboard.dismiss();
  };

  return (     
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>       
      <TouchableWithoutFeedback onPress={dismissKeyboard}>
        <View style={{ flex: 1 }}> 
          {/* Navbar */}
          <View style={styles.navBar}>         
            {/* Botão de voltar no lugar da logo */}         
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.navButton}>           
              <Ionicons name="arrow-back" size={24} color="#FFF" />         
            </TouchableOpacity>          
            <TouchableOpacity onPress={toggleDrawer} style={styles.navButton}>           
              <Ionicons name="ellipsis-vertical" size={24} color="#FFF" />         
            </TouchableOpacity>       
          </View>        

          {/* Chat */}
          <ScrollView style={styles.chatContainer} keyboardShouldPersistTaps="handled">         
            {messages.map((msg, index) => (           
              <View             
                key={index}             
                style={msg.role === 'bot' ? styles.botMessageContainer : styles.userMessageContainer}           
              >             
                {msg.role === 'bot' && (               
                  <Image                 
                    source={require('../../Icons/LogoMax/laranja.png')}                 
                    style={styles.botImage}               
                  />             
                )}             
                <Text style={msg.role === 'bot' ? styles.botMessage : styles.userMessage}>               
                  {msg.role === 'bot' ? 'Jargas: ' : 'Você: '} {msg.text}             
                </Text>           
              </View>         
            ))}       
          </ScrollView>        

          {/* Input e botão de envio */}
          <View style={styles.inputContainer}>         
            <TextInput           
              style={styles.input}           
              placeholder="Digite sua dúvida aqui..."           
              value={inputText}           
              onChangeText={setInputText}           
              onSubmitEditing={handleSendMessage}         
            />          

            <Button title="Enviar" onPress={handleSendMessage} color="#FF6F00" />       
          </View>        

          {/* Drawer Sidebar como Modal no topo */}       
          <Modal         
            visible={sidebarVisible}         
            animationType="slide"         
            transparent={true}         
            onRequestClose={toggleDrawer}       
          >         
            <View style={styles.drawerContainer}>           
              <View style={styles.drawerContent}>             
                <View style={styles.userContainer}>               
                  <Image source={{ uri: user.photo }} style={styles.userPhoto} />               
                  <Text style={styles.userName}>{user.name}</Text>             
                </View>              

                <TouchableOpacity onPress={() => navigation.navigate('configuracao')} style={styles.sidebarButton}>               
                  <Text style={styles.sidebarButtonText}>Configuração</Text>             
                </TouchableOpacity>              

                <TouchableOpacity onPress={() => navigation.navigate('avaliacao')} style={styles.sidebarButton}>               
                  <Text style={styles.sidebarButtonText}>Gostou do App?</Text>             
                </TouchableOpacity>              

                <TouchableOpacity onPress={() => navigation.navigate('Login')} style={styles.sidebarButton}>               
                  <Text style={styles.sidebarButtonText}>Logout</Text>             
                </TouchableOpacity>              

                <Button title="Fechar" onPress={toggleDrawer} />           
              </View>         
            </View>       
          </Modal>     
        </View> 
      </TouchableWithoutFeedback>     
    </KeyboardAvoidingView>   
  ); 
}  

// Estilos 
const styles = StyleSheet.create({   
  container: {     
    flex: 1,     
    backgroundColor: '#D3D3D3', // Fundo cinza claro   
  },   
  navBar: {     
    width: '106%',     
    height: 60,     
    flexDirection: 'row',     
    justifyContent: 'space-between',     
    alignItems: 'center',     
    paddingHorizontal: -3,     
    backgroundColor: '#FF6F00',     
    position: 'absolute',     
    top: 0,     
    zIndex: 2,   
  },   
  navButton: {     
    padding: 10,   
  },   
  chatContainer: {     
    flex: 1,     
    marginBottom: 10,     
    marginTop: 60, // Espaço abaixo da navbar   
  },   
  botMessageContainer: {     
    flexDirection: 'row',     
    alignItems: 'flex-start',     
    marginBottom: 5,     
    paddingHorizontal: 10,   
  },   
  userMessageContainer: {     
    alignSelf: 'flex-end',     
    marginBottom: 5,     
    paddingHorizontal: 10,   
  },   
  botMessage: {     
    padding: 10,     
    backgroundColor: '#e0e0e0',     
    borderRadius: 10,     
    maxWidth: '80%',     
    marginLeft: 10,   
  },   
  userMessage: {     
    padding: 10,     
    backgroundColor: '#FF6F00',     
    color: 'white',     
    borderRadius: 10,     
    maxWidth: '80%',   
  },   
  botImage: {     
    width: 40,     
    height: 40,     
    borderRadius: 20,   
  },   
  inputContainer: {     
    flexDirection: 'row',     
    alignItems: 'center',     
    justifyContent: 'center',   
    padding: 10,     
    marginBottom: 10,   
  },   
  input: {     
    flex: 1,     
    height: 40,     
    borderColor: '#ccc',     
    borderWidth: 1,     
    paddingHorizontal: 10,     
    borderRadius: 25,     
    backgroundColor: 'white',     
    marginRight: 10,   
  },   
  drawerContainer: {     
    flex: 1,     
    justifyContent: 'flex-start',     
    backgroundColor: 'rgba(0,0,0,0.5)', // Sombreamento transparente para destacar o modal   
  },   
  drawerContent: {     
    backgroundColor: '#FFF',     
    padding: 20,     
    borderBottomLeftRadius: 20,     
    borderBottomRightRadius: 20,   
  },   
  userContainer: {     
    alignItems: 'center',     
    marginBottom: 20,   
  },   
  userPhoto: {     
    width: 80,     
    height: 80,     
    borderRadius: 40,     
    marginBottom: 10,   
  },   
  userName: {     
    fontSize: 18,     
    fontWeight: 'bold',   
  },   
  sidebarButton: {     
    padding: 15,     
    borderBottomWidth: 1,     
    borderColor: '#ddd',   
  },   
  sidebarButtonText: {     
    fontSize: 16,   
  }, 
});
