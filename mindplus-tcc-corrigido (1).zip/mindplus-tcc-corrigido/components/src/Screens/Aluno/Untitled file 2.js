import React, { createContext, useContext, useState } from 'react';

// Criação do contexto
const UserContext = createContext();

// Criação do provedor do contexto
export const UserProvider = ({ children }) => {
  const [user, setUser] = useState({
    name: '',
    photo: null,
    email: '',
    // Adicione outras informações do usuário que você deseja armazenar
  });

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

// Custom hook para acessar o contexto do usuário
export const useUser = () => {
  return useContext(UserContext);
};
