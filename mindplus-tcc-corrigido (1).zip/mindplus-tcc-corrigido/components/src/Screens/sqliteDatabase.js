import * as SQLite from 'expo-sqlite/legacy';

const db = SQLite.openDatabase('user.db');

export const createUserTable = () => {
  db.transaction(tx => {
    tx.executeSql(
      'CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, password TEXT);',
      [],
      () => console.log('Tabela users criada com sucesso!'),
      (tx, error) => console.log('Erro ao criar tabela users:', error)
    );
  });
};

export const checkAndInsertUser = (email, password) => {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT * FROM users WHERE email = ?;',
      [email],
      (tx, results) => {
        if (results.rows.length > 0) {
          console.log('Usuário já cadastrado:', email);
        } else {
          insertUser(email, password);
        }
      },
      (tx, error) => {
        console.log('Erro ao buscar usuário:', error);
      }
    );
  });
};

const insertUser = (email, password) => {
  db.transaction(tx => {
    tx.executeSql(
      'INSERT OR REPLACE INTO users (email, password) VALUES (?, ?);',
      [email, password],
      () => console.log('Email salvo com sucesso no SQLite'),
      (_, error) => console.error('Erro ao salvar email no SQLite:', error)
    );
  });
};

export const getUserByEmail = (email, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT * FROM user WHERE email = ?;',
      [email],
      (tx, results) => {
        if (results.rows.length > 0) {
          callback(results.rows.item(0)); // Retorna o primeiro usuário encontrado
        } else {
          callback(null); // Nenhum usuário encontrado
        }
      },
      (tx, error) => {
        console.log('Erro ao buscar usuário:', error);
        callback(null);
      }
    );
  });
};

// Nova função para buscar o email
export const fetchUserEmail = (callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT email FROM user LIMIT 1;',
      [],
      (tx, results) => {
        if (results.rows.length > 0) {
          callback(results.rows.item(0).email); // Retorna o email encontrado
        } else {
          callback(null); // Nenhum email encontrado
        }
      },
      (tx, error) => {
        console.log('Erro ao consultar SQLite:', error);
        callback(null);
      }
    );
  });
};
