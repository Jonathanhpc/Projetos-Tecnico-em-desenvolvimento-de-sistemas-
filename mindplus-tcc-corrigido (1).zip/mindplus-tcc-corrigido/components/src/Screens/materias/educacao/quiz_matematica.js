import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const QuizScreen = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isCorrect, setIsCorrect] = useState(null);
  const [score, setScore] = useState(0);
  const [errors, setErrors] = useState(0);
  const [isQuizFinished, setIsQuizFinished] = useState(false);

 const questions = [
  {    
    question: 'Qual é o valor de 5²?',
    options: ['A) 10', 'B) 15', 'C) 25', 'D) 20'],
    answer: 'C) 25',
  },
  {
    question: 'Qual é a fórmula da área de um círculo?',
    options: ['A) 2πr', 'B) πr²', 'C) πr', 'D) 2πr²'],
    answer: 'B) πr²',
  },
  {
    question: 'Se uma equação é dada por 2x + 3 = 7, qual é o valor de x?',
    options: ['A) 1', 'B) 2', 'C) 3', 'D) 4'],
    answer: 'B) 2',
  },
  {
    question: 'Qual é a soma dos ângulos internos de um triângulo?',
    options: ['A) 90°', 'B) 180°', 'C) 360°', 'D) 270°'],
    answer: 'B) 180°',
  },
  {
    question: 'Qual é o valor de √144?',
    options: ['A) 10', 'B) 12', 'C) 14', 'D) 16'],
    answer: 'B) 12',
  },
  {
    question: 'Quanto é 7 vezes 8?',
    options: ['A) 54', 'B) 56', 'C) 58', 'D) 64'],
    answer: 'B) 56',
  },
  {
    question: 'Qual é o resultado da equação: 3x - 4 = 11?',
    options: ['A) 3', 'B) 5', 'C) 6', 'D) 7'],
    answer: 'C) 5',
  },
  {
    question: 'O que representa o "π" em matemática?',
    options: ['A) Número imaginário', 'B) Constante matemática', 'C) Número fracionário', 'D) Variável'],
    answer: 'B) Constante matemática',
  },
  {
    question: 'Quanto é 100 dividido por 4?',
    options: ['A) 20', 'B) 25', 'C) 30', 'D) 40'],
    answer: 'B) 25',
  },
  {
    question: 'Se uma reta tem inclinação de 45°, qual é a tangente desse ângulo?',
    options: ['A) 0', 'B) 1', 'C) √2', 'D) 1/2'],
    answer: 'B) 1',
  },
];


  const handleAnswer = (option) => {
    if (isCorrect === null) { 
      const correct = option === questions[currentQuestion].answer;
      setIsCorrect(correct);

      if (correct) {
        setScore(score + 1); 
      } else {
        setErrors(errors + 1); 
      }
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion + 1 < questions.length) {
      setIsCorrect(null);
      setCurrentQuestion((prev) => prev + 1);
    } else {
      setIsQuizFinished(true);
    }
  };

  const getFinalMessage = () => {
    const percentage = (score / questions.length) * 100;

    if (percentage >= 80) {
      return 'Parabéns, você foi incrível!';
    } else if (percentage >= 50) {
      return 'Muito bem, mas podemos melhorar!';
    } else {
      return 'Estude mais um pouquinho!';
    }
  };

  return (
    <LinearGradient colors={['#ffe0b2', '#ff9800']} style={styles.background}>
      <View style={styles.container}>
        {isQuizFinished ? (
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>Quiz finalizado!</Text>
            <Text style={styles.resultText}>Acertos: {score}</Text>
            <Text style={styles.resultText}>Erros: {errors}</Text>
            <Text style={styles.resultMessage}>{getFinalMessage()}</Text>
          </View>
        ) : (
          <>
            <Text style={styles.question}>{questions[currentQuestion].question}</Text>
            
            <View style={styles.optionsContainer}>
              {questions[currentQuestion].options.map((option, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.optionButton, isCorrect !== null && styles.disabledOption]}
                  onPress={() => handleAnswer(option)}
                  disabled={isCorrect !== null}
                >
                  <Text style={styles.optionText}>{option}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {isCorrect !== null && (
              <Text style={isCorrect ? styles.correct : styles.incorrect}>
                {isCorrect ? 'Acertou!' : 'Errou!'}
              </Text>
            )}

            {isCorrect !== null && (
              <TouchableOpacity style={styles.nextButton} onPress={handleNextQuestion}>
                <Text style={styles.nextButtonText}>Próxima pergunta</Text>
              </TouchableOpacity>
            )}
          </>
        )}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginHorizontal: 20,
    elevation: 10, 
    shadowColor: '#FF6F00',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  question: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  optionsContainer: {
    marginBottom: 20,
  },
  optionButton: {
    backgroundColor: '#FF6F00',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  disabledOption: {
    backgroundColor: '#d3d3d3',
  },
  optionText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  correct: {
    fontSize: 22,
    color: '#4caf50',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  incorrect: {
    fontSize: 22,
    color: '#f44336',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  nextButton: {
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  nextButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  resultContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  resultMessage: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ff9800',
    marginTop: 20,
    textAlign: 'center',
  },
});

export default QuizScreen;
