import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput, Alert, Modal, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { useNavigation } from '@react-navigation/native';

// Configurações do Supabase
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; 
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const AlunoScreen = () => {
  const navigation = useNavigation();
  const [alunos, setAlunos] = useState([]);
  const [institutionCode, setInstitutionCode] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [newAluno, setNewAluno] = useState({ id: null, nome: '', cpf: '', email: '', rg: '', nome_mae: '', telefone: '', cep: '', endereco: '', sexo: '', data_nascimento: '', senha: '' });
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const fetchInstitutionCode = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (!userData) throw new Error('Usuário não autenticado.');

        const { email } = JSON.parse(userData);
        if (!email) throw new Error('Email não encontrado nos dados do usuário.');

        const { data, error } = await supabase
          .from('instituicoes')
          .select('codigo')
          .eq('email', email)
          .single();

        if (error || !data) throw new Error('Erro ao buscar código da instituição.');

        setInstitutionCode(data.codigo);
        fetchAlunos(data.codigo);
      } catch (err) {
        Alert.alert('Erro', err.message);
      }
    };

    fetchInstitutionCode();
  }, []);

  const fetchAlunos = async (codigo) => {
    try {
      const { data, error } = await supabase
        .from('alunos_instituicao')
        .select('*')
        .eq('codigo_instituicao', codigo);

      if (error) throw new Error('Erro ao buscar alunos.');
      setAlunos(data || []);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const handleAddOrEditAluno = async () => {
    try {
      if (isEditing) {
        const { error } = await supabase
          .from('alunos_instituicao')
          .update({
            nome: newAluno.nome,
            cpf: newAluno.cpf,
            email: newAluno.email,
            rg: newAluno.rg,
            nome_mae: newAluno.nome_mae,
            telefone: newAluno.telefone,
            cep: newAluno.cep,
            endereco: newAluno.endereco,
            sexo: newAluno.sexo,
            data_nascimento: newAluno.data_nascimento,
            senha: newAluno.senha,
          })
          .eq('id', newAluno.id);

        if (error) throw new Error('Erro ao editar aluno.');
        Alert.alert('Sucesso', 'Aluno atualizado com sucesso!');
      } else {
        const { error } = await supabase
          .from('alunos_instituicao')
          .insert({ ...newAluno, codigo_instituicao: institutionCode });

        if (error) throw new Error('Erro ao adicionar aluno.');
        Alert.alert('Sucesso', 'Aluno cadastrado com sucesso!');
      }

      fetchAlunos(institutionCode);
      setShowForm(false);
      setNewAluno({ id: null, nome: '', cpf: '', email: '', rg: '', nome_mae: '', telefone: '', cep: '', endereco: '', sexo: '', data_nascimento: '', senha: '' });
      setIsEditing(false);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const handleDeleteAluno = async (id) => {
    try {
      const { error } = await supabase
        .from('alunos_instituicao')
        .delete()
        .eq('id', id);

      if (error) throw new Error('Erro ao deletar aluno.');
      Alert.alert('Sucesso', 'Aluno excluído com sucesso!');
      fetchAlunos(institutionCode);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const startEdit = (aluno) => {
    setNewAluno(aluno);
    setShowModal(true);
    setIsEditing(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setIsEditing(false);
    setNewAluno({ id: null, nome: '', cpf: '', email: '', rg: '', nome_mae: '', telefone: '', cep: '', endereco: '', sexo: '', data_nascimento: '', senha: '' });
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Alunos</Text>
      </View>

      <FlatList
        data={alunos}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => startEdit(item)} style={styles.alunoItem}>
            <View>
              <Text style={styles.alunoName}>{item.nome}</Text>
              <Text style={styles.alunoDetails}>Telefone: {item.telefone}</Text>
              <Text style={styles.alunoDetails}>E-mail: {item.email}</Text>
            </View>
            <View style={styles.actions}>
              <TouchableOpacity onPress={() => startEdit(item)}>
                <Ionicons name="create" size={24} color="#FF6F00" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDeleteAluno(item.id)}>
                <Ionicons name="trash" size={24} color="#FF6F00" />
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        )}
        keyboardShouldPersistTaps="handled"
      />

      <TouchableOpacity style={styles.addButton} onPress={() => navigation.navigate('cadastro_alunoinstituicao')}>
        <Ionicons name="add-circle" size={24} color="#FFF" />
        <Text style={styles.addButtonText}>{isEditing ? 'Cancelar' : 'Adicionar Aluno'}</Text>
      </TouchableOpacity>

      {/* Modal para editar ou adicionar aluno */}
      <Modal visible={showModal} animationType="slide" transparent={true}>
        <View style={styles.modalBackground}>
          <ScrollView contentContainerStyle={styles.formContainer}>
            <TextInput
              style={styles.input}
              placeholder="Nome"
              value={newAluno.nome}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, nome: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="CPF"
              value={newAluno.cpf}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, cpf: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="E-mail"
              value={newAluno.email}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, email: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="RG"
              value={newAluno.rg}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, rg: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Nome da Mãe"
              value={newAluno.nome_mae}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, nome_mae: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Telefone"
              value={newAluno.telefone}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, telefone: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="CEP"
              value={newAluno.cep}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, cep: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Endereço"
              value={newAluno.endereco}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, endereco: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Sexo"
              value={newAluno.sexo}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, sexo: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Data de Nascimento"
              value={newAluno.data_nascimento}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, data_nascimento: text }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Senha"
              value={newAluno.senha}
              onChangeText={(text) => setNewAluno((prev) => ({ ...prev, senha: text }))}
            />
            <TouchableOpacity onPress={handleAddOrEditAluno} style={styles.submitButton}>
              <Text style={styles.submitButtonText}>{isEditing ? 'Editar' : 'Adicionar'} Aluno</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={closeModal} style={styles.cancelButton}>
              <Text style={styles.cancelButtonText}>Cancelar</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
 container: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    padding: 15,
  },
  headerTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  alunoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FFF',
    padding: 15,
    marginVertical: 8,
    borderRadius: 8,
    elevation: 2,
  },
  alunoName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  alunoDetails: {
    fontSize: 14,
    color: '#555',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: 60,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 8,
    margin: 20,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 16,
    marginLeft: 8,
  },
  formContainer: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    margin: 20,
    elevation: 5,
    shadowColor: '#FF6F00',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
  },
  input: {
    backgroundColor: '#F0F0F0',
    padding: 10,
    borderRadius: 8,
    marginVertical: 10,
  },
   submitButton: {
    backgroundColor: '#FF6F00',
    paddingVertical: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  submitButtonText: {
    color: '#FFF',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: '#CCC',
    paddingVertical: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  cancelButtonText: {
    color: '#FFF',
    textAlign: 'center',
  },
});

export default AlunoScreen;
