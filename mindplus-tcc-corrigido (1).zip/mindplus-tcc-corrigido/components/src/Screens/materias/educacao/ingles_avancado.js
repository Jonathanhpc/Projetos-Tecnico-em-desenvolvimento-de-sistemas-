import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const AdvancedEnglishScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const goBack = () => {
    navigation.goBack();
  };

  const showSidebar = () => setSidebar(prev => !prev);

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Inglês Avançado
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Future Perfect</Text>{"\n"}
                - Explicação: O Future Perfect é usado para expressar ações que estarão concluídas antes de um determinado momento no futuro. Ele é formado com "will have" seguido do particípio passado do verbo.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                By next year, I will have completed my degree. (No próximo ano, eu terei completado meu diploma.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Mixed Conditionals</Text>{"\n"}
                - Explicação: Mixed Conditionals combinam diferentes tempos verbais para falar de situações hipotéticas que envolvem o passado e o presente, ou o passado e o futuro.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                If I had studied harder, I would be more confident now. (Se eu tivesse estudado mais, eu estaria mais confiante agora.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Reported Speech (Discurso Indireto)</Text>{"\n"}
                - Explicação: O Reported Speech é utilizado para reportar o que outra pessoa disse, geralmente mudando o tempo verbal da fala original.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                She said, "I am going to the store." → She said (that) she was going to the store. (Ela disse que estava indo à loja.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Inversion in Conditionals</Text>{"\n"}
                - Explicação: A Inversão em Condicionais ocorre quando invertemos a estrutura da frase condicional para soar mais formal ou enfático. Geralmente, "if" é omitido e o verbo auxiliar aparece antes do sujeito.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                Had I known you were coming, I would have prepared something. (Se eu soubesse que você viria, teria preparado algo.)
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>5. Idiomatic Expressions</Text>{"\n"}
                - Explicação: As Expressões Idiomáticas são frases que têm significados diferentes de suas palavras individuais e são muito usadas em conversas no inglês avançado.
                {"\n"}{"\n"}
                <Text style={styles.subTitle}>Exemplo:</Text>{"\n"}
                It's raining cats and dogs. (Está chovendo muito.){"\n"}
                Break the ice. (Quebrar o gelo, ou seja, iniciar uma conversa.)
                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                Compreender e praticar esses conceitos avançados ajudará você a se comunicar com maior fluência e precisão em inglês. Continue praticando para se aperfeiçoar!
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default AdvancedEnglishScreen;
