import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const IntermediateWritingScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Redação Intermediária
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Coerência e Coesão</Text>{"\n"}
                - Conceitos e Aplicações: Coerência diz respeito à lógica e clareza nas ideias, enquanto coesão refere-se à conexão entre as partes do texto. Exemplo: uso de pronomes e conectores para garantir fluidez.
                {"\n"}{"\n"}
                - Estratégias: A utilização de conectores e a repetição controlada de palavras-chave ajudam a manter a coesão e coerência. Exemplo: "Além disso", "Portanto", "No entanto".
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Desenvolvimento de Argumentos</Text>{"\n"}
                - Construção de Argumentos: Apresentar argumentos convincentes com evidências e exemplos sólidos. Exemplo: apoiar uma tese com dados estatísticos e análises.
                {"\n"}{"\n"}
                - Contra-argumentos: Considerar e refutar argumentos opostos fortalece a persuasão. Exemplo: apresentar uma objeção e explicá-la criticamente.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Estilo e Tom</Text>{"\n"}
                - Adaptação ao Público: Ajustar o estilo e o tom de acordo com o público-alvo e o propósito do texto. Exemplo: tom formal para textos acadêmicos e informal para blogs.
                {"\n"}{"\n"}
                - Variedade de Vocabulário: Usar uma linguagem rica e variada para evitar repetições e manter o interesse do leitor. Exemplo: substituir termos comuns por sinônimos apropriados.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Estrutura Avançada</Text>{"\n"}
                - Parágrafos de Desenvolvimento: Cada parágrafo deve tratar de um aspecto específico do tema e ter uma ideia central clara. Exemplo: parágrafo sobre as vantagens e desvantagens de um argumento.
                {"\n"}{"\n"}
                - Uso de Subtítulos: Facilitar a leitura e organização do texto usando subtítulos. Exemplo: dividir o texto em seções como "Introdução", "Metodologia", "Resultados", "Conclusão".

                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                Desenvolver uma redação intermediária envolve aprimorar a clareza, argumentação e estilo. Com prática e atenção aos detalhes, você pode criar textos mais impactantes e eficazes.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default IntermediateWritingScreen;
