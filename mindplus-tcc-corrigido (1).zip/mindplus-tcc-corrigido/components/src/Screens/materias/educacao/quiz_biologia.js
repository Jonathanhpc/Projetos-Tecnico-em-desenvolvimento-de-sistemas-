import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; // Substitua pela sua URL do Supabase
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; // Substitua pela sua chave anônima do Supabase
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const QuizScreen = ({ navigation }) => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [userInfo, setUserInfo] = useState(null);

  const questionBank = [
    {
      question: 'Qual das seguintes opções é uma característica exclusiva das células eucarióticas?',
      options: ['Presença de ribossomos', 'Parede celular', 'Presença de núcleo definido', 'Ausência de mitocôndrias'],
      answer: 'Presença de núcleo definido',
    },
    {
      question: 'Qual é a função principal da mitocôndria?',
      options: ['Síntese de proteínas', 'Produção de ATP', 'Armazenamento de lipídios', 'Degradação de toxinas'],
      answer: 'Produção de ATP',
    },
    {
      question: 'A fotossíntese ocorre em qual organela da célula vegetal?',
      options: ['Mitocôndria', 'Lisossomo', 'Cloroplasto', 'Ribossomo'],
      answer: 'Cloroplasto',
    },
    {
      question: 'Qual é o nome do processo de divisão celular que resulta em células-filhas geneticamente idênticas à célula-mãe?',
      options: ['Meiose', 'Mitose', 'Fusão celular', 'Apoptose'],
      answer: 'Mitose',
    },
    {
      question: 'O grupo dos artrópodes inclui qual destes animais?',
      options: ['Sapo', 'Borboleta', 'Peixe', 'Minhoca'],
      answer: 'Borboleta',
    },
    {
      question: 'Qual é a função do sistema digestório?',
      options: ['Realizar trocas gasosas', 'Absorver nutrientes dos alimentos', 'Transportar oxigênio no sangue', 'Produzir hormônios'],
      answer: 'Absorver nutrientes dos alimentos',
    },
    {
      question: 'O DNA é composto por unidades chamadas de:',
      options: ['Aminoácidos', 'Nucleotídeos', 'Ácidos graxos', 'Monossacarídeos'],
      answer: 'Nucleotídeos',
    },
    {
      question: 'O transporte de oxigênio no sangue é realizado principalmente por:',
      options: ['Plaquetas', 'Glóbulos brancos', 'Hemoglobina', 'Plasma'],
      answer: 'Hemoglobina',
    },
    {
      question: 'Qual é a função dos ribossomos nas células?',
      options: ['Produção de energia', 'Armazenamento de gordura', 'Síntese de proteínas', 'Digestão de substâncias'],
      answer: 'Síntese de proteínas',
    },
    {
      question: 'Os anfíbios são caracterizados por:',
      options: ['Respiração exclusivamente pulmonar', 'Ciclo de vida dependente da água', 'Presença de escamas', 'Ausência de esqueleto'],
      answer: 'Ciclo de vida dependente da água',
    },
  ];

  useEffect(() => {
    setQuestions(shuffleArray([...questionBank]));
    fetchUserInfo();
  }, []);

  const shuffleArray = (array) => array.sort(() => Math.random() - 0.5);

  const fetchUserInfo = async () => {
    try {
      const userData = await AsyncStorage.getItem('userData');
      if (!userData) {
        Alert.alert('Erro', 'Usuário não encontrado. Faça login novamente.');
        return;
      }

      const user = JSON.parse(userData);
      const { data, error } = await supabase
        .from('alunos_instituicao')
        .select('codigo_instituicao, codigo_profissional')
        .eq('email', user.email)
        .single();

      if (error || !data) {
        Alert.alert('Erro', 'Não foi possível buscar as informações do usuário.');
        return;
      }

      setUserInfo({
        email: user.email,
        codigo_instituicao: data.codigo_instituicao,
        codigo_profissional: data.codigo_profissional,
      });
    } catch (err) {
      console.error('Erro ao buscar informações do usuário:', err);
      Alert.alert('Erro', 'Ocorreu um erro ao buscar os dados do usuário.');
    }
  };

  const handleAnswer = (selectedOption) => {
    const question = questions[currentQuestion];
    const isCorrect = selectedOption === question.answer;

    if (isCorrect) setScore((prev) => prev + 1);
    setSelectedAnswer(selectedOption);
    setAnswers((prev) => [...prev, { question: question.question, selectedOption, isCorrect }]);

    setTimeout(() => {
      setSelectedAnswer(null);
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion((prev) => prev + 1);
      } else {
        finishQuiz();
      }
    }, 1000);
  };

  const finishQuiz = async () => {
    if (!userInfo) {
      Alert.alert('Erro', 'Informações do usuário não carregadas.');
      return;
    }

    try {
      // Buscar o ID do aluno
      const { data: alunoData, error: alunoError } = await supabase
        .from('alunos_instituicao')
        .select('id')
        .eq('email', userInfo.email)
        .single();

      if (alunoError || !alunoData) {
        console.error('Erro ao buscar ID do aluno:', alunoError);
        Alert.alert('Erro', 'Não foi possível buscar o ID do aluno.');
        return;
      }

      const alunoId = alunoData.id;

      // Inserir o progresso
      const { error: insertError } = await supabase
        .from('progresso_aluno')
        .insert({
          aluno_id: alunoId,
          codigo_instituicao: userInfo.codigo_instituicao,
          codigo_profissional: userInfo.codigo_profissional,
          materia_ou_jogo: 'Biologia',
          pontos: score,
          progresso: ((score / questions.length) * 100).toFixed(2), // Em porcentagem
        });

      if (insertError) {
        console.error('Erro ao salvar progresso:', insertError);
        Alert.alert('Erro', 'Não foi possível salvar o progresso.');
      } else {
        Alert.alert(
          'Quiz Finalizado',
          `Você acertou ${score} de ${questions.length} perguntas! Seu progresso foi salvo com sucesso.`
        );
        navigation.navigate('Home');
      }
    } catch (err) {
      console.error('Erro ao salvar progresso:', err);
      Alert.alert('Erro', 'Ocorreu um erro ao processar os dados.');
    }
  };

  return (
    <LinearGradient colors={['#FFA500', '#FFFFFF']} style={styles.container}>
      {currentQuestion < questions.length ? (
        <View style={styles.questionContainer}>
          <Text style={styles.question}>{questions[currentQuestion].question}</Text>
          {questions[currentQuestion].options.map((option, index) => (
            <TouchableOpacity
              key={index}
              onPress={() => handleAnswer(option)}
              style={[
                styles.optionButton,
                selectedAnswer === option &&
                  (option === questions[currentQuestion].answer
                    ? styles.correctAnswer
                    : styles.wrongAnswer),
              ]}
            >
              <LinearGradient
                colors={['#FFFFFF', '#FFA500']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.gradientButton}
              >
                <Text style={styles.optionText}>{option}</Text>
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>
      ) : (
        <View style={styles.summaryContainer}>
          <Text style={styles.summaryText}>
            Você acertou {score} de {questions.length} perguntas!
          </Text>
          <TouchableOpacity onPress={finishQuiz} style={styles.finishButton}>
            <Text style={styles.finishButtonText}>Finalizar</Text>
          </TouchableOpacity>
        </View>
      )}
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  questionContainer: {
     width: '100%',
    alignItems: 'center',
  },
  question: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  optionButton: {
    width: '100%',
    marginVertical: 5,
    borderRadius: 10,
  },
  optionText: {
    fontSize: 18,
  },
  correctAnswer: {
    backgroundColor: 'green',
  },
  wrongAnswer: {
    backgroundColor: 'red',
  },
  gradientButton: {
    padding: 15,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
  },
  summaryContainer: {
    padding: 20,
    alignItems: 'center',
  },
  summaryText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  finishButton: {
    backgroundColor: '#FFA500',
    padding: 10,
    borderRadius: 10,
  },
  finishButtonText: {
    fontSize: 18,
    color: 'white',
  },
});

export default QuizScreen;
