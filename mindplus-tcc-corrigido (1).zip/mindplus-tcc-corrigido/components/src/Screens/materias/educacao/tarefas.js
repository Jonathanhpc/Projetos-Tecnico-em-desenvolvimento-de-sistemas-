import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Modal, FlatList, Alert, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const { width } = Dimensions.get('window');

const formatDate = (date) => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

const formatDateInput = (text) => {
  const cleaned = text.replace(/\D/g, '');
  let formatted = cleaned;
  if (cleaned.length > 2) {
    formatted = `${cleaned.slice(0, 2)}/${cleaned.slice(2)}`;
  }
  if (cleaned.length > 4) {
    formatted = `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}/${cleaned.slice(4)}`;
  }
  return formatted;
};

const CalendarScreen = () => {
  const navigation = useNavigation();
  const [tasks, setTasks] = useState([]);
  const [taskInput, setTaskInput] = useState('');
  const [taskDate, setTaskDate] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleAddTask = () => {
    if (taskInput.trim() === '' || taskDate.trim() === '') {
      Alert.alert('Erro', 'Digite a tarefa e selecione a data.');
      return;
    }

    const datePattern = /^([0-2][0-9]|3[0-1])\/(0[1-9]|1[0-2])\/\d{4}$/;
    if (!datePattern.test(taskDate)) {
      Alert.alert('Erro', 'Formato de data inválido. Use DD/MM/AAAA.');
      return;
    }

    const newTask = {
      text: taskInput,
      taskDate: taskDate,
      addedDate: formatDate(new Date()),
    };

    setTasks(prevTasks => [...prevTasks, newTask]);
    setTaskInput('');
    setTaskDate('');
    setIsModalVisible(false);
  };

  const handleDeleteTask = (index) => {
    Alert.alert(
      'Excluir Tarefa',
      'Tem certeza que deseja excluir esta tarefa?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Excluir', onPress: () => {
            setTasks(prevTasks => prevTasks.filter((_, i) => i !== index));
        }},
      ]
    );
  };

  return (
    <View style={styles.container}>
      {/* Barra de navegação superior */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.headerButton}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Tarefas</Text>
        <TouchableOpacity onPress={() => {/* Lógica para abrir opções */}} style={styles.headerButton}>
          <Ionicons name="ellipsis-vertical" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.title}>Organize suas tarefas</Text>

        <TouchableOpacity onPress={() => setIsModalVisible(true)} style={styles.addButton}>
          <Text style={styles.addButtonText}>Adicionar Tarefa</Text>
        </TouchableOpacity>

        {/* Modal para adicionar nova tarefa */}
        <Modal
          visible={isModalVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setIsModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Nova Tarefa</Text>

              <TextInput
                style={styles.input}
                placeholder="Nome da tarefa"
                value={taskInput}
                onChangeText={setTaskInput}
              />

              <TextInput
                style={styles.input}
                placeholder="Data (DD/MM/AAAA)"
                value={taskDate}
                onChangeText={(text) => setTaskDate(formatDateInput(text))}
                keyboardType="numeric"
                maxLength={10}
              />

              <TouchableOpacity onPress={handleAddTask} style={styles.button}>
                <Text style={styles.buttonText}>Adicionar</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setIsModalVisible(false)} style={styles.button}>
                <Text style={styles.buttonText}>Cancelar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Lista de Tarefas */}
        <View style={styles.taskListContainer}>
          <Text style={styles.taskListTitle}>Lista de tarefas:</Text>
          <FlatList
            data={tasks}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => (
              <View style={styles.taskItem}>
                <Text style={styles.taskText}>Tarefa: {item.text}</Text>
                <Text style={styles.taskText}>Data para concluir: {item.taskDate}</Text>
                <Text style={styles.taskText}>Adicionada em: {item.addedDate}</Text>
                <TouchableOpacity onPress={() => handleDeleteTask(index)} style={styles.deleteButton}>
                  <Ionicons name="trash" size={24} color="#FFF" />
                </TouchableOpacity>
              </View>
            )}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    padding: 15,
  },
  headerButton: {
    marginHorizontal: 10,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF6F00',
    marginBottom: 20,
    textAlign: 'center',
  },
  addButton: {
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#DDD',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  taskListContainer: {
    marginTop: 20,
  },
  taskListTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  taskItem: {
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  taskText: {
    color: '#FFF',
  },
  deleteButton: {
    marginTop: 10,
    alignItems: 'flex-end',
  },
});

export default CalendarScreen;
