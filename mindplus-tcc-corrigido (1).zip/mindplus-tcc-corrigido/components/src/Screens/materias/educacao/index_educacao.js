import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const SignupScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  // Função para abrir ou fechar o drawer
  const openDrawer = () => {
    setSidebar(prev => !prev);
  };

  // Função para voltar para a tela anterior
  const goBack = () => {
    navigation.goBack();
  };

  // Simulação de carregamento do usuário
  useEffect(() => {
    
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100' 
      });
    }, 1000); 
  }, []);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        {/* Barra de Navegação com Botão de Voltar e Botão de Menu Lateral */}
        <View style={styles.navBar}>
          <TouchableOpacity 
            onPress={goBack} 
            style={styles.navButton}
            accessibilityLabel="Voltar"
            accessibilityHint="Volta para a tela anterior"
          >
            <Ionicons name="arrow-back" size={24} color="#FFF" />
          </TouchableOpacity>
          
          <TouchableOpacity 
            onPress={openDrawer} 
            style={styles.navButton}
            accessibilityLabel="Menu"
            accessibilityHint="Abre o menu lateral"
          >
            <Ionicons name="menu" size={24} color="#FFF" />
          </TouchableOpacity>
        </View>

        {/* Se o sidebar estiver ativo, exiba-o */}
        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            {/* Botões de Navegação no Sidebar */}
            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.content}>
          {/* Container para o texto com fundo laranja claro */}
          <View style={styles.textContainer}>
            <Text style={styles.tituloText}>Matérias para estudo</Text>
          </View>

          {/* Container para os botões */}
          <View style={styles.buttonContainer}>
            <View style={styles.row}>
              <TouchableOpacity onPress={() => navigation.navigate('portugues')} style={styles.button}>
                <Image
                  source={require('../../../Images/livro.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Português</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('matematica')} style={styles.button}>
                <Image
                  source={require('../../../Images/matematica.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Matemática</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('quimica')} style={styles.button}>
                <Image
                  source={require('../../../Images/teste.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Química</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.row}>
              <TouchableOpacity onPress={() => navigation.navigate('ingles')} style={styles.button}>
                <Image
                  source={require('../../../Images/reino-unido.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Inglês</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('redacao')} style={styles.button}>
                <Image
                  source={require('../../../Images/escrita.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Redação</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('biologia')} style={styles.button}>
                <Image
                  source={require('../../../Images/bacterias.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Biologia</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.row}>
              <TouchableOpacity onPress={() => navigation.navigate('fisica')} style={styles.button}>
                <Image
                  source={require('../../../Images/fisica.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Física</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('geografia')} style={styles.button}>
                <Image
                  source={require('../../../Images/geografia.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Geografia</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => navigation.navigate('dicas')} style={styles.button}>
                <Image
                  source={require('../../../Images/bate-papo.png')}
                  style={styles.buttonImage}
                />
                <Text style={styles.buttonText}>Dicas de estudos</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    marginTop: height * 0.1,
  },
  textContainer: {
    backgroundColor: '#FFB74D',
    padding: width * 0.05,
    borderRadius: 20,
    marginBottom: height * 0.03,
    alignItems: 'center',
    width: '90%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.05,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonContainer: {
    width: '98%',
    justifyContent: 'flex-start',
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 12,
    alignItems: 'flex-start',
    elevation: 3,
    marginBottom: height * 0.01,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'flex-start', 
    width: '100%',
    marginBottom: height * 0.02,
  },
  
  button: {
    width: width * 0.28, 
    backgroundColor: '#FFF',
    borderRadius: 12,
    alignItems: 'center',
    paddingVertical: height * 0.02,
    paddingHorizontal: width * 0.02,
    marginRight: width * 0.02, 
  },

  buttonImage: {
    width: width * 0.15,
    height: width * 0.15,
    marginBottom: height * 0.01,
  },
  buttonText: {
    color: 'black',
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
});

export default SignupScreen;
