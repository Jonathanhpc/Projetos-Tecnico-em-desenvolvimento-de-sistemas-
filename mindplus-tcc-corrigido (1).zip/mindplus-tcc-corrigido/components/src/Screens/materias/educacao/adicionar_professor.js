import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { useNavigation } from '@react-navigation/native';

// Configurações do Supabase
// Configurações do Supabase
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; // Substitua pela sua URL do Supabase
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; // Substitua pela sua chave anônima do Supabase
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const ProfessorScreen = () => {
  const navigation = useNavigation();
  const [professors, setProfessors] = useState([]);
  const [institutionCode, setInstitutionCode] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [newProfessor, setNewProfessor] = useState({ id: null, nome_completo: '', telefone: '', email: '' });

  useEffect(() => {
    const fetchInstitutionCode = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (!userData) throw new Error('Usuário não autenticado.');

        const { email } = JSON.parse(userData);
        if (!email) throw new Error('Email não encontrado nos dados do usuário.');

        const { data, error } = await supabase
          .from('instituicoes')
          .select('codigo')
          .eq('email', email)
          .single();

        if (error || !data) throw new Error('Erro ao buscar código da instituição.');

        setInstitutionCode(data.codigo);
        fetchProfessors(data.codigo);
      } catch (err) {
        Alert.alert('Erro', err.message);
      }
    };

    fetchInstitutionCode();
  }, []);

  const fetchProfessors = async (codigo) => {
    try {
      const { data, error } = await supabase
        .from('profissional')
        .select('*')
        .eq('codigo_instituicao', codigo);

      if (error) throw new Error('Erro ao buscar professores.');
      setProfessors(data || []);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const handleAddOrEditProfessor = async () => {
    try {
      if (isEditing) {
        const { error } = await supabase
          .from('profissional')
          .update({
            nome_completo: newProfessor.nome_completo,
            telefone: newProfessor.telefone,
            email: newProfessor.email,
          })
          .eq('id', newProfessor.id);

        if (error) throw new Error('Erro ao editar professor.');
        Alert.alert('Sucesso', 'Professor atualizado com sucesso!');
      } else {
        const { error } = await supabase
          .from('profissional')
          .insert({ ...newProfessor, codigo_instituicao: institutionCode });

        if (error) throw new Error('Erro ao adicionar professor.');
        Alert.alert('Sucesso', 'Professor cadastrado com sucesso!');
      }

      fetchProfessors(institutionCode);
      setShowForm(false);
      setNewProfessor({ id: null, nome_completo: '', telefone: '', email: '' });
      setIsEditing(false);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const handleDeleteProfessor = async (id) => {
    try {
      const { error } = await supabase
        .from('profissional')
        .delete()
        .eq('id', id);

      if (error) throw new Error('Erro ao deletar professor.');
      Alert.alert('Sucesso', 'Professor excluído com sucesso!');
      fetchProfessors(institutionCode);
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  };

  const startEdit = (professor) => {
    setNewProfessor(professor);
    setShowForm(true);
    setIsEditing(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Professores</Text>
      </View>

      <FlatList
        data={professors}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.professorItem}>
            <View>
              <Text style={styles.professorName}>{item.nome_completo}</Text>
              <Text style={styles.professorDetails}>Telefone: {item.telefone}</Text>
              <Text style={styles.professorDetails}>E-mail: {item.email}</Text>
            </View>
            <View style={styles.actions}>
              <TouchableOpacity onPress={() => startEdit(item)}>
                <Ionicons name="create" size={24} color="#FF6F00" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDeleteProfessor(item.id)}>
                <Ionicons name="trash" size={24} color="#FF6F00" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

     <TouchableOpacity style={styles.addButton} onPress={() => navigation.navigate('CadastroProfessor')}>
  <Ionicons name="add-circle" size={24} color="#FFF" />
  <Text style={styles.addButtonText}>{isEditing ? 'Cancelar' : 'Adicionar Professor'}</Text>
</TouchableOpacity>

      {showForm && (
        <View style={styles.formContainer}>
          <TextInput
            style={styles.input}
            placeholder="Nome Completo"
            value={newProfessor.nome_completo}
            onChangeText={(text) => setNewProfessor((prev) => ({ ...prev, nome_completo: text }))}
          />
          <TextInput
            style={styles.input}
            placeholder="Telefone"
            value={newProfessor.telefone}
            onChangeText={(text) => setNewProfessor((prev) => ({ ...prev, telefone: text }))}
          />
          <TextInput
            style={styles.input}
            placeholder="E-mail"
            value={newProfessor.email}
            onChangeText={(text) => setNewProfessor((prev) => ({ ...prev, email: text }))}
          />
          <TouchableOpacity style={styles.saveButton} onPress={handleAddOrEditProfessor}>
            <Text style={styles.saveButtonText}>{isEditing ? 'Atualizar' : 'Salvar'}</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    padding: 15,
  },
  headerTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  professorItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FFF',
    padding: 15,
    marginVertical: 8,
    borderRadius: 8,
    elevation: 2,
  },
  professorName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  professorDetails: {
    fontSize: 14,
    color: '#555',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: 60,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 8,
    margin: 20,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 16,
    marginLeft: 8,
  },
  formContainer: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    margin: 20,
    elevation: 5,
    shadowColor: '#FF6F00',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
  },
  input: {
    backgroundColor: '#F0F0F0',
    padding: 10,
    borderRadius: 8,
    marginVertical: 10,
  },
  saveButton: {
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  saveButtonText: {
    color: '#FFF',
    fontSize: 16,
  },
});

export default ProfessorScreen;
