import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, Modal, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native'; // Importando o hook de navegação

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const TaskScreen = () => {
  const [tasks, setTasks] = useState([]);
  const [taskName, setTaskName] = useState('');
  const [taskDate, setTaskDate] = useState(new Date());
  const [taskNote, setTaskNote] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [email, setEmail] = useState('');  // Aqui vai ser armazenado o email do usuário logado
  const navigation = useNavigation(); // Hook de navegação

  // Função para mostrar o DatePicker
  const showDatePickerModal = () => setShowDatePicker(true);
  const hideDatePicker = () => setShowDatePicker(false);

  // Função para quando a data for escolhida
  const handleDateChange = (event, selectedDate) => {
    setShowDatePicker(false); // Fecha o DatePicker quando uma data for selecionada
    if (selectedDate) {
      setTaskDate(selectedDate);
    }
  };

  // Função para adicionar nova tarefa no Supabase
  const addTask = async () => {
    if (!taskName || !taskDate || !email) return; // Verifica se todos os campos estão preenchidos

    try {
      const { data, error } = await supabase
        .from('tasks')  // Nome da tabela no Supabase
        .insert([
          {
            user_id: email,
            nome_aluno: taskName,  // Usando o nome da tarefa como nome do aluno
            email: email,
            date: taskDate.toISOString().split('T')[0],  // Formata a data como 'YYYY-MM-DD'
            note: taskNote,
          },
        ]);

      if (error) {
        throw error;
      }

      console.log('Tarefa cadastrada com sucesso:', data);

      // Limpa os campos e atualiza a lista de tarefas
      setTaskName('');
      setTaskDate(new Date());
      setTaskNote('');
      fetchTasks();  // Atualiza as tarefas
      setIsModalVisible(false);
    } catch (error) {
      console.error('Erro ao adicionar tarefa:', error.message);
    }
  };

  // Função para buscar as tarefas no Supabase
  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase.from('tasks').select('*').eq('user_id', email);

      if (error) {
        throw error;
      }

      setTasks(data);
    } catch (error) {
      console.error('Erro ao buscar tarefas:', error.message);
    }
  };

  // Chama a função para buscar as tarefas assim que o componente for montado
  useEffect(() => {
    const getUserEmail = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (userData) {
          const parsedData = JSON.parse(userData);
          setEmail(parsedData.email);  // Recupera o email do usuário logado
        }
      } catch (error) {
        console.error('Erro ao recuperar email do AsyncStorage:', error);
      }
    };

    getUserEmail();
  }, []);  // O useEffect é chamado uma vez após o componente ser montado

  // Atualiza as tarefas sempre que o email mudar
  useEffect(() => {
    if (email) {
      fetchTasks();
    }
  }, [email]);

  return (
    <View style={styles.container}>
      <View style={styles.navbar}>
        {/* Botão de Voltar */}
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={30} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.navbarText}>Tarefas</Text>
      </View>

      <FlatList
        data={tasks}
        renderItem={({ item }) => (
          <View style={styles.taskContainer}>
            <Text style={styles.taskTitle}>{item.nome_aluno}: {item.note}</Text>
            <Text style={styles.taskDate}>Data: {item.date}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id.toString()}
      />

      <TouchableOpacity
        style={styles.floatingButton}
        onPress={() => setIsModalVisible(true)}
      >
        <Ionicons name="add" size={30} color="#fff" />
      </TouchableOpacity>

      <Modal visible={isModalVisible} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <TextInput
              style={styles.input}
              value={taskName}
              onChangeText={setTaskName}
              placeholder="Nome da Tarefa"
            />

            <TouchableOpacity onPress={showDatePickerModal}>
              <Text style={styles.input}>Selecione a Data</Text>
            </TouchableOpacity>
            
            {showDatePicker && (
              <DateTimePicker
                value={taskDate}
                mode="date"
                display="default"
                onChange={handleDateChange}
              />
            )}

            <TextInput
              style={styles.input}
              value={taskNote}
              onChangeText={setTaskNote}
              placeholder="Observação"
            />
            
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setIsModalVisible(false)}>
                <Text style={styles.buttonText}>Fechar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sendButton} onPress={addTask}>
                <Text style={styles.buttonText}>Cadastrar Tarefa</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  navbar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    padding: 15,
  },
  navbarText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginLeft: 10,
  },
  taskContainer: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#f1f1f1',
    borderRadius: 12,  // Bordas arredondadas
    shadowColor: '#FF5733',  // Cor da sombra laranja
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 4,
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  taskDate: {
    fontSize: 12,
    color: '#555',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    fontSize: 16,
    color: '#333',
  },
  sendButton: {
    backgroundColor: '#FF5733',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  cancelButton: {
    backgroundColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  floatingButton: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    backgroundColor: '#FF5733',
    borderRadius: 50,
    padding: 15,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
    elevation: 5,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
  },
});

export default TaskScreen;
