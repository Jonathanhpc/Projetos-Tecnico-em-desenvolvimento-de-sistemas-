import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const QuizScreen = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isCorrect, setIsCorrect] = useState(null);
  const [score, setScore] = useState(0);
  const [errors, setErrors] = useState(0);
  const [isQuizFinished, setIsQuizFinished] = useState(false);

 const questions = [
  {
    question: 'Qual é a estrutura básica de um texto dissertativo-argumentativo?',
    options: ['A) Introdução, desenvolvimento, conclusão', 'B) Título, introdução, corpo, conclusão', 'C) Introdução, argumento, conclusão', 'D) Introdução, desenvolvimento, resumo'],
    answer: 'A) Introdução, desenvolvimento, conclusão',
  },
  {
    question: 'Qual é a principal função de um parágrafo de desenvolvimento em uma redação?',
    options: ['A) Apresentar o tema', 'B) Fornecer argumentos e evidências', 'C) Resumir o conteúdo', 'D) Fazer uma conclusão final'],
    answer: 'B) Fornecer argumentos e evidências',
  },
  {
    question: 'O que caracteriza uma boa tese em uma redação dissertativa?',
    options: ['A) Deve ser uma afirmação clara e objetiva sobre o tema', 'B) Deve ser uma citação famosa', 'C) Deve ser uma pergunta retórica', 'D) Deve ser uma descrição detalhada do tema'],
    answer: 'A) Deve ser uma afirmação clara e objetiva sobre o tema',
  },
  {
    question: 'Qual é a importância da coesão e coerência em uma redação?',
    options: ['A) Para garantir que o texto esteja bem formatado', 'B) Para assegurar que as ideias estão bem conectadas e fazem sentido', 'C) Para criar um impacto visual agradável', 'D) Para utilizar um vocabulário sofisticado'],
    answer: 'B) Para assegurar que as ideias estão bem conectadas e fazem sentido',
  },
  {
    question: 'O que deve conter em uma conclusão eficaz?',
    options: ['A) Resumo das ideias principais e reafirmação da tese', 'B) Novos argumentos e evidências', 'C) Informações adicionais não mencionadas anteriormente', 'D) Perguntas para o leitor'],
    answer: 'A) Resumo das ideias principais e reafirmação da tese',
  },
  {
    question: 'Como é definida a função de um tópico frasal em um parágrafo?',
    options: ['A) Introduzir o tema do parágrafo', 'B) Fornecer uma conclusão', 'C) Apresentar evidências', 'D) Criar um efeito visual'],
    answer: 'A) Introduzir o tema do parágrafo',
  },
  {
    question: 'Qual é a diferença entre uma redação argumentativa e uma redação expositiva?',
    options: ['A) A argumentativa defende uma posição, enquanto a expositiva apenas informa', 'B) A expositiva utiliza uma linguagem mais formal', 'C) A argumentativa é mais curta', 'D) Não há diferença significativa'],
    answer: 'A) A argumentativa defende uma posição, enquanto a expositiva apenas informa',
  },
  {
    question: 'Qual é a função dos conectivos textuais em uma redação?',
    options: ['A) Embelezar o texto', 'B) Fazer o texto parecer mais longo', 'C) Facilitar a transição entre ideias e frases', 'D) Evitar erros gramaticais'],
    answer: 'C) Facilitar a transição entre ideias e frases',
  },
  {
    question: 'O que é um antônimo e como ele pode ser utilizado em uma redação?',
    options: ['A) É uma palavra com o mesmo significado; utilizado para evitar repetição', 'B) É uma palavra com o significado oposto; utilizado para criar contraste', 'C) É uma palavra que descreve uma ação', 'D) É uma palavra que descreve um lugar'],
    answer: 'B) É uma palavra com o significado oposto; utilizado para criar contraste',
  },
  {
    question: 'Qual é a importância de revisar uma redação antes da entrega?',
    options: ['A) Para corrigir erros de digitação e gramática', 'B) Para adicionar mais informações', 'C) Para garantir que o texto está formatado corretamente', 'D) Para garantir que as ideias estão bem desenvolvidas e claras'],
    answer: 'D) Para garantir que as ideias estão bem desenvolvidas e claras',
  },
];


  const handleAnswer = (option) => {
    if (isCorrect === null) { 
      const correct = option === questions[currentQuestion].answer;
      setIsCorrect(correct);

      if (correct) {
        setScore(score + 1); 
      } else {
        setErrors(errors + 1); 
      }
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion + 1 < questions.length) {
      setIsCorrect(null);
      setCurrentQuestion((prev) => prev + 1);
    } else {
      setIsQuizFinished(true);
    }
  };

  const getFinalMessage = () => {
    const percentage = (score / questions.length) * 100;

    if (percentage >= 80) {
      return 'Parabéns, você foi incrível!';
    } else if (percentage >= 50) {
      return 'Muito bem, mas podemos melhorar!';
    } else {
      return 'Estude mais um pouquinho!';
    }
  };

  return (
    <LinearGradient colors={['#ffe0b2', '#ff9800']} style={styles.background}>
      <View style={styles.container}>
        {isQuizFinished ? (
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>Quiz finalizado!</Text>
            <Text style={styles.resultText}>Acertos: {score}</Text>
            <Text style={styles.resultText}>Erros: {errors}</Text>
            <Text style={styles.resultMessage}>{getFinalMessage()}</Text>
          </View>
        ) : (
          <>
            <Text style={styles.question}>{questions[currentQuestion].question}</Text>
            
            <View style={styles.optionsContainer}>
              {questions[currentQuestion].options.map((option, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.optionButton, isCorrect !== null && styles.disabledOption]}
                  onPress={() => handleAnswer(option)}
                  disabled={isCorrect !== null}
                >
                  <Text style={styles.optionText}>{option}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {isCorrect !== null && (
              <Text style={isCorrect ? styles.correct : styles.incorrect}>
                {isCorrect ? 'Acertou!' : 'Errou!'}
              </Text>
            )}

            {isCorrect !== null && (
              <TouchableOpacity style={styles.nextButton} onPress={handleNextQuestion}>
                <Text style={styles.nextButtonText}>Próxima pergunta</Text>
              </TouchableOpacity>
            )}
          </>
        )}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginHorizontal: 20,
    elevation: 10, 
    shadowColor: '#FF6F00',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  question: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  optionsContainer: {
    marginBottom: 20,
  },
  optionButton: {
    backgroundColor: '#FF6F00',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  disabledOption: {
    backgroundColor: '#d3d3d3',
  },
  optionText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  correct: {
    fontSize: 22,
    color: '#4caf50',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  incorrect: {
    fontSize: 22,
    color: '#f44336',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  nextButton: {
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  nextButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  resultContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  resultMessage: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ff9800',
    marginTop: 20,
    textAlign: 'center',
  },
});

export default QuizScreen;
