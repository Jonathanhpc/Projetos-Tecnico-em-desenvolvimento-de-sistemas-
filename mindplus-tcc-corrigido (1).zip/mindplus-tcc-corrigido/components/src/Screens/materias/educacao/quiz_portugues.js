import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const QuizScreen = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isCorrect, setIsCorrect] = useState(null);
  const [score, setScore] = useState(0);
  const [errors, setErrors] = useState(0);
  const [isQuizFinished, setIsQuizFinished] = useState(false);

 const questions = [
  {    
    question: 'Qual das opções abaixo é uma palavra oxítona?',
    options: ['A) árvore', 'B) fácil', 'C) café', 'D) lápis'],
    answer: 'C) café',
  },
  {
    question: 'Qual é o sujeito na frase: "Os alunos estudam para a prova"?',
    options: ['A) Estudam', 'B) Os alunos', 'C) Para a prova', 'D) Prova'],
    answer: 'B) Os alunos',
  },
  {
    question: 'Em qual das opções há um erro de concordância verbal?',
    options: ['A) Eles vão ao parque', 'B) Nós vamos ao cinema', 'C) As criança brinca no quintal', 'D) Eu estudo todos os dias'],
    answer: 'C) As criança brinca no quintal',
  },
  {
    question: 'Qual é a classificação da oração "quando ela chegou"?',
    options: ['A) Oração subordinada adverbial causal', 'B) Oração subordinada adverbial temporal', 'C) Oração coordenada', 'D) Oração subordinada adjetiva'],
    answer: 'B) Oração subordinada adverbial temporal',
  },
  {
    question: 'Qual das frases apresenta um pronome oblíquo?',
    options: ['A) Eu vi o filme', 'B) Eles me chamaram', 'C) Ela está feliz', 'D) Nós vamos ao parque'],
    answer: 'B) Eles me chamaram',
  },
  {
    question: 'Na frase "O sol ilumina a praia", qual é o complemento do verbo?',
    options: ['A) O sol', 'B) A praia', 'C) Ilumina', 'D) Nenhuma das opções'],
    answer: 'B) A praia',
  },
  {
    question: 'Qual é o plural da palavra "cidadão"?',
    options: ['A) Cidadãos', 'B) Cidadãoses', 'C) Cidadães', 'D) Cidadões'],
    answer: 'A) Cidadãos',
  },
  {
    question: 'Qual é a função da vírgula na frase: "Ana, venha aqui agora!"?',
    options: ['A) Separar um aposto', 'B) Separar um vocativo', 'C) Separar orações coordenadas', 'D) Indicar uma pausa longa'],
    answer: 'B) Separar um vocativo',
  },
  {
    question: 'Em qual frase a palavra "que" é uma conjunção subordinativa?',
    options: ['A) O filme que assisti foi ótimo', 'B) Sei que você está cansado', 'C) A casa que compraram é grande', 'D) Não sei o que fazer'],
    answer: 'B) Sei que você está cansado',
  },
  {
    question: 'Qual é a forma correta da conjugação do verbo no futuro: "Nós ___ para a praia amanhã"?',
    options: ['A) Iremos', 'B) Vamos', 'C) Iríamos', 'D) Fomos'],
    answer: 'A) Iremos',
  },
];


  const handleAnswer = (option) => {
    if (isCorrect === null) { 
      const correct = option === questions[currentQuestion].answer;
      setIsCorrect(correct);

      if (correct) {
        setScore(score + 1); 
      } else {
        setErrors(errors + 1); 
      }
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion + 1 < questions.length) {
      setIsCorrect(null);
      setCurrentQuestion((prev) => prev + 1);
    } else {
      setIsQuizFinished(true);
    }
  };

  const getFinalMessage = () => {
    const percentage = (score / questions.length) * 100;

    if (percentage >= 80) {
      return 'Parabéns, você foi incrível!';
    } else if (percentage >= 50) {
      return 'Muito bem, mas podemos melhorar!';
    } else {
      return 'Estude mais um pouquinho!';
    }
  };

  return (
    <LinearGradient colors={['#ffe0b2', '#ff9800']} style={styles.background}>
      <View style={styles.container}>
        {isQuizFinished ? (
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>Quiz finalizado!</Text>
            <Text style={styles.resultText}>Acertos: {score}</Text>
            <Text style={styles.resultText}>Erros: {errors}</Text>
            <Text style={styles.resultMessage}>{getFinalMessage()}</Text>
          </View>
        ) : (
          <>
            <Text style={styles.question}>{questions[currentQuestion].question}</Text>
            
            <View style={styles.optionsContainer}>
              {questions[currentQuestion].options.map((option, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.optionButton, isCorrect !== null && styles.disabledOption]}
                  onPress={() => handleAnswer(option)}
                  disabled={isCorrect !== null}
                >
                  <Text style={styles.optionText}>{option}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {isCorrect !== null && (
              <Text style={isCorrect ? styles.correct : styles.incorrect}>
                {isCorrect ? 'Acertou!' : 'Errou!'}
              </Text>
            )}

            {isCorrect !== null && (
              <TouchableOpacity style={styles.nextButton} onPress={handleNextQuestion}>
                <Text style={styles.nextButtonText}>Próxima pergunta</Text>
              </TouchableOpacity>
            )}
          </>
        )}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginHorizontal: 20,
    elevation: 10, 
    shadowColor: '#FF6F00',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  question: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  optionsContainer: {
    marginBottom: 20,
  },
  optionButton: {
    backgroundColor: '#FF6F00',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  disabledOption: {
    backgroundColor: '#d3d3d3',
  },
  optionText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  correct: {
    fontSize: 22,
    color: '#4caf50',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  incorrect: {
    fontSize: 22,
    color: '#f44336',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  nextButton: {
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  nextButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  resultContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  resultMessage: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ff9800',
    marginTop: 20,
    textAlign: 'center',
  },
});

export default QuizScreen;
