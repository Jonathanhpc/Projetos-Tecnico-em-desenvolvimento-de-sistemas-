import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; 
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const tableMap = {
  'Profissional': 'profissional',
  'Aluno': 'alunos',
  'Instituição': 'instituicoes',
  'Usuário Comum': 'usuarios',
};

const CommunityScreen = ({ navigation }) => {
  const [messages, setMessages] = useState([]);
  const [userProfile, setUserProfile] = useState({});
  const [studentName, setStudentName] = useState('');
  const [email, setEmail] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isCommentVisible, setIsCommentVisible] = useState(false);
  const [comment, setComment] = useState('');
  const [currentMessageId, setCurrentMessageId] = useState(null);

  // Buscar o nome do aluno com base no email
  const fetchStudentDetails = async (email) => {
    try {
      const { data, error } = await supabase
        .from(tableMap['Aluno'])  
        .select('nome')
        .eq('email', email)
        .single();

      if (error) throw error;

      if (data) {
        setStudentName(data.nome);
      } else {
        console.log('No data found for email:', email);
      }
    } catch (error) {
      console.error('Erro ao buscar dados do aluno:', error.message);
    }
  };

  // Carregar as mensagens de todos os usuários cadastrados
  const fetchMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('messages') 
        .select('*');
      if (error) throw error;

      setMessages(data);
    } catch (error) {
      console.error('Erro ao buscar mensagens:', error.message);
    }
  };

  // Recuperar o email do usuário a partir do AsyncStorage
  const fetchEmailFromAsyncStorage = async () => {
    try {
      const userData = await AsyncStorage.getItem('userData');
      if (userData) {
        const parsedUserData = JSON.parse(userData);
        setEmail(parsedUserData.email);
        fetchStudentDetails(parsedUserData.email);
      }
    } catch (error) {
      console.error('Erro ao recuperar dados do usuário:', error);
    }
  };

  useEffect(() => {
    fetchEmailFromAsyncStorage();
    fetchMessages();
  }, []);

  // Função para adicionar nova mensagem
  const addMessage = async () => {
    if (!newMessage) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert([{ content: newMessage, user_name: studentName, user_photo: '', likes: 0 }]);

      if (error) throw error;
      setNewMessage('');
      fetchMessages();
      setIsModalVisible(false);
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error.message);
    }
  };

  // Função para adicionar comentário
  const addComment = async () => {
    if (!comment) return;

    try {
      const { data, error } = await supabase
        .from('comments')
        .insert([{ content: comment, user_name: studentName, message_id: currentMessageId }]);

      if (error) throw error;
      setComment('');
      setIsCommentVisible(false);
      fetchMessages(); // Recarrega as mensagens e comentários
    } catch (error) {
      console.error('Erro ao adicionar comentário:', error.message);
    }
  };

  // Função para adicionar like
  const addLike = async (messageId) => {
    try {
      const { data, error } = await supabase
        .from('likes')
        .insert([{ message_id: messageId }]);

      if (error) throw error;
      fetchMessages(); // Recarrega as mensagens e os likes
    } catch (error) {
      console.error('Erro ao adicionar like:', error.message);
    }
  };

  const renderMessageItem = ({ item }) => (
    <View style={styles.messageContainer}>
      <Text style={styles.messageText}>{item.content}</Text>
      <Text style={styles.authorText}>- {item.user_name}</Text>
      <View style={styles.actionsContainer}>
        <TouchableOpacity style={styles.actionButton} onPress={() => addLike(item.id)}>
          <Ionicons name="heart-outline" size={20} color="#FF5733" />
          <Text style={styles.actionText}>Curtir</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton} onPress={() => {
          setIsCommentVisible(true);
          setCurrentMessageId(item.id);
        }}>
          <Ionicons name="chatbubble-outline" size={20} color="#FF5733" />
          <Text style={styles.actionText}>Comentar</Text>
        </TouchableOpacity>
      </View>

      {isCommentVisible && currentMessageId === item.id && (
        <View style={styles.commentContainer}>
          <TextInput
            style={styles.input}
            value={comment}
            onChangeText={setComment}
            placeholder="Escreva seu comentário..."
          />
          <TouchableOpacity style={styles.sendButton} onPress={addComment}>
            <Text style={styles.buttonText}>Comentar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.cancelButton} onPress={() => setIsCommentVisible(false)}>
            <Text style={styles.buttonText}>Fechar</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={30} color="#fff" />
        </TouchableOpacity>

      </View>

      <FlatList
        data={messages}
        renderItem={renderMessageItem}
        keyExtractor={(item) => item.id.toString()}
      />

      <TouchableOpacity
        style={styles.floatingButton}
        onPress={() => setIsModalVisible(true)}
      >
        <Ionicons name="add" size={30} color="#fff" />
      </TouchableOpacity>

      <Modal visible={isModalVisible} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <TextInput
              style={styles.input}
              value={newMessage}
              onChangeText={setNewMessage}
              placeholder="Digite sua mensagem..."
            />
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setIsModalVisible(false)}>
                <Text style={styles.buttonText}>Fechar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sendButton} onPress={addMessage}>
                <Text style={styles.buttonText}>Publicar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  navbar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    padding: 15,
  },
  
  messageContainer: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#f1f1f1',
    borderRadius: 5,
  },
  messageText: {
    fontSize: 16,
    marginBottom: 5,
  },
  authorText: {
    fontSize: 12,
    color: '#555',
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionText: {
    marginLeft: 5,
    fontSize: 14,
  },
  commentContainer: {
    marginTop: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  sendButton: {
    backgroundColor: '#FF5733',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  floatingButton: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    backgroundColor: '#FF5733',
    borderRadius: 50,
    padding: 15,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    maxWidth: 400,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
});

export default CommunityScreen;
