import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const QuizScreen = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isCorrect, setIsCorrect] = useState(null);
  const [score, setScore] = useState(0);
  const [errors, setErrors] = useState(0);
  const [isQuizFinished, setIsQuizFinished] = useState(false);

 const questions = [
    {    
      question: 'Qual das seguintes opções é uma característica exclusiva das células eucarióticas?',
      options: ['A) Presença de ribossomos', 'B) Parede celular', 'C) Presença de núcleo definido', 'D) Ausência de mitocôndrias'],
      answer: 'C) Presença de núcleo definido',
    },
    {
      question: 'Qual é a função principal da mitocôndria?',
      options: ['A) Síntese de proteínas', 'B) Produção de ATP', 'C) Armazenamento de lipídios', 'D) Degradação de toxinas'],
      answer: 'B) Produção de ATP',
    },
    {
      question: 'A fotossíntese ocorre em qual organela da célula vegetal?',
      options: ['A) Mitocôndria', 'B) Lisossomo', 'C) Cloroplasto', 'D) Ribossomo'],
      answer: 'C) Cloroplasto',
    },
    {
      question: 'Qual é o nome do processo de divisão celular que resulta em células-filhas geneticamente idênticas à célula-mãe?',
      options: ['A) Meiose', 'B) Mitose', 'C) Fusão celular', 'D) Apoptose'],
      answer: 'B) Mitose',
    },
    {
      question: 'O grupo dos artrópodes inclui qual destes animais?',
      options: ['A) Sapo', 'B) Borboleta', 'C) Peixe', 'D) Minhoca'],
      answer: 'B) Borboleta',
    },
    {
      question: 'Qual é a função do sistema digestório?',
      options: ['A) Realizar trocas gasosas com o meio ambiente', 'B) Absorver nutrientes dos alimentos', 'C) Transportar oxigênio no sangue', 'D) Produzir hormônios'],
      answer: 'B) Absorver nutrientes dos alimentos',
    },
    {
      question: 'O DNA é composto por unidades chamadas de:',
      options: ['A) Aminoácidos', 'B) Nucleotídeos', 'C) Ácidos graxos', 'D) Monossacarídeos'],
      answer: 'B) Nucleotídeos',
    },
    {
      question: 'O transporte de oxigênio no sangue é realizado principalmente por:',
      options: ['A) Plaquetas', 'B) Glóbulos brancos', 'C) Hemoglobina', 'D) Plasma'],
      answer: 'C) Hemoglobina',
    },
    {
      question: 'Qual é a função dos ribossomos nas células?',
      options: ['A) Produção de energia', 'B) Armazenamento de gordura', 'C) Síntese de proteínas', 'D) Digestão de substâncias'],
      answer: 'C) Síntese de proteínas',
    },
    {
      question: 'Os anfíbios são caracterizados por:',
      options: ['A) Respiração exclusivamente pulmonar', 'B) Ciclo de vida dependente da água', 'C) Presença de escamas', 'D) Ausência de esqueleto'],
      answer: 'B) Ciclo de vida dependente da água',
    },
  ];

  const handleAnswer = (option) => {
    if (isCorrect === null) { 
      const correct = option === questions[currentQuestion].answer;
      setIsCorrect(correct);

      if (correct) {
        setScore(score + 1); 
      } else {
        setErrors(errors + 1); 
      }
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion + 1 < questions.length) {
      setIsCorrect(null);
      setCurrentQuestion((prev) => prev + 1);
    } else {
      setIsQuizFinished(true);
    }
  };

  const getFinalMessage = () => {
    const percentage = (score / questions.length) * 100;

    if (percentage >= 80) {
      return 'Parabéns, você foi incrível!';
    } else if (percentage >= 50) {
      return 'Muito bem, mas podemos melhorar!';
    } else {
      return 'Estude mais um pouquinho!';
    }
  };

  return (
    <LinearGradient colors={['#ffe0b2', '#ff9800']} style={styles.background}>
      <View style={styles.container}>
        {isQuizFinished ? (
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>Quiz finalizado!</Text>
            <Text style={styles.resultText}>Acertos: {score}</Text>
            <Text style={styles.resultText}>Erros: {errors}</Text>
            <Text style={styles.resultMessage}>{getFinalMessage()}</Text>
          </View>
        ) : (
          <>
            <Text style={styles.question}>{questions[currentQuestion].question}</Text>
            
            <View style={styles.optionsContainer}>
              {questions[currentQuestion].options.map((option, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.optionButton, isCorrect !== null && styles.disabledOption]}
                  onPress={() => handleAnswer(option)}
                  disabled={isCorrect !== null}
                >
                  <Text style={styles.optionText}>{option}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {isCorrect !== null && (
              <Text style={isCorrect ? styles.correct : styles.incorrect}>
                {isCorrect ? 'Acertou!' : 'Errou!'}
              </Text>
            )}

            {isCorrect !== null && (
              <TouchableOpacity style={styles.nextButton} onPress={handleNextQuestion}>
                <Text style={styles.nextButtonText}>Próxima pergunta</Text>
              </TouchableOpacity>
            )}
          </>
        )}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginHorizontal: 20,
    elevation: 10, 
    shadowColor: '#FF6F00',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  question: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  optionsContainer: {
    marginBottom: 20,
  },
  optionButton: {
    backgroundColor: '#FF6F00',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  disabledOption: {
    backgroundColor: '#d3d3d3',
  },
  optionText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  correct: {
    fontSize: 22,
    color: '#4caf50',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  incorrect: {
    fontSize: 22,
    color: '#f44336',
    textAlign: 'center',
    marginTop: 20,
    fontWeight: 'bold',
  },
  nextButton: {
    backgroundColor: '#FF6F00',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  nextButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  resultContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
    textAlign: 'center',
  },
  resultMessage: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ff9800',
    marginTop: 20,
    textAlign: 'center',
  },
});

export default QuizScreen;
