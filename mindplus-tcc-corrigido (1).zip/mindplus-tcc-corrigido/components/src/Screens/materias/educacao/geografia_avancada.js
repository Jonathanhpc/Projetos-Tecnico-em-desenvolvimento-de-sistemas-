import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const AdvancedGeographyScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Geografia Avançada
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Geografia Física Avançada</Text>{"\n"}
                - Tectônica de Placas: Estudo das interações complexas entre as placas tectônicas, como a subducção e o impacto sobre a formação de cadeias montanhosas e terremotos. Exemplo: a formação dos Andes.
                {"\n"}{"\n"}
                - Geomorfologia: Análise detalhada dos processos que moldam a superfície terrestre, como a erosão e sedimentação. Exemplo: o papel dos glaciares na formação de vales em U.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Climatologia Avançada</Text>{"\n"}
                - Modelos Climáticos: Utilização de modelos matemáticos para prever mudanças climáticas e suas implicações. Exemplo: modelos de circulação atmosférica e sua previsão para alterações no clima global.
                {"\n"}{"\n"}
                - Microclimas: Estudo de variações climáticas em pequena escala, influenciadas por fatores locais. Exemplo: microclimas urbanos e seu impacto na temperatura local.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Geografia Humana Avançada</Text>{"\n"}
                - Urbanização Global: Análise dos padrões de urbanização e seus impactos econômicos, sociais e ambientais. Exemplo: o fenômeno das cidades globais e seu papel na economia mundial.
                {"\n"}{"\n"}
                - Mobilidade e Migração: Estudos sobre fluxos migratórios internacionais e seus efeitos na dinâmica populacional e cultural. Exemplo: a migração forçada devido a crises climáticas e conflitos.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Geopolítica e Relações Internacionais</Text>{"\n"}
                - Conflitos e Geopolítica: Estudo dos conflitos internacionais e seu impacto na geopolítica global. Exemplo: a influência das disputas territoriais no Oriente Médio.
                {"\n"}{"\n"}
                - Economia Política Global: Análise das relações entre economia e poder político em uma escala global. Exemplo: a influência das potências econômicas nas políticas internacionais.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>5. Geografia Ambiental</Text>{"\n"}
                - Gestão de Recursos Naturais: Estratégias para a gestão sustentável de recursos naturais, como água e minerais. Exemplo: práticas de gestão integrada de bacias hidrográficas.
                {"\n"}{"\n"}
                - Impactos Ambientais: Avaliação dos impactos das atividades humanas sobre o meio ambiente e estratégias para mitigação. Exemplo: o impacto da deflorestação na biodiversidade.
                {"\n"}{"\n"}
                <Text style={styles.conclusionText}>
                A Geografia Avançada proporciona uma compreensão aprofundada dos processos naturais e humanos, além de sua interação complexa. Este conhecimento é fundamental para enfrentar os desafios ambientais e sociais globais e promover a sustentabilidade.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default AdvancedGeographyScreen;
