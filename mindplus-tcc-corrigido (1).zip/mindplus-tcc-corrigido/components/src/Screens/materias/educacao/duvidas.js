import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground, Dimensions, ScrollView, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const FAQScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    setSidebar(prev => !prev);
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100' 
      });
    }, 1000); 
  }, []);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="#FFF" />
          </TouchableOpacity>
          
          <TouchableOpacity onPress={openDrawer} style={styles.navButton}>
            <Ionicons name="menu" size={24} color="#FFF" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image source={{ uri: user.photo }} style={styles.userPhoto} />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity onPress={() => navigation.navigate('configuracao')} style={styles.sidebarButton}>
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigation.navigate('avaliacao')} style={styles.sidebarButton}>
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigation.navigate('Login')} style={styles.sidebarButton}>
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>
          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <Text style={styles.tituloText}>Dúvidas Frequentes</Text>
            
            {faqData.map((item, index) => (
              <View key={index} style={styles.faqItem}>
                <Text style={styles.subTitle}>{item.title}</Text>
                <Image source={item.image} style={styles.image} />
                <Text style={styles.contentText}>{item.text}</Text>
              </View>
            ))}

            <View style={styles.conclusionContainer}>
              <Text style={styles.conclusion}>
                Estamos aqui para ajudar! Aproveite o app e divirta-se estudando!
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const faqData = [
  {
    title: "Como o app me ajuda?",
    image: require('../../../Images/central-de-ajuda.png'),
    text: "Auxilia na organização e no foco nos estudos!"
  },
  {
    title: "Quais matérias?",
    image: require('../../../Images/pilha-de-livros.png'),
    text: "Matemática, ciências, história e mais!"
  },
  {
    title: "Jogos educativos?",
    image: require('../../../Images/controle-de-video-game.png'),
    text: "Aprenda brincando e se divertindo!"
  },
  {
    title: "O que é o cronograma?",
    image: require('../../../Images/schedule.png'),
    text: "Organize seus estudos de forma fácil!"
  }
];

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.07,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  faqItem: {
    backgroundColor: '#FFFFFF',
    padding: width * 0.05,
    borderRadius: 15,
    alignItems: 'center',
    width: '100%',
    marginBottom: height * 0.02,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
    marginBottom: 10,
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'center',
    marginTop: height * 0.01,
  },
  image: {
    width: width * 0.3,
    height: width * 0.3,
    marginVertical: height * 0.02,
    resizeMode: 'contain',
  },
  conclusionContainer: {
    alignItems: 'center',
    marginTop: height * 0.02,
    padding: width * 0.05,
    borderRadius: 10,
    backgroundColor: '#FF6F00',
    width: '100%',
  },
  conclusion: {
    fontSize: width * 0.04,
    color: '#FFF',
    textAlign: 'center',
  },
  sidebar: {
    position: 'absolute',
    top: 0,
    left: 0,
    height: height,
    width: width * 0.75,
    backgroundColor: '#FFF',
    padding: 20,
    elevation: 5,
    zIndex: 3,
  },
  userContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  userPhoto: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
    backgroundColor: '#FF6F00',
  },
  sidebarButtonText: {
    color: '#FFF',
    textAlign: 'center',
  },
});

export default FAQScreen;
