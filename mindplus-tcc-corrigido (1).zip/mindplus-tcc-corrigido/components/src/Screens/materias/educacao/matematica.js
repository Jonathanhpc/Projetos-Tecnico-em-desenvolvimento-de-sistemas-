import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const SignupScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <View style={styles.content}>
          <View style={styles.textContainer}>
            <Text style={styles.tituloText}>
              A matemática é uma ciência fundamental que explora padrões, estruturas e relações lógicas entre números e formas. Ela é essencial em diversas áreas, como ciência, engenharia e economia, e desenvolve habilidades de raciocínio lógico e resolução de problemas.
            </Text>
          </View>

          <View style={styles.buttonContainer}>
            <TouchableOpacity 
              onPress={() => navigation.navigate('matematica_basica')} 
              style={styles.button}
              accessibilityLabel="Matemática Básica"
            >
              <Text style={styles.buttonText}>Matemática Básica</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('matematica_intermediaria')} 
              style={styles.button}
              accessibilityLabel="Matemática Individual"
            >
              <Text style={styles.buttonText}>Matemática Intermediária</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('matematica_avancada')} 
              style={styles.button}
              accessibilityLabel="Matemática Avançada"
            >
              <Text style={styles.buttonText}>Matemática Avançada</Text>
            </TouchableOpacity>

             <TouchableOpacity 
              onPress={() => navigation.navigate('quiz_matematica')} 
              style={styles.button}
              accessibilityLabel="Quiz Matemática"
            >
              <Text style={styles.buttonText}>Quiz Matemática</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: height * 0.1,
  },
  textContainer: {
    backgroundColor: '#F5F5F5', // Cinza claro
    padding: width * 0.05,
    borderRadius: 20,
    marginBottom: height * 0.03,
    alignItems: 'center',
    width: '90%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.05,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonContainer: {
    width: '90%',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: height * 0.05,
  },
  button: {
    backgroundColor: '#FF6F00', // Alterado para laranja
    borderRadius: 12,
    paddingVertical: height * 0.02,
    paddingHorizontal: width * 0.1,
    width: '80%',
    marginBottom: height * 0.02,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  buttonText: {
    fontSize: width * 0.04,
    color: '#FFF', // Texto em branco
    fontWeight: 'bold',
  },
});

export default SignupScreen;
