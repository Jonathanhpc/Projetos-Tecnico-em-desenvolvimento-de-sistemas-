import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ImageBackground, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const IntermediateChemistryScreen = () => {
  const navigation = useNavigation();
  const [sidebar, setSidebar] = useState(false); 
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });

  const goBack = () => {
    navigation.goBack();
  };

  useEffect(() => {
    setTimeout(() => {
      setUser({
        name: 'João da Silva',
        photo: 'https://via.placeholder.com/100'
      });
    }, 1000);
  }, []);

  const showSidebar = () => setSidebar(prev => !prev);

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../../Images/fundo.png')}
        style={styles.background}
      >
        <View style={styles.navBar}>
          <TouchableOpacity onPress={goBack} style={styles.navButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={showSidebar}
            style={styles.navButton}
            accessibilityLabel="Open Sidebar"
          >
            <Ionicons name="menu" size={24} color="white" />
          </TouchableOpacity>
        </View>

        {sidebar && (
          <View style={styles.sidebar}>
            <View style={styles.userContainer}>
              <Image
                source={{ uri: user.photo }}
                style={styles.userPhoto}
              />
              <Text style={styles.userName}>{user.name}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => navigation.navigate('configuracao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Configuração</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('avaliacao')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')} 
              style={styles.sidebarButton}
            >
              <Text style={styles.sidebarButtonText}>Logout</Text>
            </TouchableOpacity>

          </View>
        )}

        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.content}>
            <View style={styles.textContainer}>
              <Text style={styles.tituloText}>
                Química Intermediária
              </Text>
              <Text style={styles.contentText}>
                <Text style={styles.subTitle}>1. Estequiometria</Text>{"\n"}
                - Cálculos estequiométricos: Relação entre os reagentes e produtos de uma reação química. Exemplo: como calcular a quantidade de reagentes necessários para produzir uma determinada quantidade de produto.
                {"\n"}{"\n"}
                - Pureza dos Reagentes e Rendimento Percentual: Conceitos de rendimento teórico, real e percentual em reações químicas.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>2. Soluções Químicas</Text>{"\n"}
                - Concentração de Soluções: Tipos de concentração como molaridade, molalidade e fração molar.
                {"\n"}{"\n"}
                - Propriedades Coligativas: Efeitos da adição de solutos em solventes, como ponto de ebulição e congelamento. Exemplo: o efeito da adição de sal na água para aumentar seu ponto de ebulição.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>3. Cinética Química</Text>{"\n"}
                - Velocidade das Reações: Fatores que afetam a velocidade das reações químicas, como concentração, temperatura e catalisadores.
                {"\n"}{"\n"}
                - Teoria das Colisões e Energia de Ativação: Como a teoria das colisões explica a velocidade das reações e o papel da energia de ativação.
                {"\n"}{"\n"}

                <Text style={styles.subTitle}>4. Equilíbrio Químico</Text>{"\n"}
                - Princípio de Le Chatelier: Como o sistema em equilíbrio reage a mudanças de concentração, pressão e temperatura. Exemplo: o que acontece em um sistema de equilíbrio quando a pressão é aumentada.
                {"\n"}{"\n"}
                - Constante de Equilíbrio: Como calcular a constante de equilíbrio (Kc e Kp) e o que ela significa em termos de posição do equilíbrio.
                {"\n"}{"\n"}

                <Text style={styles.conclusionText}>
                O estudo da estequiometria, das soluções e do equilíbrio químico é fundamental para entender o comportamento das substâncias em diferentes condições. Continue praticando para aperfeiçoar suas habilidades na resolução de problemas e na compreensão das reações químicas.
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1, 
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  navButton: {
    padding: width * 0.02,
    borderRadius: width * 0.1,
  },
  sidebar: {
    position: 'absolute',
    top: height * 0.1,
    left: 0,
    width: width * 0.8,
    height: height * 0.9,
    backgroundColor: '#FFF',
    zIndex: 3,
    padding: 20,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  userPhoto: {
    width: width * 0.3,
    height: width * 0.3,
    borderRadius: width * 0.15,
    marginBottom: 10,
  },
  userName: {
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
  sidebarButton: {
    padding: width * 0.03,
    marginVertical: height * 0.01,
    backgroundColor: '#FF6F00',
    borderRadius: 12,
    alignItems: 'center',
  },
  sidebarButtonText: {
    fontSize: width * 0.04,
    color: '#FFF',
    fontWeight: 'bold',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  content: {
    alignItems: 'center',
    marginTop: height * 0.1,
    paddingHorizontal: width * 0.05,
  },
  textContainer: {
    backgroundColor: '#F5F5F5',
    padding: width * 0.05,
    borderRadius: 20,
    alignItems: 'center',
    width: '100%',
  },
  tituloText: {
    color: '#000',
    fontSize: width * 0.06,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: height * 0.02,
  },
  subTitle: {
    fontSize: width * 0.05,
    fontWeight: 'bold',
    color: '#FF6F00',
  },
  contentText: {
    color: '#333',
    fontSize: width * 0.04,
    textAlign: 'justify',
  },
  conclusionText: {
    marginTop: height * 0.02,
    fontSize: width * 0.04,
    color: '#333',
    textAlign: 'center',
  }
});

export default IntermediateChemistryScreen;
