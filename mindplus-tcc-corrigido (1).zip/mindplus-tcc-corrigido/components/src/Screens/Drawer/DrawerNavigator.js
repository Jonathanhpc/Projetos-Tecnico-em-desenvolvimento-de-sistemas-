import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import CustomDrawerContent from './CustomDrawerContent'; // Importa o custom drawer

import HomeScreen from '../../Screens/LoginScreen'; // Verifique o caminho correto
import InstituicaoScreen from '../../Screens/CadastroInstituicao'; // Verifique o caminho correto
import avaliacao from '../../Screens/instituicao/Avaliacao'; // Corrija o caminho para o arquivo correto

const Drawer = createDrawerNavigator();

const DrawerNavigator = () => {
  return (
    <NavigationContainer>
      <Drawer.Navigator drawerContent={(props) => <CustomDrawerContent {...props} />}>
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Profile" component={InstituicaoScreen} />
        <Drawer.Screen name="Aprovacao" component={SignupScreen} /> {/* Use "Aprovacao" como nome da rota */}
      </Drawer.Navigator>
    </NavigationContainer>
  );
};

export default DrawerNavigator;
