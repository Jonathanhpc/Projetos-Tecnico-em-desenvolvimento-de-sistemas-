import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, StatusBar } from 'react-native';
import { createClient } from '@supabase/supabase-js';
import { LinearGradient } from 'expo-linear-gradient';

// Substitua pelas suas credenciais do Supabase
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const PasswordRecoveryScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  // Função para recuperar a senha
  const handlePasswordRecovery = async () => {
    if (!email) {
      Alert.alert('Erro', 'Por favor, insira seu e-mail.');
      return;
    }

    setLoading(true);

    try {
      // Verificar se o e-mail está registrado em qualquer uma das tabelas
      const { data, error } = await supabase
        .from('alunos')
        .select('email')
        .eq('email', email)
        .single();  // Pega apenas um item

      if (error || !data) {
        // Tentar em alunos_instituicao caso não encontrado em alunos
        const { data: instituicaoData, error: instituicaoError } = await supabase
          .from('alunos_instituicao')
          .select('email')
          .eq('email', email)
          .single();  // Pega apenas um item

        if (instituicaoError || !instituicaoData) {
          setLoading(false);
          Alert.alert('Erro', 'Este e-mail não está cadastrado.');
          return;
        }
      }

      // Chama a função que envia o e-mail de recuperação de senha
      const { error: sendError } = await supabase
        .rpc('send_password_recovery_email', { user_email: email });

      if (sendError) {
        setLoading(false);
        Alert.alert('Erro', 'Não foi possível enviar o e-mail de recuperação.');
        return;
      }

      setLoading(false);
      Alert.alert('Sucesso', 'Um e-mail de recuperação foi enviado para o seu endereço!');
      navigation.navigate('Login');
    } catch (error) {
      console.error('Erro ao enviar o e-mail:', error);
      setLoading(false);
      Alert.alert('Erro', 'Houve um problema ao tentar enviar o e-mail de recuperação.');
    }
  };

  return (
    <LinearGradient colors={['#f46a14', '#f46a14']} style={styles.background}>
      <StatusBar barStyle="light-content" backgroundColor="#f46a14" />
      <View style={styles.container}>
        <Text style={styles.title}>Recuperação de Senha</Text>
        
        {/* Campo para e-mail */}
        <TextInput
          style={styles.input}
          placeholder="E-mail"
          placeholderTextColor="#888888"
          value={email}
          onChangeText={setEmail}
        />

        {loading ? (
          <Text style={styles.loadingText}>Processando...</Text>
        ) : (
          <TouchableOpacity style={styles.button} onPress={handlePasswordRecovery}>
            <Text style={styles.buttonText}>ENVIAR E-MAIL</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.backToLoginText}>Voltar para o Login</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: { flex: 1 },
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 10 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#f46a14' },
  input: { width: '100%', height: 40, backgroundColor: '#d6cfcb', borderRadius: 10, paddingHorizontal: 20, marginBottom: 15, color: '#000' },
  button: { width: '80%', height: 50, backgroundColor: '#FFFAFA', borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginTop: 20 },
  buttonText: { color: 'Black', fontSize: 18, fontWeight: 'bold' },
  backToLoginText: { color: 'white', fontSize: 14, textDecorationLine: 'underline', marginTop: 20 },
  loadingText: { color: 'white', fontSize: 16, marginTop: 20, textAlign: 'center' },
});

export default PasswordRecoveryScreen;
