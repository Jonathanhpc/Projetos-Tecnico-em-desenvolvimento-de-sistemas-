import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, StyleSheet, Dimensions, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const SignupScreen = () => {
  const navigation = useNavigation();
  const [comment, setComment] = useState('');

  // Função para abrir o drawer
  const openDrawer = () => {
    navigation.openDrawer(); 
  };

  // Função para voltar para a tela anterior
  const goBack = () => {
    navigation.goBack();
  };

  // Função para enviar o comentário
  const submitComment = () => {
    if (comment.trim() === '') {
      Alert.alert('Erro', 'Por favor, insira um comentário antes de enviar.');
    } else {
      Alert.alert('Comentário Enviado', 'Obrigado pelo seu feedback!');
      setComment(''); // Limpa o campo de comentário após o envio
    }
  };

  return (
    <View style={styles.container}>
      <ImageBackground 
        source={require('../../Images/fundo.png')}
        style={styles.background}
      >
        {/* Barra de Navegação com Botão de Voltar e Botão de Menu Lateral */}
        <View style={styles.navBar}>
          <TouchableOpacity 
            onPress={goBack} 
            style={styles.navButton}
            accessibilityLabel="Voltar"
            accessibilityHint="Volta para a tela anterior"
          >
            <Ionicons name="arrow-back" size={24} color="#FFF" />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={openDrawer} 
            style={styles.navButton}
            accessibilityLabel="Menu"
            accessibilityHint="Abre o menu lateral"
          >
            <Ionicons name="menu" size={24} color="#FFF" />
          </TouchableOpacity>
        </View>

        <View style={styles.content}>
          <View style={styles.orangeContainer}>
            <Text style={styles.label}>Deixe seu comentário:</Text>
          </View>

          <View style={styles.commentContainer}>
            <TextInput
              style={styles.textInput}
              placeholder="Escreva sua avaliação aqui..."
              placeholderTextColor="#999"
              value={comment}
              onChangeText={setComment}
              multiline
            />
          </View>

          <TouchableOpacity onPress={submitComment} style={styles.submitButton}>
            <Text style={styles.submitButtonText}>Enviar</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  navBar: {
    width: '100%',
    height: height * 0.1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    backgroundColor: '#FF6F00',
    position: 'absolute',
    top: 0,
    zIndex: 1,
  },
  navButton: {
    padding: width * 0.02, 
    borderRadius: width * 0.1,
    color: '#FFF',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: width * 0.05,
    marginTop: height * 0.1,
  },
  orangeContainer: {
    backgroundColor: '#FFA500',
    padding: width * 0.04,
    borderRadius: 12,
    marginBottom: height * 0.02,
    width: '100%',
    alignItems: 'center',
  },
  commentContainer: {
    backgroundColor: '#FFF',
    padding: width * 0.05,
    borderRadius: 12,
    width: '100%',
    marginBottom: height * 0.03,
  },
  label: {
    color: '#000',
    fontSize: width * 0.04,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  textInput: {
    height: height * 0.2,
    borderColor: '#DDD',
    borderWidth: 1,
    borderRadius: 8,
    padding: width * 0.04,
    textAlignVertical: 'top',
    fontSize: width * 0.04,
    color: '#333',
  },
  submitButton: {
    backgroundColor: '#FF6F00',
    padding: width * 0.04,
    borderRadius: 12,
    alignItems: 'center',
    width: '50%',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  submitButtonText: {
    color: '#FFF',
    fontSize: width * 0.04,
    fontWeight: 'bold',
  },
});

export default SignupScreen;
