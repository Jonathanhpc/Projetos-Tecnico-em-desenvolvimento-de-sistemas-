import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Alert, Modal, TextInput, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../supabaseClient'; // Certifique-se de configurar o Supabase corretamente

const ProfessorScreen = () => {
  const navigation = useNavigation();
  const [professors, setProfessors] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedProfessor, setSelectedProfessor] = useState(null);
  const [sidebar, setSidebar] = useState(false);
  const [user, setUser] = useState({ name: 'Carregando...', photo: null });
  const [institutionCode, setInstitutionCode] = useState('');

  useEffect(() => {
    const fetchUserData = async () => {
      const email = await AsyncStorage.getItem('userData'); // Recupera o email da instituição logada
      fetchInstitutionCodeByEmail(email);
    };
    fetchUserData();

    // Chama a função para adicionar um profissional fictício
    addFakeProfessor();
  }, []);

  // Função para adicionar um profissional fictício na tabela
  const addFakeProfessor = async () => {
    // Dados fictícios de um professor
    const fakeProfessor = {
      nome_completo: 'João Silva',
      telefone: '11987654321',
      email: 'joao.silva@instituicao.com',
      data_nascimento: '1985-08-15',
      endereco: 'Rua Fictícia, 123, Cidade Exemplo',
      codigo_instituicao: institutionCode, // Certifique-se de usar o código correto da instituição
    };

    const { data, error } = await supabase
      .from('profissional')
      .insert([fakeProfessor]);

    if (error) {
      console.log('Erro ao adicionar profissional fictício:', error);
      Alert.alert('Erro', 'Não foi possível adicionar o profissional fictício.');
    } else {
      console.log('Profissional fictício adicionado:', data);
      fetchProfessorsByInstitutionCode(institutionCode); // Atualiza a lista de professores
    }
  };

  // Função para buscar o código da instituição com base no email
  const fetchInstitutionCodeByEmail = async (email) => {
    const { data, error } = await supabase
      .from('instituicoes')
      .select('codigo')
      .eq('email', email)
      .single();  // Usamos .single() para garantir que estamos pegando um único resultado

    if (error || !data) {
      Alert.alert('Erro', 'Erro ao carregar código da instituição');
      console.log(error);
    } else {
      setInstitutionCode(data.codigo); // Define o código da instituição
      fetchProfessorsByInstitutionCode(data.codigo); // Busca os professores com o código
    }
  };

  // Função para buscar professores pela instituição com o código
  const fetchProfessorsByInstitutionCode = async (codigo) => {
    const { data, error } = await supabase
      .from('profissional')
      .select('*')
      .eq('codigo_instituicao', codigo); // Filtra pelos professores da instituição

    if (error) {
      Alert.alert('Erro', 'Erro ao carregar profissionais');
      console.log(error);
    } else {
      setProfessors(data);
    }
  };

  // Função para excluir um professor
  const handleDeleteProfessor = async (id) => {
    const { error } = await supabase
      .from('profissional')
      .delete()
      .eq('id', id);

    if (error) {
      Alert.alert('Erro', 'Erro ao deletar professor');
      console.log(error);
    } else {
      setProfessors(professors.filter(prof => prof.id !== id)); // Remove o professor da lista
      Alert.alert('Sucesso', 'Professor excluído com sucesso');
    }
  };

  // Função para abrir o modal de edição
  const handleEditProfessor = (professor) => {
    setSelectedProfessor(professor); // Setar o professor que será editado
    setIsModalVisible(true); // Abrir o modal
  };

  // Função para salvar as alterações do professor
  const handleSaveChanges = async () => {
    const { nome_completo, telefone, endereco, email, data_nascimento } = selectedProfessor;

    const { error } = await supabase
      .from('profissional')
      .update({ nome_completo, telefone, endereco, email, data_nascimento })
      .eq('id', selectedProfessor.id);

    if (error) {
      Alert.alert('Erro', 'Erro ao salvar alterações');
      console.log(error);
    } else {
      fetchProfessorsByInstitutionCode(institutionCode); // Atualizar a lista de professores
      setIsModalVisible(false); // Fechar o modal
      Alert.alert('Sucesso', 'Alterações salvas com sucesso');
    }
  };

  const openDrawer = () => {
    setSidebar(prev => !prev);
  };

  return (
    <View style={styles.container}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.navButton}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>

        <TouchableOpacity onPress={openDrawer} style={styles.navButton}>
          <Ionicons name="menu" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      {sidebar && (
        <View style={styles.sidebar}>
          <View style={styles.userContainer}>
            <Image
              source={{ uri: user.photo }}
              style={styles.userPhoto}
            />
            <Text style={styles.userName}>{user.name}</Text>
          </View>

          <TouchableOpacity onPress={() => navigation.navigate('Configuracao')} style={styles.sidebarButton}>
            <Text style={styles.sidebarButtonText}>Configuração</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Avaliacao')} style={styles.sidebarButton}>
            <Text style={styles.sidebarButtonText}>Gostou do App?</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Login')} style={styles.sidebarButton}>
            <Text style={styles.sidebarButtonText}>Logout</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.content}>
        <Text style={styles.title}>Gerenciar Professores</Text>

        <FlatList
          data={professors}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.professorItem}>
              <View style={styles.professorDetails}>
                <Text style={styles.professorName}>{item.nome_completo}</Text>
                <Text style={styles.professorInfo}>
                  Telefone: {item.telefone} | Email: {item.email} | Data de Nascimento: {item.data_nascimento}
                </Text>
              </View>

              <View style={styles.actions}>
                <TouchableOpacity onPress={() => handleEditProfessor(item)}>
                  <Ionicons name="pencil" size={24} color="#FF6F00" />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleDeleteProfessor(item.id)}>
                  <Ionicons name="trash" size={24} color="#FF6F00" />
                </TouchableOpacity>
              </View>
            </View>
          )}
        />

        {/* Modal para Editar Profissional */}
        <Modal
          visible={isModalVisible}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setIsModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Editar Professor</Text>

              <TextInput
                style={styles.input}
                value={selectedProfessor?.nome_completo}
                placeholder="Nome Completo"
                onChangeText={(text) => setSelectedProfessor({ ...selectedProfessor, nome_completo: text })}
              />
              <TextInput
                style={styles.input}
                value={selectedProfessor?.telefone}
                placeholder="Telefone"
                onChangeText={(text) => setSelectedProfessor({ ...selectedProfessor, telefone: text })}
              />
              <TextInput
                style={styles.input}
                value={selectedProfessor?.email}
                placeholder="Email"
                onChangeText={(text) => setSelectedProfessor({ ...selectedProfessor, email: text })}
              />
              <TextInput
                style={styles.input}
                value={selectedProfessor?.data_nascimento}
                placeholder="Data de Nascimento"
                onChangeText={(text) => setSelectedProfessor({ ...selectedProfessor, data_nascimento: text })}
              />
              <TextInput
                style={styles.input}
                value={selectedProfessor?.endereco}
                placeholder="Endereço"
                onChangeText={(text) => setSelectedProfessor({ ...selectedProfessor, endereco: text })}
              />

              <TouchableOpacity
                style={styles.button}
                onPress={handleSaveChanges}
              >
                <Text style={styles.buttonText}>Salvar Alterações</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.button}
                onPress={() => setIsModalVisible(false)}
              >
                <Text style={styles.buttonText}>Fechar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF6F00',
    marginBottom: 20,
    textAlign: 'center',
  },
  navBar: {
    width: '100%',
    height: 50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FF6F00',
    paddingHorizontal: 10,
    elevation: 4,
  },
  navButton: {
    padding: 10,
  },
  professorItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#FFF',
    borderRadius: 10,
    marginBottom: 10,
    elevation: 2,
    width: '90%',
    alignSelf: 'center',
  },
  professorDetails: {
    flex: 1,
  },
  professorName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  professorInfo: {
    color: '#555',
    marginTop: 5,
  },
  actions: {
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  input: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 12,
    marginBottom: 15,
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#FF6F00',
    padding: 12,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  sidebar: {
    width: 250,
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: '#FF6F00',
    padding: 15,
    elevation: 4,
  },
  sidebarButton: {
    marginVertical: 10,
  },
  sidebarButtonText: {
    color: '#FFF',
    fontSize: 16,
  },
  userContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  userPhoto: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  userName: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
  },
});

export default ProfessorScreen;
