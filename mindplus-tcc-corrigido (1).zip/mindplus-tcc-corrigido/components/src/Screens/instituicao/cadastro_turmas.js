import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image, StatusBar, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { createClient } from '@supabase/supabase-js';
import axios from 'axios';

// Configurações do Supabase
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; // Substitua pela sua URL do Supabase
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; // Substitua pela sua chave anônima do Supabase
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const CadastroTurmaScreen = ({ navigation }) => {
  const [nomeTurma, setNomeTurma] = useState('');
  const [codigoTurma, setCodigoTurma] = useState('');
  const [nivel, setNivel] = useState('');
  const [ano, setAno] = useState('');
  const [turno, setTurno] = useState('');
  const [descricao, setDescricao] = useState('');
  const [instituicaoId, setInstituicaoId] = useState('');

  const handleRegister = async () => {
    if (!nomeTurma || !codigoTurma || !nivel || !ano || !turno || !descricao || !instituicaoId) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('turmas')
        .insert([
          { 
            nome_turma: nomeTurma,
            codigo_turma: codigoTurma,
            nivel,
            ano,
            turno,
            descricao,
            instituicao_id: instituicaoId
          }
        ]);

      if (error) {
        Alert.alert('Erro', error.message);
      } else {
        Alert.alert('Sucesso', 'Cadastro de turma realizado com sucesso!');
        navigation.replace('Home');
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível realizar o cadastro.');
    }
  };

  return (
    <LinearGradient colors={['#f46a14', '#f46a14']} style={styles.background}>
      <StatusBar barStyle="light-content" backgroundColor="#f46a14" />
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.logoContainer}>
          <Image source={require('../../Icons/LogoMax/logo.png')} style={styles.logoImage} />
        </View>
        
        <View style={styles.cadastroTurmaContainer}>
          <TextInput
            style={styles.input}
            placeholder="Nome da Turma"
            placeholderTextColor="#888888"
            value={nomeTurma}
            onChangeText={setNomeTurma}
          />
          <TextInput
            style={styles.input}
            placeholder="Código da Turma"
            placeholderTextColor="#888888"
            value={codigoTurma}
            onChangeText={setCodigoTurma}
          />
          <TextInput
            style={styles.input}
            placeholder="Nível"
            placeholderTextColor="#888888"
            value={nivel}
            onChangeText={setNivel}
          />
          <TextInput
            style={styles.input}
            placeholder="Ano"
            placeholderTextColor="#888888"
            value={ano}
            onChangeText={setAno}
          />
          <TextInput
            style={styles.input}
            placeholder="Turno"
            placeholderTextColor="#888888"
            value={turno}
            onChangeText={setTurno}
          />
          <TextInput
            style={styles.input}
            placeholder="Descrição"
            placeholderTextColor="#888888"
            value={descricao}
            onChangeText={setDescricao}
          />
          <TextInput
            style={styles.input}
            placeholder="ID da Instituição"
            placeholderTextColor="#888888"
            value={instituicaoId}
            onChangeText={setInstituicaoId}
          />
        </View>

        <TouchableOpacity style={styles.button} onPress={handleRgister}>
          <Text style={styles.buttonText}>CADASTRAR TURMA</Text>
        </TouchableOpacity>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    paddingBottom: 20,
  },
  logoContainer: {
    marginBottom: 20,
    alignItems: 'center',
    paddingRight: 80,
    paddingTop: 30,
  },
  logoImage: {
    width: 300,
    height: 100,
    resizeMode: 'contain',
  },
  input: {
    width: '100%',
    height: 40,
    backgroundColor: '#F5FFFA',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginBottom: 15,
    color: '#000',
  },
  cadastroTurmaContainer: {
    width: '100%',
  },
  button: {
    width: '80%',
    height: 50,
    backgroundColor: '#FFFAFA',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: 'Black',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default CadastroTurmaScreen;
