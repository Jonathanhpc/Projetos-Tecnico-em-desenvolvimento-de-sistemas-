import React, { useState, useEffect } from 'react';
import { View, Text, Switch, TouchableOpacity, StyleSheet, Dimensions, Alert, Image, TextInput, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { createClient } from '@supabase/supabase-js';

const { width, height } = Dimensions.get('window');
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; 
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw'; 
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const profileImages = [
  require('../../../src/Icons/icones/icones_perfil/1.png'),
  require('../../../src/Icons/icones/icones_perfil/2.png'),
  require('../../../src/Icons/icones/icones_perfil/3.png'),
  require('../../../src/Icons/icones/icones_perfil/4.png'),
  require('../../../src/Icons/icones/icones_perfil/5.png'),
  require('../../../src/Icons/icones/icones_perfil/6.png'),
];

const SettingsScreen = () => {
  const navigation = useNavigation();
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState(false);
  const [isRememberLogin, setIsRememberLogin] = useState(false);
  const [selectedImage, setSelectedImage] = useState(profileImages[0]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('usuario@exemplo.com'); // Valor inicial para teste

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('alunos')
        .select('notificacoes_enabled, lembrar_login, nome, foto_perfil')
        .eq('email', email)
        .single();

      if (error) throw error;
      if (data) {
        const { notificacoes_enabled, lembrar_login, nome, foto_perfil } = data;
        setIsNotificationsEnabled(notificacoes_enabled ?? false);
        setIsRememberLogin(lembrar_login ?? false);
        setName(nome ?? '');
        setSelectedImage(profileImages[foto_perfil] || profileImages[0]);
      }
    } catch (error) {
      Alert.alert('Erro ao carregar configurações', error.message);
    }
  };

  const saveSettings = async () => {
    try {
      const profileImageIndex = profileImages.indexOf(selectedImage);
      const { error } = await supabase
        .from('alunos')
        .update({
          notificacoes_enabled: isNotificationsEnabled,
          lembrar_login: isRememberLogin,
          foto_perfil: profileImageIndex,
          nome: name,
        })
        .eq('email', email);
      if (error) throw error;
      Alert.alert('Configurações salvas com sucesso!');
    } catch (error) {
      Alert.alert('Erro ao salvar configurações', error.message);
    }
  };

  const goBack = () => {
    navigation.goBack();
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={goBack} style={styles.navButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.navTitle}>Configurações</Text>
      </View>

      <View style={styles.content}>
        <Text style={styles.title}>Escolha sua imagem de perfil</Text>
        <View style={styles.imageSelectorContainer}>
          {profileImages.map((image, index) => (
            <TouchableOpacity key={index} onPress={() => setSelectedImage(image)}>
              <Image source={image} style={[styles.profileImage, selectedImage === image && styles.selectedImage]} />
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.label}>Nome completo</Text>
        <TextInput
          style={styles.input}
          placeholder="Nome completo"
          value={name}
          onChangeText={setName}
        />
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
        />

        <View style={styles.settingItem}>
          <Text style={styles.settingText}>Notificações</Text>
          <Switch
            value={isNotificationsEnabled}
            onValueChange={setIsNotificationsEnabled}
            thumbColor={isNotificationsEnabled ? '#FF6F00' : '#f4f3f4'}
          />
        </View>

        <View style={styles.settingItem}>
          <Text style={styles.settingText}>Lembrar login</Text>
          <Switch
            value={isRememberLogin}
            onValueChange={setIsRememberLogin}
            thumbColor={isRememberLogin ? '#FF6F00' : '#f4f3f4'}
          />
        </View>

        <TouchableOpacity style={styles.saveButton} onPress={saveSettings}>
          <Text style={styles.saveButtonText}>Salvar Configurações</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F0F0F0' },
  navBar: { width: '100%', height: height * 0.1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: width * 0.05, backgroundColor: '#FF6F00' },
  navButton: { padding: width * 0.02 },
  navTitle: { fontSize: width * 0.05, color: 'white', fontWeight: 'bold', marginLeft: width * 0.02 },
  content: { marginTop: height * 0.02, paddingHorizontal: width * 0.05 },
  title: { fontSize: width * 0.045, fontWeight: 'bold', textAlign: 'center', marginBottom: height * 0.02 },
  imageSelectorContainer: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: height * 0.02 },
  profileImage: { width: width * 0.2, height: width * 0.2, borderRadius: width * 0.1, borderColor: '#DDD', borderWidth: 2 },
  selectedImage: { borderColor: '#FF6F00' },
  label: { fontSize: width * 0.04, fontWeight: 'bold', marginBottom: 5 },
  input: { borderWidth: 1, borderColor: '#DDD', borderRadius: 8, padding: 10, marginVertical: 10, fontSize: width * 0.045 },
  settingItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: height * 0.02, borderBottomWidth: 1, borderBottomColor: '#DDD' },
  settingText: { fontSize: width * 0.05, color: '#333' },
  saveButton: { marginTop: height * 0.05, paddingVertical: height * 0.02, backgroundColor: '#FF6F00', borderRadius: 10, alignItems: 'center' },
  saveButtonText: { color: 'white', fontSize: width * 0.045, fontWeight: 'bold' },
});

export default SettingsScreen;