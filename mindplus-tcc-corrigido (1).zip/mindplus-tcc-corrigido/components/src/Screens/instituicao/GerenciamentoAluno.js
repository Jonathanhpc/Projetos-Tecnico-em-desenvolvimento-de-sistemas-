import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, StyleSheet, Dimensions, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { supabase } from '../supabaseClient'; // Supondo que você já tenha configurado o Supabase

const { width, height } = Dimensions.get('window');

const CadastroInstituicaoScreen = () => {
  const navigation = useNavigation();
  const [cnes, setCnes] = useState('');
  const [turmas, setTurmas] = useState([]);
  const [pesquisa, setPesquisa] = useState('');

  // Função para abrir o drawer
  const openDrawer = () => {
    navigation.openDrawer();
  };

  // Função para voltar para a tela anterior
  const goBack = () => {
    navigation.goBack();
  };

  const fetchTurmas = async (cnes) => {
    try {
      const { data, error } = await supabase
        .from('turmas')
        .select('*')
        .eq('cnes', cnes);

      if (error) throw error;
      setTurmas(data);
    } catch (error) {
      console.error('Erro ao buscar turmas:', error.message);
    }
  };

  const handlePesquisar = (texto) => {
    setPesquisa(texto);
    if (texto.length > 2) {
      fetchTurmas(cnes);
    } else {
      setTurmas([]);
    }
  };

  useEffect(() => {
    if (cnes) {
      fetchTurmas(cnes);
    }
  }, [cnes]);

  return (
    <View style={styles.container}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={openDrawer} style={styles.navButton}>
          <Ionicons name="menu" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.navTitle}>Cadastro de Instituição</Text>
        <TouchableOpacity onPress={goBack} style={styles.navButton}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <TextInput
          style={styles.input}
          placeholder="Digite o CNES"
          value={cnes}
          onChangeText={setCnes}
          keyboardType="numeric"
        />
        <TouchableOpacity onPress={() => fetchTurmas(cnes)} style={styles.button}>
          <Text style={styles.buttonText}>Buscar Turmas</Text>
        </TouchableOpacity>

        {/* Campo de Pesquisa */}
        <TextInput
          style={styles.input}
          placeholder="Pesquisar Turmas"
          value={pesquisa}
          onChangeText={handlePesquisar}
        />

        {/* Lista de Turmas */}
        {turmas.length > 0 ? (
          <View style={styles.turmasContainer}>
            {turmas
              .filter((turma) => turma.nome.toLowerCase().includes(pesquisa.toLowerCase()))
              .map((turma) => (
                <View key={turma.id} style={styles.turmaContainer}>
                  <Text style={styles.turmaText}>{turma.nome}</Text>
                </View>
              ))}
          </View>
        ) : (
          <Text style={styles.noTurmasText}>Nenhuma turma encontrada.</Text>
        )}

        {/* Botão para Adicionar Alunos e Profissionais */}
        <TouchableOpacity
          onPress={() => navigation.navigate('CadastroAluno')}
          style={styles.addButton}
        >
          <Ionicons name="add" size={30} color="#FFF" />
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    backgroundColor: '#FF6F00',
    paddingVertical: 10,
  },
  navButton: {
    padding: 10,
  },
  navTitle: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18,
  },
  content: {
    padding: 20,
    alignItems: 'center',
  },
  input: {
    width: '100%',
    padding: 10,
    marginBottom: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  button: {
    backgroundColor: '#FF6F00',
    padding: 10,
    borderRadius: 8,
    width: '100%',
    marginBottom: 20,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
  turmasContainer: {
    width: '100%',
  },
  turmaContainer: {
    backgroundColor: '#FFB74D',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    shadowColor: 'rgba(0,0,0,0.2)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  turmaText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
  noTurmasText: {
    fontSize: 16,
    color: '#FF6F00',
  },
  addButton: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: '#FF6F00',
    padding: 20,
    borderRadius: 50,
    shadowColor: 'rgba(0,0,0,0.2)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
});

export default CadastroInstituicaoScreen;
