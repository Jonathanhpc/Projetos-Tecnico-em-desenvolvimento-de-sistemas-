import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, Pressable, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const MenuScreen = ({ navigation }) => {
  const [modalVisible, setModalVisible] = useState(false);

  const handleMenuOption = (option) => {
    setModalVisible(false); 
    switch (option) {
      case 'profile':
        navigation.navigate('Profile'); 
        break;
      case 'settings':
        navigation.navigate('Settings'); 
        break;
      case 'logout':
        
        navigation.navigate('Login');
        break;
      default:
        break;
    }
  };

  const menuOptions = [
    { key: 'profile', label: 'Profile' },
    { key: 'settings', label: 'Settings' },
    { key: 'logout', label: 'Logout' },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu Screen</Text>
      
      {/* Botão de menu na parte superior direita */}
      <TouchableOpacity
        onPress={() => setModalVisible(true)}
        style={styles.menuButton}
      >
        <Ionicons name="ellipsis-vertical" size={24} color="black" />
      </TouchableOpacity>

      {/* Modal para exibir o menu */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <Pressable style={styles.overlay} onPress={() => setModalVisible(false)}>
          <View style={styles.menuContainer}>
            {menuOptions.map(option => (
              <Pressable
                key={option.key}
                onPress={() => handleMenuOption(option.key)}
                style={styles.menuItem}
              >
                <Text style={styles.menuText}>{option.label}</Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  menuButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    padding: 10,
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  menuContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    width: 150,
    marginRight: 10,
    elevation: 5,
  },
  menuItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  menuText: {
    fontSize: 16,
  },
});

export default MenuScreen;
