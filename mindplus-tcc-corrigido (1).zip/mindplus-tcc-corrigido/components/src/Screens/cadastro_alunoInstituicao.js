import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image, StatusBar, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { createClient } from '@supabase/supabase-js';
import axios from 'axios';
// Configurações do Supabase
const SUPABASE_URL = 'https://mtcstjxlhobtgaopefep.supabase.co'; // Substitua pela sua URL do Supabase
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im10Y3N0anhsaG9idGdhb3BlZmVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk3Njk3MTgsImV4cCI6MjA0NTM0NTcxOH0.ouCxWxI6KFWLP5G6_Y1NoH7--kal00Dtu49rIEoMcnw';

const CadastroAlunoScreen = ({ navigation }) => {
  const [nomeCompleto, setNomeCompleto] = useState('');
  const [cpf, setCpf] = useState('');
  const [email, setEmail] = useState('');
  const [rg, setRg] = useState('');
  const [nomeMae, setNomeMae] = useState('');
  const [telefone, setTelefone] = useState('');
  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [sexo, setSexo] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [senha, setSenha] = useState('');
  const [codigoInstituicao, setCodigoInstituicao] = useState('');
  const [codigoProfissional, setCodigoProfissional] = useState('');

  const formatDate = (dateStr) => {
    const [day, month, year] = dateStr.split('/');
    return `${year}-${month}-${day}`; // Converte para AAAA-MM-DD
  };

  const handleCepChange = async (cep) => {
    setCep(cep);
    if (cep.length === 8) {
      try {
        const response = await axios.get(`https://viacep.com.br/ws/${cep}/json/`);
        if (response.data.erro) {
          Alert.alert('Erro', 'CEP não encontrado.');
          return;
        }
        setEndereco(`${response.data.logradouro}, ${response.data.bairro}, ${response.data.localidade} - ${response.data.uf}`);
      } catch (error) {
        Alert.alert('Erro', 'Erro ao buscar o endereço. Tente novamente.');
      }
    }
  };

  const handleRegister = async () => {
    if (!nomeCompleto || !cpf || !email || !rg || !nomeMae || !telefone || !cep || !endereco || !sexo || !dataNascimento || !senha || !codigoInstituicao || !codigoProfissional) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    const dataNascimentoFormatted = formatDate(dataNascimento);

    try {
      const { data, error } = await supabase
        .from('alunos_instituicao') // Alterado para a tabela 'alunos_instituicao'
        .insert([
          { 
            cpf,
            nome: nomeCompleto,
            telefone,
            data_nascimento: dataNascimentoFormatted,
            sexo,
            cep,
            endereco,
            email,
            codigo_instituicao: codigoInstituicao,
            codigo_profissional: codigoProfissional,
            senha,
          }
        ]);

      if (error) {
        Alert.alert('Erro', error.message);
      } else {
        Alert.alert('Sucesso', 'Cadastro realizado com sucesso!');
        navigation.replace('Home');
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível realizar o cadastro.');
    }
  };

  const GenderButton = ({ label, value }) => (
    <TouchableOpacity
      style={[styles.genderButton, sexo === value && styles.genderButtonSelected]}
      onPress={() => setSexo(value)}
    >
      <Text style={[styles.genderButtonText, sexo === value && styles.genderButtonTextSelected]}>
        {label}
      </Text>
    </TouchableOpacity>
  );

  return (
    <LinearGradient colors={['#f46a14', '#f46a14']} style={styles.background}>
      <StatusBar barStyle="light-content" backgroundColor="#f46a14" />
      <ScrollView contentContainerStyle={styles.container}>
        {/* Botão de Voltar */}
        <TouchableOpacity 
          style={styles.backButton} 
          onPress={() => navigation.goBack()} // Função para voltar à página anterior
        >
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>

        <View style={styles.logoContainer}>
          <Image source={require('../Icons/LogoMax/logo.png')} style={styles.logoImage} />
        </View>
        
        <View style={styles.cadastroalunoContainer}>
          <TextInput
            style={styles.input}
            placeholder="Nome completo"
            placeholderTextColor="#888888"
            value={nomeCompleto}
            onChangeText={setNomeCompleto}
          />
          <TextInput
            style={styles.input}
            placeholder="CPF"
            placeholderTextColor="#888888"
            value={cpf}
            onChangeText={setCpf}
          />
          <TextInput
            style={styles.input}
            placeholder="RG"
            placeholderTextColor="#888888"
            value={rg}
            onChangeText={setRg}
          />
          <TextInput
            style={styles.input}
            placeholder="Nome da Mãe"
            placeholderTextColor="#888888"
            value={nomeMae}
            onChangeText={setNomeMae}
          />
          <TextInput
            style={styles.input}
            placeholder="Telefone"
            placeholderTextColor="#888888"
            value={telefone}
            onChangeText={setTelefone}
          />
          <TextInput
            style={styles.input}
            placeholder="CEP"
            placeholderTextColor="#888888"
            value={cep}
            onChangeText={handleCepChange}
            maxLength={8}
          />
          <TextInput
            style={styles.input}
            placeholder="Endereço"
            placeholderTextColor="#888888"
            value={endereco}
            onChangeText={setEndereco}
          />
          <TextInput
            style={styles.input}
            placeholder="Data de Nascimento (DD/MM/AAAA)"
            placeholderTextColor="#888888"
            value={dataNascimento}
            onChangeText={setDataNascimento}
          />
          <Text style={styles.genderLabel}>Sexo</Text>
          <View style={styles.genderContainer}>
            <GenderButton label="Masculino" value="Masculino" />
            <GenderButton label="Feminino" value="Feminino" />
            <GenderButton label="Outro" value="Outro" />
          </View>
          <TextInput
            style={styles.input}
            placeholder="Código da Instituição"
            placeholderTextColor="#888888"
            value={codigoInstituicao}
            onChangeText={setCodigoInstituicao}
          />
          <TextInput
            style={styles.input}
            placeholder="Código do Profissional"
            placeholderTextColor="#888888"
            value={codigoProfissional}
            onChangeText={setCodigoProfissional}
          />
          <TextInput
            style={styles.input}
            placeholder="E-mail"
            placeholderTextColor="#888888"
            value={email}
            onChangeText={setEmail}
          />
          <TextInput
            style={styles.input}
            placeholder="Senha"
            placeholderTextColor="#888888"
            secureTextEntry
            value={senha}
            onChangeText={setSenha}
          />
        </View>

        <TouchableOpacity 
          style={styles.backButton} 
          onPress={() => navigation.goBack()} // Função para voltar à página anterior
        >
          <Text style={styles.cadastroalunoText}>Voltar para página anterior</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={handleRegister}>
          <Text style={styles.buttonText}>CADASTRAR</Text>
        </TouchableOpacity>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
   container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    paddingBottom: 20,
  },
  logoContainer: {
    marginBottom: 20,
    alignItems: 'center',
    paddingRight: 80,
    paddingTop: 30,
  },
  logoImage: {
    width: 300,
    height: 100,
    resizeMode: 'contain',
  },
  input: {
    width: '100%',
    height: 40,
    backgroundColor: '#F5FFFA',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginBottom: 15,
    color: '#000',
  },
  genderLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 10,
    width: '100%',
    textAlign: 'left',
  },
  genderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 15,
  },
  genderButton: {
    flex: 1,
    marginHorizontal: 5,
    backgroundColor: '#d6cfcb',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
  },
  genderButtonSelected: {
    backgroundColor: '#f46a14',
  },
  genderButtonText: {
    color: '#000',
    fontSize: 16,
  },
  genderButtonTextSelected: {
    color: '#fff',
  },
  cadastroalunoContainer: {
    width: '100%',
  },
  cadastroalunoText: {
    color: 'white',
    fontSize: 14,
    textDecorationLine: 'underline',
    marginTop: 20,
  },
  button: {
    width: '80%',
    height: 50,
    backgroundColor: '#FFFAFA',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: 'Black',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default CadastroAlunoScreen;
