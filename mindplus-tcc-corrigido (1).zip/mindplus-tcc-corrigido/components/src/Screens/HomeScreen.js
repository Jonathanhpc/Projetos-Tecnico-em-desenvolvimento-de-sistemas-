import React, { useState, useEffect } from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { useFonts } from 'expo-font';

const TutorialScreen = () => {
  const [fontsLoaded] = useFonts({
    'Poppins': require('../../../assets/fontes/Poppins/Poppins-Regular.ttf'),
  });

  const navigation = useNavigation();
  const [currentScreen, setCurrentScreen] = useState('splash'); // Tela inicial é a de Splash
  const [tutorialStep, setTutorialStep] = useState(1);

  // Exibe a tela de Splash por 2 segundos antes de iniciar o tutorial
  useEffect(() => {
    if (fontsLoaded) {
      if (currentScreen === 'splash') {
        const timer = setTimeout(() => {
          setCurrentScreen('tutorial'); // Após 2 segundos, mostra o tutorial
        }, 2000);

        return () => clearTimeout(timer);
      }
    }
  }, [fontsLoaded, currentScreen]);

  // Função para renderizar o tutorial
  const renderTutorialScreen = () => {
    switch (tutorialStep) {
      case 1:
        return (
          <View style={styles.container}>
            <Image source={require('../Icons/LogoMax/logo.png')} style={styles.image_logo} />
            <Text style={styles.title}>Bem-vindo ao Mind Plus</Text>
            <Text style={styles.subtitle}>Nós ajudamos você a organizar sua mente e melhorar seu foco.</Text>
          </View>
        );
      case 2:
        return (
          <View style={styles.container}>
            <Image source={require('../Images/alvo.png')} style={styles.image} />
            <Text style={styles.title}>Técnicas para melhorar o foco</Text>
            <Text style={styles.subtitle}>Aprenda a usar técnicas simples e eficazes para aumentar sua concentração.</Text>
          </View>
        );
      case 3:
        return (
          <View style={styles.container}>
            <Image source={require('../Images/ampulheta.png')} style={styles.image} />
            <Text style={styles.title}>Organize seu tempo</Text>
            <Text style={styles.subtitle}>Use o nosso aplicativo para planejar e gerenciar suas tarefas de forma eficiente.</Text>
          </View>
        );
      default:
        return (
          <View style={styles.container}>
            <Text style={styles.title}>Carregando...</Text>
          </View>
        );
    }
  };

  // Função para renderizar a tela de Splash
  const renderSplashScreen = () => {
    return (
      <View style={styles.splashContainer}>
        <Image source={require('../Icons/LogoMax/logo.png')} style={styles.splashLogo} />
        <Text style={styles.title}>Mind Plus</Text>
      </View>
    );
  };

  if (!fontsLoaded) {
    return null; // Não renderiza nada até as fontes estarem carregadas
  }

  return (
    <LinearGradient
      colors={['#f46a14', '#f46a14']} // Degradê de laranja
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={styles.background}
    >
      {currentScreen === 'splash' ? renderSplashScreen() : renderTutorialScreen()}

      {currentScreen === 'tutorial' && (
        <View style={styles.footer}>
          {tutorialStep > 1 && (
            <TouchableOpacity
              style={styles.navButton}
              onPress={() => setTutorialStep(tutorialStep - 1)}
            >
              <Text style={styles.buttonText}>Voltar</Text>
            </TouchableOpacity>
          )}
          {tutorialStep < 3 ? (
            <TouchableOpacity
              style={styles.navButton}
              onPress={() => setTutorialStep(tutorialStep + 1)}
            >
              <Text style={styles.buttonText}>Próximo</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={styles.navButton}
              onPress={() => navigation.navigate('Login')}
            >
              <Text style={styles.buttonText}>Ir para o Login</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  splashContainer: {
 flex: 1,
justifyContent: 'center',
alignItems: 'center',
  },
  splashLogo: {
   width: 200, 
height: 90,
right:40,
marginBottom: 20, 
  },
  container: {
 justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    flex: 1,
  },
   image_logo: {
      width: 200, 
height: 90,
right:40,
marginBottom: 20,

  },
  image: {
     width: 100, 
height: 100,
right:5,
marginBottom: 0,

  },
  title: {
   fontSize: 35, 
color: '#FFF', 
fontWeight: 'bold', 
  },
  subtitle: {
    fontSize: 20,
    color: '#FFF',
    fontFamily: 'Poppins', // Fonte personalizada
    textAlign: 'center',
    marginHorizontal: 20,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    position: 'absolute',
    bottom: 40,
  },
  navButton: {
    backgroundColor: '#FFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    marginTop: 20,
  },
  buttonText: {
    color: '#FF6A00',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default TutorialScreen;
