// styles.js
import styled from 'styled-components';

export const SidebarContainer = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 250px;
  height: 100%;
  background-color: #fff;
  box-shadow: 2px 0 5px rgba(0,0,0,0.5);
  display: flex;
  flex-direction: column;
  padding: 20px;
  z-index: 20;
`;

export const CloseButton = styled.div`
  display: flex;
  justify-content: flex-end;
  padding: 10px;
  cursor: pointer;
  font-size: 24px;
`;

export const ProfilePhoto = styled.img`
  width: 100px;
  height: 100px;
  border-radius: 50%;
  object-fit: cover;
  margin-bottom: 20px;
`;

export const ProfileName = styled.h2`
  font-size: 18px;
  color: #333;
  margin-bottom: 20px;
`;

export const ButtonsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const Button = styled.button`
  background-color: #1A202C;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 10px;
  cursor: pointer;
  text-align: center;
  font-size: 16px;

  &:hover {
    background-color: #333;
  }
`;

export const ButtonText = styled.span`
  font-weight: bold;
`;
