import React, { useState, useEffect } from 'react';
import { SidebarContainer, CloseButton, ProfilePhoto, ProfileName, Button, ButtonText, ButtonsContainer } from './styles';
import { FaTimes } from 'react-icons/fa';
import axios from 'axios'; // Para realizar chamadas HTTP

const Sidebar = ({ closeSidebar }) => {
  const [user, setUser] = useState({ photo: '', name: '' });

  useEffect(() => {
    // Função para buscar dados do usuário
    const fetchUserData = async () => {
      try {
        const response = await axios.get('/api/user'); // Substitua pela URL real da API
        setUser({
          photo: response.data.photo, // Ajuste conforme a resposta da API
          name: response.data.name,
        });
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);

  return (
    <SidebarContainer>
      <CloseButton onClick={closeSidebar}>
        <FaTimes />
      </CloseButton>
      <ProfilePhoto src={user.photo || 'https://via.placeholder.com/100'} alt="Profile" />
      <ProfileName>{user.name || 'Nome do Usuário'}</ProfileName>
      <ButtonsContainer>
        <Button onClick={() => console.log('Navigating to Page 1')}>
          <ButtonText>Page 1</ButtonText>
        </Button>
        <Button onClick={() => console.log('Navigating to Page 2')}>
          <ButtonText>Page 2</ButtonText>
        </Button>
        <Button onClick={() => console.log('Navigating to Page 3')}>
          <ButtonText>Page 3</ButtonText>
        </Button>
      </ButtonsContainer>
    </SidebarContainer>
  );
};

export default Sidebar;
